-- ============================================================
-- Migration: Account System v2
--   - customer balance (wallet)
--   - email + email verification + google login
--   - personal coupons (customer_id)
--   - balance transaction log
--   - email OTP table
--   - SMTP / Google / order-login settings
--
--   mysql -u botuser -p restaurant_bot < migration_accounts_v2.sql
-- ============================================================
SET NAMES utf8mb4;

-- customers: add balance, email, verification, google id
ALTER TABLE customers ADD COLUMN balance DECIMAL(10,2) DEFAULT 0 AFTER password;
ALTER TABLE customers ADD COLUMN email VARCHAR(100) NULL UNIQUE AFTER balance;
ALTER TABLE customers ADD COLUMN email_verified TINYINT(1) DEFAULT 0 AFTER email;
ALTER TABLE customers ADD COLUMN google_id VARCHAR(100) NULL UNIQUE AFTER email_verified;

-- coupons: personal coupon support
ALTER TABLE coupons ADD COLUMN customer_id INT NULL AFTER applicable_ids;
ALTER TABLE coupons ADD CONSTRAINT fk_coupon_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE;

-- restaurant_settings: SMTP + auth config
ALTER TABLE restaurant_settings ADD COLUMN smtp_host VARCHAR(100) NULL;
ALTER TABLE restaurant_settings ADD COLUMN smtp_port INT DEFAULT 587;
ALTER TABLE restaurant_settings ADD COLUMN smtp_user VARCHAR(100) NULL;
ALTER TABLE restaurant_settings ADD COLUMN smtp_pass VARCHAR(255) NULL;
ALTER TABLE restaurant_settings ADD COLUMN smtp_from_email VARCHAR(100) NULL;
ALTER TABLE restaurant_settings ADD COLUMN smtp_from_name VARCHAR(100) NULL;
ALTER TABLE restaurant_settings ADD COLUMN smtp_secure VARCHAR(10) DEFAULT 'tls';
ALTER TABLE restaurant_settings ADD COLUMN require_login_for_orders TINYINT(1) DEFAULT 1;
ALTER TABLE restaurant_settings ADD COLUMN require_email_verification TINYINT(1) DEFAULT 0;
ALTER TABLE restaurant_settings ADD COLUMN google_client_id VARCHAR(255) NULL;

-- balance transactions (audit log)
CREATE TABLE IF NOT EXISTS balance_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  reason VARCHAR(255),
  order_id INT NULL,
  created_by VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- email OTPs
CREATE TABLE IF NOT EXISTS email_otps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) NOT NULL,
  code VARCHAR(6) NOT NULL,
  purpose VARCHAR(30) DEFAULT 'verify',
  expires_at TIMESTAMP NOT NULL,
  used TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- orders: track balance used + credit_used column if not present
ALTER TABLE orders ADD COLUMN balance_used DECIMAL(10,2) DEFAULT 0 AFTER discount_amount;
