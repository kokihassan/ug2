<?php
// includes/mailer.php
// A minimal SMTP client (no Composer/PHPMailer dependency) supporting
// STARTTLS and SSL, AUTH LOGIN. Good enough for OTP/transactional emails.

function smtpSendMail($settings, $toEmail, $subject, $bodyHtml) {
    $host = $settings['smtp_host'] ?? null;
    $port = (int)($settings['smtp_port'] ?? 587);
    $user = $settings['smtp_user'] ?? '';
    $pass = $settings['smtp_pass'] ?? '';
    $fromEmail = $settings['smtp_from_email'] ?? $user;
    $fromName = $settings['smtp_from_name'] ?? ($settings['name'] ?? 'Restaurant');
    $secure = $settings['smtp_secure'] ?? 'tls'; // tls | ssl | none

    if (!$host || !$user || !$pass || !$fromEmail) {
        return ['success' => false, 'error' => 'SMTP غير مُعدّ. اذهب إلى الإعدادات → SMTP'];
    }

    $transport = ($secure === 'ssl') ? "ssl://$host" : $host;
    $errno = 0; $errstr = '';
    $fp = @stream_socket_client("$transport:$port", $errno, $errstr, 15);
    if (!$fp) return ['success' => false, 'error' => "فشل الاتصال بـ SMTP: $errstr ($errno)"];

    $read = function() use ($fp) {
        $data = '';
        while ($line = fgets($fp, 515)) {
            $data .= $line;
            if (substr($line, 3, 1) === ' ') break; // last line of multi-line response
        }
        return $data;
    };
    $write = function($cmd) use ($fp) { fwrite($fp, $cmd . "\r\n"); };

    $read(); // greeting

    $write("EHLO " . ($_SERVER['SERVER_NAME'] ?? 'localhost'));
    $read();

    if ($secure === 'tls') {
        $write("STARTTLS");
        $resp = $read();
        if (substr($resp, 0, 3) !== '220') { fclose($fp); return ['success'=>false,'error'=>'فشل STARTTLS: '.$resp]; }
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($fp); return ['success'=>false,'error'=>'فشل تشفير TLS'];
        }
        $write("EHLO " . ($_SERVER['SERVER_NAME'] ?? 'localhost'));
        $read();
    }

    $write("AUTH LOGIN");
    $resp = $read();
    if (substr($resp, 0, 3) !== '334') { fclose($fp); return ['success'=>false,'error'=>'AUTH LOGIN غير مدعوم: '.$resp]; }

    $write(base64_encode($user));
    $resp = $read();
    if (substr($resp, 0, 3) !== '334') { fclose($fp); return ['success'=>false,'error'=>'اسم المستخدم مرفوض: '.$resp]; }

    $write(base64_encode($pass));
    $resp = $read();
    if (substr($resp, 0, 3) !== '235') { fclose($fp); return ['success'=>false,'error'=>'فشل تسجيل الدخول (تحقق من كلمة المرور / App Password): '.$resp]; }

    $write("MAIL FROM:<$fromEmail>");
    $resp = $read();
    if (substr($resp, 0, 3) !== '250') { fclose($fp); return ['success'=>false,'error'=>'MAIL FROM مرفوض: '.$resp]; }

    $write("RCPT TO:<$toEmail>");
    $resp = $read();
    if (substr($resp, 0, 3) !== '250' && substr($resp, 0, 3) !== '251') { fclose($fp); return ['success'=>false,'error'=>'RCPT TO مرفوض: '.$resp]; }

    $write("DATA");
    $resp = $read();
    if (substr($resp, 0, 3) !== '354') { fclose($fp); return ['success'=>false,'error'=>'DATA مرفوض: '.$resp]; }

    $boundary = uniqid('bnd');
    $headers = [];
    $headers[] = "From: " . mb_encode_mimeheader($fromName) . " <$fromEmail>";
    $headers[] = "To: <$toEmail>";
    $headers[] = "Subject: " . mb_encode_mimeheader($subject);
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-Type: text/html; charset=UTF-8";
    $headers[] = "Date: " . date('r');

    $message = implode("\r\n", $headers) . "\r\n\r\n" . $bodyHtml . "\r\n.";
    // Escape lines starting with a lone dot
    $message = preg_replace('/^\./m', '..', $message);

    $write($message);
    $resp = $read();
    if (substr($resp, 0, 3) !== '250') { fclose($fp); return ['success'=>false,'error'=>'فشل إرسال الرسالة: '.$resp]; }

    $write("QUIT");
    fclose($fp);

    return ['success' => true];
}

// Generates a 6-digit numeric OTP code
function generateOtpCode() {
    return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}
