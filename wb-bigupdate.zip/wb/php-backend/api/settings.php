<?php
// api/settings.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    case 'GET:get':
        $db = getDB();
        $settings = $db->query("SELECT * FROM restaurant_settings LIMIT 1")->fetch();
        if (!empty($settings['smtp_pass'])) $settings['smtp_pass'] = '••••••••';
        success($settings);

    case 'PUT:update':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        $logo = null;
        if (!empty($_FILES['logo'])) $logo = uploadImage($_FILES['logo'], 'settings');

        // Don't overwrite SMTP password if not sent or masked
        if (empty($data['smtp_pass']) || $data['smtp_pass'] === '••••••••') {
            $cur = $db->query("SELECT smtp_pass FROM restaurant_settings LIMIT 1")->fetchColumn();
            $data['smtp_pass'] = $cur;
        }
        
        $sql = "UPDATE restaurant_settings SET name=?, bot_name=?, bot_personality=?, 
            welcome_message=?, closed_message=?, paused_message=?,
            phone=?, email=?, facebook=?, instagram=?, website=?,
            min_order_amount=?, tax_percentage=?, currency=?,
            is_open=?, orders_paused=?,
            smtp_host=?, smtp_port=?, smtp_user=?, smtp_pass=?, smtp_from_email=?, smtp_from_name=?, smtp_secure=?,
            require_login_for_orders=?, require_email_verification=?, google_client_id=?";
        $params = [
            $data['name'], $data['bot_name']??'نور', $data['bot_personality']??null,
            $data['welcome_message']??null, $data['closed_message']??null, $data['paused_message']??null,
            $data['phone']??null, $data['email']??null, $data['facebook']??null,
            $data['instagram']??null, $data['website']??null,
            $data['min_order_amount']??0, $data['tax_percentage']??0, $data['currency']??'جنيه',
            $data['is_open']??1, $data['orders_paused']??0,
            $data['smtp_host']??null, $data['smtp_port']??587, $data['smtp_user']??null,
            $data['smtp_pass']??null, $data['smtp_from_email']??null, $data['smtp_from_name']??null,
            $data['smtp_secure']??'tls',
            $data['require_login_for_orders']??1, $data['require_email_verification']??0,
            $data['google_client_id']??null,
        ];
        
        if ($logo) { $sql .= ", logo=?"; $params[] = $logo; }
        $db->prepare($sql)->execute($params);
        success([], 'تم حفظ الإعدادات');

    case 'PUT:toggle-open':
        requireAuth();
        $db = getDB();
        $db->query("UPDATE restaurant_settings SET is_open = NOT is_open");
        $status = $db->query("SELECT is_open FROM restaurant_settings LIMIT 1")->fetchColumn();
        success(['is_open' => $status]);

    case 'PUT:toggle-orders':
        requireAuth();
        $db = getDB();
        $db->query("UPDATE restaurant_settings SET orders_paused = NOT orders_paused");
        $status = $db->query("SELECT orders_paused FROM restaurant_settings LIMIT 1")->fetchColumn();
        success(['orders_paused' => $status]);

    // FAQ Management
    case 'GET:faq':
        $db = getDB();
        success($db->query("SELECT * FROM faq WHERE is_active=1 ORDER BY sort_order")->fetchAll());

    case 'POST:faq':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("INSERT INTO faq (question, answer, category, sort_order) VALUES (?,?,?,?)")
           ->execute([$data['question'], $data['answer'], $data['category']??'general', $data['sort_order']??0]);
        success(['id' => $db->lastInsertId()], 'تم الإضافة', 201);

    case 'DELETE:faq':
        requireAuth();
        $id = $path[1] ?? null;
        getDB()->prepare("DELETE FROM faq WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    // Peak Hours
    case 'GET:peak-hours':
        requireAuth();
        success(getDB()->query("SELECT * FROM peak_hours")->fetchAll());

    case 'POST:peak-hours':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("INSERT INTO peak_hours (branch_id, day_of_week, start_time, end_time, extra_delivery_time, is_active) VALUES (?,?,?,?,?,?)")
           ->execute([$data['branch_id']??null, $data['day_of_week']??null, $data['start_time'], $data['end_time'], $data['extra_delivery_time']??15, 1]);
        success(['id' => $db->lastInsertId()], 'تم الإضافة', 201);

    // ============================================================
    // AI PROVIDERS (multi-provider chatbot with fallback)
    // ============================================================

    // List all providers (admin) - includes api_key for editing
    case 'GET:ai-providers':
        requireAuth();
        success(getDB()->query("SELECT * FROM ai_providers ORDER BY priority ASC, id ASC")->fetchAll());

    // Add a provider
    case 'POST:ai-providers':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['provider']) || empty($data['model'])) error('بيانات ناقصة');
        $db = getDB();
        if (!empty($data['is_default'])) {
            $db->exec("UPDATE ai_providers SET is_default=0");
        }
        $stmt = $db->prepare("INSERT INTO ai_providers (provider, display_name, api_key, model, is_active, is_default, priority) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([
            $data['provider'], $data['display_name'] ?? $data['provider'], $data['api_key'] ?? '',
            $data['model'], $data['is_active'] ?? 1, $data['is_default'] ?? 0, $data['priority'] ?? 0,
        ]);
        success(['id' => $db->lastInsertId()], 'تمت الإضافة', 201);

    // Update a provider
    case 'PUT:ai-providers':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        if (!empty($data['is_default'])) {
            $db->exec("UPDATE ai_providers SET is_default=0");
        }
        // If api_key not sent (or masked), keep the existing one
        if (!isset($data['api_key']) || $data['api_key'] === '••••••••' || $data['api_key'] === '') {
            $cur = $db->prepare("SELECT api_key FROM ai_providers WHERE id=?");
            $cur->execute([$id]);
            $data['api_key'] = $cur->fetchColumn();
        }
        $stmt = $db->prepare("UPDATE ai_providers SET display_name=?, api_key=?, model=?, is_active=?, is_default=?, priority=? WHERE id=?");
        $stmt->execute([
            $data['display_name'], $data['api_key'], $data['model'],
            $data['is_active'] ?? 1, $data['is_default'] ?? 0, $data['priority'] ?? 0, $id,
        ]);
        success([], 'تم التحديث');

    // Delete a provider
    case 'DELETE:ai-providers':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        getDB()->prepare("DELETE FROM ai_providers WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    default:
        error('Action not found', 404);
}
