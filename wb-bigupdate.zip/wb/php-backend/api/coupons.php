<?php
// api/coupons.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    case 'GET:list':
        requireAuth();
        success(getDB()->query("SELECT c.*, cu.name as customer_name, cu.whatsapp_number as customer_phone
            FROM coupons c LEFT JOIN customers cu ON c.customer_id=cu.id
            ORDER BY c.created_at DESC")->fetchAll());

    case 'POST:create':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO coupons (code, description, type, value, min_order_amount, max_discount, usage_limit, usage_per_customer, valid_from, valid_until, customer_id, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([strtoupper($data['code']), $data['description']??null, $data['type'], $data['value'], $data['min_order_amount']??0, $data['max_discount']??null, $data['usage_limit']??null, $data['usage_per_customer']??1, $data['valid_from']??null, $data['valid_until']??null, $data['customer_id']??null, 1]);
        success(['id' => $db->lastInsertId()], 'تم إنشاء الكوبون', 201);

    case 'PUT:toggle':
        requireAuth();
        $id = $path[1] ?? null;
        getDB()->prepare("UPDATE coupons SET is_active = NOT is_active WHERE id=?")->execute([$id]);
        success([], 'تم التحديث');

    case 'DELETE:delete':
        requireAuth();
        $id = $path[1] ?? null;
        getDB()->prepare("DELETE FROM coupons WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    case 'POST:validate':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $customerId = optionalCustomerAuth() ?? ($data['customer_id'] ?? null);

        $stmt = $db->prepare("SELECT * FROM coupons WHERE code=? AND is_active=1
            AND (valid_from IS NULL OR valid_from<=NOW())
            AND (valid_until IS NULL OR valid_until>=NOW())
            AND (usage_limit IS NULL OR used_count < usage_limit)");
        $stmt->execute([strtoupper($data['code'] ?? '')]);
        $coupon = $stmt->fetch();
        if (!$coupon) error('كوبون غير صالح أو منتهي الصلاحية');

        // Personal coupon: only the assigned customer can use it
        if (!empty($coupon['customer_id'])) {
            if (!$customerId || (int)$coupon['customer_id'] !== (int)$customerId) {
                error('هذا الكوبون غير متاح لحسابك');
            }
        }

        if ((float)($data['subtotal'] ?? 0) < (float)$coupon['min_order_amount']) {
            error("الحد الأدنى للطلب {$coupon['min_order_amount']} جنيه");
        }

        // Check customer usage (only if we know who the customer is)
        if ($customerId) {
            $usage = $db->prepare("SELECT COUNT(*) FROM coupon_usage WHERE coupon_id=? AND customer_id=?");
            $usage->execute([$coupon['id'], $customerId]);
            if ($usage->fetchColumn() >= $coupon['usage_per_customer']) error('لقد استخدمت هذا الكوبون من قبل');
        }

        $discount = $coupon['type'] === 'percentage' ? $data['subtotal'] * ($coupon['value']/100) : $coupon['value'];
        if ($coupon['max_discount']) $discount = min($discount, $coupon['max_discount']);
        $discount = min($discount, $data['subtotal']); // never discount more than the subtotal

        success(['coupon' => $coupon, 'discount' => round($discount, 2)]);

    default:
        error('Action not found', 404);
}
