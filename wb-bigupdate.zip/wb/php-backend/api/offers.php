<?php
// api/offers.php - Offers & Combos Management
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path   = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch ("$method:$action") {

    // ─── PUBLIC: Get active offers ────────────────────────────
    case 'GET:active':
        $db = getDB();
        $stmt = $db->query("SELECT o.*, GROUP_CONCAT(
                CONCAT(mi.id,'|',mi.name,'|',oi.quantity,'|',mi.price,'|',COALESCE(mi.image,'')) ORDER BY oi.id SEPARATOR ';;'
            ) as items_str
            FROM offers o
            LEFT JOIN offer_items oi ON o.id = oi.offer_id
            LEFT JOIN menu_items mi ON oi.item_id = mi.id
            WHERE o.is_active = 1
            AND (o.valid_from IS NULL OR o.valid_from <= NOW())
            AND (o.valid_until IS NULL OR o.valid_until >= NOW())
            GROUP BY o.id
            ORDER BY o.sort_order ASC");
        $offers = $stmt->fetchAll();
        foreach ($offers as &$offer) {
            $offer['items'] = [];
            if ($offer['items_str']) {
                foreach (explode(';;', $offer['items_str']) as $item) {
                    [$itemId, $name, $qty, $price, $image] = explode('|', $item);
                    $offer['items'][] = [
                        'item_id' => (int)$itemId,
                        'name' => $name,
                        'quantity' => (int)$qty,
                        'price' => (float)$price,
                        'image' => $image ?: null,
                    ];
                }
            }
            unset($offer['items_str']);
        }
        success($offers);

    // ─── ADMIN: Get all offers ────────────────────────────────
    case 'GET:list':
        requireAuth();
        $db = getDB();
        $offers = $db->query("SELECT * FROM offers ORDER BY sort_order ASC")->fetchAll();
        foreach ($offers as &$offer) {
            $items = $db->prepare("SELECT oi.*, mi.name as item_name, mi.price FROM offer_items oi JOIN menu_items mi ON oi.item_id=mi.id WHERE oi.offer_id=?");
            $items->execute([$offer['id']]);
            $offer['items'] = $items->fetchAll();
        }
        success($offers);

    // ─── ADMIN: Create offer ──────────────────────────────────
    case 'POST:create':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();

        $stmt = $db->prepare("INSERT INTO offers (name, description, type, price, valid_from, valid_until, is_active, sort_order) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $data['name'], $data['description'] ?? null,
            $data['type'] ?? 'combo', $data['price'] ?? null,
            $data['valid_from'] ?? null, $data['valid_until'] ?? null,
            1, $data['sort_order'] ?? 0
        ]);
        $offerId = $db->lastInsertId();

        // Add items to offer
        if (!empty($data['items'])) {
            foreach ($data['items'] as $item) {
                $db->prepare("INSERT INTO offer_items (offer_id, item_id, quantity) VALUES (?,?,?)")
                   ->execute([$offerId, $item['item_id'], $item['quantity'] ?? 1]);
            }
        }
        success(['id' => $offerId], 'تم إنشاء الأوفر', 201);

    // ─── ADMIN: Update offer ──────────────────────────────────
    case 'PUT:update':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();

        $db->prepare("UPDATE offers SET name=?, description=?, type=?, price=?, valid_from=?, valid_until=?, sort_order=? WHERE id=?")
           ->execute([$data['name'], $data['description'] ?? null, $data['type'] ?? 'combo', $data['price'] ?? null, $data['valid_from'] ?? null, $data['valid_until'] ?? null, $data['sort_order'] ?? 0, $id]);

        // Rebuild items
        if (isset($data['items'])) {
            $db->prepare("DELETE FROM offer_items WHERE offer_id=?")->execute([$id]);
            foreach ($data['items'] as $item) {
                $db->prepare("INSERT INTO offer_items (offer_id, item_id, quantity) VALUES (?,?,?)")
                   ->execute([$id, $item['item_id'], $item['quantity'] ?? 1]);
            }
        }
        success([], 'تم التحديث');

    // ─── ADMIN: Toggle offer ──────────────────────────────────
    case 'PUT:toggle':
        requireAuth();
        $id = $path[1] ?? null;
        $db = getDB();
        $db->prepare("UPDATE offers SET is_active = NOT is_active WHERE id=?")->execute([$id]);
        success([], 'تم التحديث');

    // ─── ADMIN: Delete offer ──────────────────────────────────
    case 'DELETE:delete':
        requireAuth();
        $id = $path[1] ?? null;
        $db = getDB();
        $db->prepare("DELETE FROM offers WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    // ─── Upload offer image ───────────────────────────────────
    case 'POST:upload-image':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id || empty($_FILES['image'])) error('Missing data');
        $url = uploadImage($_FILES['image'], 'offers');
        if (!$url) error('فشل رفع الصورة');
        getDB()->prepare("UPDATE offers SET image=? WHERE id=?")->execute([$url, $id]);
        success(['image' => $url], 'تم رفع الصورة');

    default:
        error('Action not found', 404);
}
