import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// ─── App Store ────────────────────────────────────────────────
export const useAppStore = create(
  persist(
    (set, get) => ({
      // Theme
      isDark: true,
      lang: 'ar',
      toggleTheme: () => {
        const next = !get().isDark
        set({ isDark: next })
        document.body.className = next ? 'dark' : 'light'
      },
      toggleLang: () => set(s => ({ lang: s.lang === 'ar' ? 'en' : 'ar' })),

      // Settings cache
      settings: null,
      branches: [],
      setSettings: (s) => set({ settings: s }),
      setBranches: (b) => set({ branches: b }),

      // Selected branch
      selectedBranch: null,
      setSelectedBranch: (b) => set({ selectedBranch: b }),

      // Customer
      customer: null,
      setCustomer: (c) => set({ customer: c }),
    }),
    {
      name: 'restaurant-app',
      partialize: (s) => ({ isDark: s.isDark, lang: s.lang, customer: s.customer }),
    }
  )
)

// ─── Cart Store ───────────────────────────────────────────────
// Each cart line has a unique `lineId` derived from item id + selected
// size + selected extras, so the same dish with different add-ons/sizes
// is kept as separate lines (and shown separately in the cart).
function buildLineId(item) {
  const sizeKey = item.size?.id ?? 'nosize'
  const extrasKey = (item.extras || []).map(e => e.id).sort((a,b)=>a-b).join('-') || 'noextras'
  return `${item.id}__${sizeKey}__${extrasKey}`
}

export const useCartStore = create(
  persist(
    (set, get) => ({
      items: [],
      coupon: null,
      discount: 0,

      // item: { id, name, price (base item price), image, size?: {id,size_name,price_addition}, extras?: [{id,name,price}], notes? }
      add: (item) => {
        const lineId = buildLineId(item)
        const items = get().items
        const ex = items.find(i => i.lineId === lineId)
        if (ex) {
          set({ items: items.map(i => i.lineId === lineId ? { ...i, qty: i.qty + 1 } : i) })
        } else {
          set({ items: [...items, { ...item, lineId, qty: 1 }] })
        }
      },

      remove: (lineId) => set(s => ({ items: s.items.filter(i => i.lineId !== lineId) })),

      setQty: (lineId, qty) => {
        if (qty <= 0) return get().remove(lineId)
        set(s => ({ items: s.items.map(i => i.lineId === lineId ? { ...i, qty } : i) }))
      },

      clear: () => set({ items: [], coupon: null, discount: 0 }),

      setCoupon: (code, discount) => set({ coupon: code, discount }),

      // Unit price = base price + size addition + sum of extras
      unitPrice: (item) => {
        const sizeAdd = parseFloat(item.size?.price_addition || 0)
        const extrasAdd = (item.extras || []).reduce((s, e) => s + parseFloat(e.price || 0), 0)
        return parseFloat(item.price || 0) + sizeAdd + extrasAdd
      },

      total: () => get().items.reduce((s, i) => s + get().unitPrice(i) * i.qty, 0),
      count: () => get().items.reduce((s, i) => s + i.qty, 0),
    }),
    {
      name: 'restaurant-cart',
      partialize: (s) => ({ items: s.items }),
    }
  )
)
