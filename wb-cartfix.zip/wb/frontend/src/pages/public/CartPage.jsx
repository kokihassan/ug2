import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore, useCartStore } from '../../store'
import { publicApi } from '../../api'
import { useT, Empty } from '../../components/ui'
import toast from 'react-hot-toast'

const STEPS = ['cart', 'details', 'confirm']

export default function CartPage() {
  const t = useT()
  const navigate = useNavigate()
  const { settings, branches, selectedBranch, customer, setCustomer } = useAppStore()
  const { items, setQty, remove, clear, coupon, discount, setCoupon, unitPrice } = useCartStore()
  const total = items.reduce((s, i) => s + unitPrice(i) * i.qty, 0)
  const count = items.reduce((s, i) => s + i.qty, 0)
  const [step, setStep] = useState(0)
  const [orderType, setOrderType] = useState('delivery')
  const [form, setForm] = useState({
    name: customer?.name || '',
    phone: customer?.whatsapp_number || '',
    address: '',
    area: '',
    notes: '',
    zone_id: '',
    branch_id: selectedBranch?.id || branches[0]?.id || '',
  })
  const [zones, setZones] = useState([])
  const [couponInput, setCouponInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const currency = settings?.currency || t('ج', 'EGP')
  const deliveryFee = zones.find(z => z.id == form.zone_id)?.delivery_price || 0
  const grandTotal = total + deliveryFee - discount

  useEffect(() => {
    if (form.branch_id) {
      const br = branches.find(b => b.id == form.branch_id)
      setZones(br?.zones?.filter(z => z.is_active) || [])
    }
  }, [form.branch_id, branches])

  const applyCoupon = async () => {
    if (!couponInput.trim()) return
    const res = await publicApi.validateCoupon({
      code: couponInput.toUpperCase(),
      subtotal: total,
      customer_id: customer?.id,
    })
    if (res.success) {
      setCoupon(couponInput.toUpperCase(), res.data.discount)
      toast.success(t(`✓ خصم ${res.data.discount} ${currency}`, `✓ Discount ${res.data.discount} ${currency} applied`))
    } else {
      toast.error(res.message || t('كوبون غير صالح', 'Invalid coupon'))
    }
  }

  const placeOrder = async () => {
    setLoading(true)
    setError('')
    if (!form.name.trim()) { setError(t('أدخل اسمك', 'Enter your name')); setLoading(false); return }
    if (!form.phone.trim()) { setError(t('أدخل رقم هاتفك', 'Enter phone number')); setLoading(false); return }
    if (orderType === 'delivery' && !form.zone_id) { setError(t('اختر منطقة التوصيل', 'Select delivery zone')); setLoading(false); return }
    if (orderType === 'delivery' && !form.address.trim()) { setError(t('أدخل عنوانك', 'Enter your address')); setLoading(false); return }

    // Get/create customer
    try {
      const cr = await publicApi.getOrCreateCustomer(form.phone)
      if (cr.success) {
        setCustomer(cr.data)
        await publicApi.updateCustomer({ name: form.name, phone: form.phone, whatsapp_number: form.phone })
      }
    } catch {}

    const res = await publicApi.createOrder({
      whatsapp_number: form.phone,
      branch_id: form.branch_id || 1,
      zone_id: form.zone_id || null,
      order_type: orderType,
      recipient_name: form.name,
      recipient_phone: form.phone,
      delivery_address: form.address,
      delivery_area: form.area,
      customer_notes: form.notes,
      coupon_code: coupon || null,
      is_for_self: 1,
      payment_method: 'cash',
      items: items.map(i => ({
        item_id: i.id,
        quantity: i.qty,
        size_id: i.size?.id || null,
        extras: (i.extras || []).map(e => e.id),
        notes: i.notes || '',
      })),
    })

    setLoading(false)
    if (res.success) {
      clear()
      navigate(`/track/${res.data.order_number}`, { state: { order: res.data } })
    } else {
      setError(res.message || t('حدث خطأ، حاول مرة تانية', 'Error, please try again'))
    }
  }

  if (count === 0 && step === 0) return (
    <div className="pt-24 min-h-screen flex items-center justify-center">
      <Empty icon="🛒" title={t('السلة فارغة', 'Cart is Empty')}
        desc={t('أضف أصناف من المنيو', 'Add items from the menu')}
        action={
          <button onClick={() => navigate('/menu')} className="btn-gold px-8 py-3 rounded-xl mt-2">
            {t('تصفح المنيو', 'Browse Menu')}
          </button>
        } />
    </div>
  )

  return (
    <div className="pt-20 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Step indicator */}
        <div className="flex items-center justify-center gap-3 mb-8">
          {[t('السلة','Cart'), t('بياناتك','Details'), t('تأكيد','Confirm')].map((label, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-black transition-all
                ${step > i ? 'bg-gold-500 text-obsidian-900' : step === i ? 'bg-gold-500/20 text-gold-400 border border-gold-500' : 'bg-obsidian-800 text-obsidian-500 border border-obsidian-700'}`}>
                {step > i ? '✓' : i + 1}
              </div>
              <span className={`text-sm font-semibold hidden sm:block ${step === i ? 'text-gold-400' : 'text-obsidian-500'}`}>{label}</span>
              {i < 2 && <div className="w-8 h-px bg-obsidian-700 mx-1" />}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6 items-start">
          {/* Main content */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {/* STEP 0: Cart */}
              {step === 0 && (
                <motion.div key="cart" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                  <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl overflow-hidden">
                    <div className="p-4 border-b border-obsidian-700 flex items-center justify-between">
                      <h2 className="font-black text-white">{t('سلة التسوق','Shopping Cart')}</h2>
                      <button onClick={clear} className="text-obsidian-500 hover:text-red-400 text-xs transition-colors">
                        {t('مسح الكل','Clear All')}
                      </button>
                    </div>
                    <div className="divide-y divide-obsidian-700">
                      {items.map(item => {
                        const unit = unitPrice(item)
                        return (
                        <div key={item.lineId} className="p-4 flex items-center gap-3">
                          {item.image
                            ? <img src={item.image} alt={item.name} className="w-14 h-14 rounded-xl object-cover flex-shrink-0" />
                            : <div className="w-14 h-14 bg-obsidian-700 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">🍽️</div>
                          }
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-white text-sm truncate">{item.name}</p>
                            {item.size && (
                              <p className="text-obsidian-400 text-xs mt-0.5">📏 {item.size.size_name}</p>
                            )}
                            {item.extras?.length > 0 && (
                              <p className="text-obsidian-400 text-xs mt-0.5 truncate">
                                ➕ {item.extras.map(e => e.name).join('، ')}
                              </p>
                            )}
                            {item.notes && (
                              <p className="text-gold-500/80 text-xs mt-0.5 truncate">📝 {item.notes}</p>
                            )}
                            <p className="gold-text text-sm font-bold mt-0.5">{unit.toFixed(0)} {currency}</p>
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <button onClick={() => setQty(item.lineId, item.qty - 1)}
                              className="w-7 h-7 rounded-full bg-obsidian-700 border border-obsidian-600 text-white flex items-center justify-center text-sm hover:bg-obsidian-600 transition-colors">−</button>
                            <span className="w-6 text-center font-bold text-white text-sm">{item.qty}</span>
                            <button onClick={() => setQty(item.lineId, item.qty + 1)}
                              className="w-7 h-7 rounded-full bg-gold-500 text-obsidian-900 flex items-center justify-center text-sm font-bold hover:bg-gold-400 transition-colors">+</button>
                            <button onClick={() => remove(item.lineId)} className="w-7 h-7 text-obsidian-600 hover:text-red-400 transition-colors flex items-center justify-center">✕</button>
                          </div>
                        </div>
                        )
                      })}
                    </div>
                    {/* Coupon */}
                    <div className="p-4 border-t border-obsidian-700">
                      <div className="flex gap-2">
                        <input value={couponInput} onChange={e => setCouponInput(e.target.value.toUpperCase())}
                          placeholder={t('كوبون خصم...','Coupon code...')}
                          className="flex-1 bg-obsidian-700 border border-obsidian-600 rounded-xl px-4 py-2 text-sm text-white placeholder-obsidian-500 outline-none focus:border-gold-600 font-mono tracking-widest font-inherit" />
                        <button onClick={applyCoupon} className="btn-ghost px-4 py-2 rounded-xl text-sm">
                          {t('تطبيق','Apply')}
                        </button>
                      </div>
                      {coupon && <p className="text-emerald-400 text-xs mt-2">✓ {coupon} — خصم {discount} {currency}</p>}
                    </div>
                  </div>
                  <button onClick={() => setStep(1)} className="btn-gold w-full py-4 rounded-xl mt-4 text-sm font-bold tracking-wide">
                    {t('التالي: بياناتك →','Next: Your Details →')}
                  </button>
                </motion.div>
              )}

              {/* STEP 1: Details */}
              {step === 1 && (
                <motion.div key="details" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                  <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 space-y-5">
                    <h2 className="font-black text-white text-lg">{t('بياناتك','Your Details')}</h2>
                    {/* Order type */}
                    <div className="grid grid-cols-2 gap-3">
                      {[['delivery', t('توصيل 🛵','Delivery 🛵')], ['takeaway', t('استلام 🥡','Takeaway 🥡')]].map(([type, label]) => (
                        <button key={type} onClick={() => setOrderType(type)}
                          className={`p-3 rounded-xl border-2 font-bold text-sm transition-all ${
                            orderType === type
                              ? 'bg-gold-500/10 border-gold-500 text-gold-400'
                              : 'bg-transparent border-obsidian-700 text-obsidian-400 hover:border-obsidian-600'
                          }`}>
                          {label}
                        </button>
                      ))}
                    </div>
                    {/* Name + Phone */}
                    <div className="grid grid-cols-2 gap-4">
                      {[[t('الاسم *','Name *'), 'name', 'text'], [t('الهاتف *','Phone *'), 'phone', 'tel']].map(([lbl, key, type]) => (
                        <div key={key}>
                          <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{lbl}</label>
                          <input type={type} value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
                            className="input-gold" />
                        </div>
                      ))}
                    </div>
                    {/* Delivery fields */}
                    {orderType === 'delivery' && (
                      <>
                        {branches.length > 1 && (
                          <div>
                            <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('الفرع','Branch')}</label>
                            <select value={form.branch_id} onChange={e => setForm(p => ({ ...p, branch_id: e.target.value, zone_id: '' }))}
                              className="input-gold">
                              {branches.filter(b => b.is_active).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                            </select>
                          </div>
                        )}
                        <div>
                          <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('منطقة التوصيل *','Delivery Zone *')}</label>
                          <select value={form.zone_id} onChange={e => setForm(p => ({ ...p, zone_id: e.target.value }))}
                            className="input-gold">
                            <option value="">{t('اختر منطقة','Select zone')}</option>
                            {zones.map(z => (
                              <option key={z.id} value={z.id}>
                                {z.zone_name} — {z.delivery_price} {currency} / {z.delivery_time_minutes} {t('د','min')}
                              </option>
                            ))}
                          </select>
                          {zones.length === 0 && <p className="text-obsidian-500 text-xs mt-1">{t('لا توجد مناطق توصيل لهذا الفرع','No delivery zones for this branch')}</p>}
                        </div>
                        <div>
                          <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('العنوان *','Address *')}</label>
                          <input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))}
                            className="input-gold" placeholder={t('الشارع، المبنى، الشقة','Street, Building, Apt')} />
                        </div>
                      </>
                    )}
                    <div>
                      <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('ملاحظات (اختياري)','Notes (optional)')}</label>
                      <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
                        rows={2} className="input-gold resize-none" placeholder={t('أي تعليمات خاصة...','Any special instructions...')} />
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button onClick={() => setStep(0)} className="btn-ghost px-6 py-3 rounded-xl text-sm">← {t('رجوع','Back')}</button>
                    <button onClick={() => setStep(2)} className="btn-gold flex-1 py-3 rounded-xl text-sm font-bold">
                      {t('مراجعة الطلب →','Review Order →')}
                    </button>
                  </div>
                </motion.div>
              )}

              {/* STEP 2: Confirm */}
              {step === 2 && (
                <motion.div key="confirm" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                  <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 space-y-4">
                    <h2 className="font-black text-white text-lg">{t('مراجعة الطلب','Order Review')}</h2>
                    {/* Customer info */}
                    <div className="bg-obsidian-700/50 rounded-xl p-4 space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-obsidian-400">{t('النوع','Type')}</span><span className="font-bold text-white">{orderType === 'delivery' ? t('توصيل 🛵','Delivery 🛵') : t('استلام 🥡','Takeaway 🥡')}</span></div>
                      <div className="flex justify-between"><span className="text-obsidian-400">{t('الاسم','Name')}</span><span className="font-bold text-white">{form.name}</span></div>
                      <div className="flex justify-between"><span className="text-obsidian-400">{t('الهاتف','Phone')}</span><span className="font-bold text-white">{form.phone}</span></div>
                      {form.address && <div className="flex justify-between"><span className="text-obsidian-400">{t('العنوان','Address')}</span><span className="font-bold text-white text-end max-w-[60%]">{form.address}</span></div>}
                      {zones.find(z => z.id == form.zone_id) && (
                        <div className="flex justify-between"><span className="text-obsidian-400">{t('المنطقة','Zone')}</span><span className="font-bold text-white">{zones.find(z => z.id == form.zone_id)?.zone_name}</span></div>
                      )}
                    </div>
                    {/* Items */}
                    <div className="border-t border-obsidian-700 pt-4 space-y-2">
                      {items.map(i => (
                        <div key={i.lineId} className="flex justify-between text-sm gap-2">
                          <div className="min-w-0">
                            <span className="text-obsidian-300">{i.qty}× {i.name}</span>
                            {i.size && <span className="text-obsidian-500 text-xs"> ({i.size.size_name})</span>}
                            {i.extras?.length > 0 && (
                              <div className="text-obsidian-500 text-xs">+ {i.extras.map(e=>e.name).join('، ')}</div>
                            )}
                          </div>
                          <span className="font-bold text-white whitespace-nowrap">{(unitPrice(i) * i.qty).toFixed(0)} {currency}</span>
                        </div>
                      ))}
                    </div>
                    {/* Totals */}
                    <div className="border-t border-obsidian-700 pt-4 space-y-2 text-sm">
                      {deliveryFee > 0 && <div className="flex justify-between text-obsidian-400"><span>{t('التوصيل','Delivery')}</span><span>{deliveryFee} {currency}</span></div>}
                      {discount > 0 && <div className="flex justify-between text-emerald-400 font-semibold"><span>{t('خصم','Discount')}</span><span>-{discount} {currency}</span></div>}
                      <div className="flex justify-between items-center pt-2 border-t border-obsidian-700">
                        <span className="font-black text-white text-lg">{t('الإجمالي','Total')}</span>
                        <span className="gold-text font-black text-2xl">{grandTotal} {currency}</span>
                      </div>
                    </div>
                    {form.notes && (
                      <div className="bg-gold-900/20 border border-gold-800/30 rounded-xl p-3 text-sm">
                        <span className="text-gold-400 font-bold">📝 </span>
                        <span className="text-obsidian-300">{form.notes}</span>
                      </div>
                    )}
                  </div>
                  {error && <div className="bg-red-900/20 border border-red-800 rounded-xl p-3 text-red-400 text-sm mt-3">⚠️ {error}</div>}
                  <div className="flex gap-3 mt-4">
                    <button onClick={() => setStep(1)} className="btn-ghost px-6 py-3 rounded-xl text-sm">← {t('رجوع','Back')}</button>
                    <button onClick={placeOrder} disabled={loading}
                      className="btn-gold flex-1 py-4 rounded-xl text-sm font-bold disabled:opacity-50">
                      {loading ? t('⏳ جاري الإرسال...','⏳ Placing Order...') : `✅ ${t('تأكيد الطلب','Confirm Order')}`}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Order summary sidebar */}
          <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 sticky top-28">
            <h3 className="text-sm font-black text-obsidian-300 mb-4 uppercase tracking-wide">{t('ملخص الطلب','Order Summary')}</h3>
            <div className="space-y-2 mb-4">
              {items.map(i => (
                <div key={i.lineId} className="flex justify-between text-xs">
                  <span className="text-obsidian-400 truncate flex-1 me-2">{i.qty}× {i.name}</span>
                  <span className="text-white font-semibold flex-shrink-0">{(unitPrice(i) * i.qty).toFixed(0)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-obsidian-700 pt-3 space-y-1.5 text-xs">
              {deliveryFee > 0 && <div className="flex justify-between text-obsidian-400"><span>{t('توصيل','Delivery')}</span><span>{deliveryFee}</span></div>}
              {discount > 0 && <div className="flex justify-between text-emerald-400"><span>{t('خصم','Disc')}</span><span>-{discount}</span></div>}
              <div className="flex justify-between items-center pt-2 border-t border-obsidian-700">
                <span className="font-black text-white">{t('الإجمالي','Total')}</span>
                <span className="gold-text font-black text-xl">{grandTotal} {currency}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
