import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAppStore, useCartStore } from '../../store'
import { publicApi } from '../../api'
import { useT, GoldDivider, SkeletonCard } from '../../components/ui'
import toast from 'react-hot-toast'

export default function HomePage() {
  const t = useT()
  const navigate = useNavigate()
  const { settings, branches, selectedBranch, setSelectedBranch } = useAppStore()
  const add = useCartStore(s => s.add)
  const [featured, setFeatured] = useState([])
  const [newItems, setNewItems] = useState([])
  const [offers, setOffers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      publicApi.getMenu(selectedBranch?.id || 1),
      publicApi.getOffers(),
    ]).then(([menuRes, offersRes]) => {
      if (menuRes.success) {
        const all = menuRes.data.flatMap(c => (c.items || []))
        setFeatured(all.filter(i => i.is_featured))
        setNewItems(all.filter(i => i.is_new).slice(0, 4))
      }
      if (offersRes.success) setOffers(offersRes.data || [])
      setLoading(false)
    })
  }, [selectedBranch])

  const handleAdd = (item) => {
    add({ id: item.id, name: item.name, price: parseFloat(item.final_price || item.price), image: item.image })
    toast.success(t(`تم إضافة ${item.name} للسلة`, `${item.name} added to cart`))
  }

  return (
    <div>
      {/* ── Hero ── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* BG effects */}
        <div className="absolute inset-0 bg-dark-gradient" />
        <div className="absolute inset-0 opacity-[0.04]"
          style={{ backgroundImage: 'repeating-linear-gradient(90deg,#c9a84c 0,#c9a84c 1px,transparent 1px,transparent 80px),repeating-linear-gradient(0deg,#c9a84c 0,#c9a84c 1px,transparent 1px,transparent 80px)' }} />
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full opacity-10 pointer-events-none"
          style={{ background: 'radial-gradient(circle, #c9a84c 0%, transparent 70%)' }} />

        <div className="relative z-10 text-center max-w-3xl mx-auto px-6">
          {/* Ornament */}
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="text-gold-600 text-2xl tracking-[12px] mb-8 opacity-60">✦ ✦ ✦</motion.div>

          {/* Restaurant name */}
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.8 }}
            className="gold-text font-display text-6xl sm:text-8xl font-light italic mb-6 leading-none tracking-tight">
            {settings?.name || t('مطعمنا', 'Our Restaurant')}
          </motion.h1>

          {/* Tagline */}
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
            className="text-obsidian-400 text-lg sm:text-xl leading-relaxed max-w-xl mx-auto mb-10 font-light">
            {t(
              'تجربة طعام راقية تجمع بين الأصالة والحداثة — نختار أجود المكونات لنقدم لك لحظات لا تُنسى',
              'A luxury dining experience bridging tradition and modernity — only the finest for unforgettable moments'
            )}
          </motion.p>

          {/* CTAs */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}
            className="flex flex-wrap gap-4 justify-center">
            <button onClick={() => navigate('/menu')}
              className="btn-gold px-10 py-4 rounded-sm text-sm tracking-[3px] uppercase font-bold">
              {t('اكتشف المنيو', 'Explore Menu')}
            </button>
            <button onClick={() => navigate('/cart')}
              className="btn-ghost px-10 py-4 rounded-sm text-sm tracking-[3px] uppercase font-bold">
              {t('اطلب الآن', 'Order Now')}
            </button>
          </motion.div>

          {/* Branch badges */}
          {branches.length > 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}
              className="flex flex-wrap gap-3 justify-center mt-12">
              {branches.filter(b => b.is_active).map(b => (
                <div key={b.id}
                  className="bg-obsidian-800/80 border border-obsidian-700 rounded-full px-5 py-2 text-xs text-obsidian-400 flex items-center gap-2">
                  <span className="text-gold-500">📍</span> {b.name}
                </div>
              ))}
            </motion.div>
          )}
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-obsidian-600 text-[10px] tracking-[4px] uppercase anim-pulse">
          <span>{t('اسحب للأسفل', 'Scroll Down')}</span>
          <span>↓</span>
        </div>
      </section>

      {/* ── Stats bar ── */}
      <section className="bg-obsidian-900 border-y border-obsidian-800 py-10">
        <div className="max-w-4xl mx-auto px-6 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
          {[
            ['🏪', t('فرعين', '2 Branches'), t('في أفضل المناطق', 'Prime Locations')],
            ['🍽️', t('+٥٠ صنف', '50+ Dishes'), t('متنوعة ومتجددة', 'Fresh & Diverse')],
            ['🛵', t('توصيل سريع', 'Fast Delivery'), t('٣٠-٦٠ دقيقة', '30-60 Minutes')],
            ['🤖', t('AI مساعد', 'AI Assistant'), t('متاح ٢٤/٧', 'Available 24/7')],
          ].map(([icon, val, desc], i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }} viewport={{ once: true }}>
              <div className="text-3xl mb-2">{icon}</div>
              <div className="gold-text text-lg font-black mb-1">{val}</div>
              <div className="text-obsidian-500 text-xs">{desc}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── Featured ── */}
      {(loading || featured.length > 0) && (
        <section className="max-w-7xl mx-auto px-6 py-20">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-center mb-12">
            <p className="text-gold-600 text-xs tracking-[4px] uppercase mb-3">{t('اختيار الشيف', "Chef's Pick")}</p>
            <h2 className="section-title text-3xl sm:text-4xl font-display font-light italic text-white">
              {t('الأكثر طلباً', 'Most Popular')}
            </h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {loading
              ? Array(4).fill(0).map((_, i) => <SkeletonCard key={i} />)
              : featured.slice(0, 4).map((item, i) => (
                <motion.div key={item.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }} viewport={{ once: true }}>
                  <ItemCard item={item} onAdd={() => handleAdd(item)} />
                </motion.div>
              ))
            }
          </div>
          <div className="text-center mt-10">
            <button onClick={() => navigate('/menu')} className="btn-ghost px-8 py-3 rounded-sm text-sm tracking-[2px] uppercase">
              {t('عرض المنيو كامل', 'View Full Menu')}
            </button>
          </div>
        </section>
      )}

      {/* ── Offers ── */}
      {offers.length > 0 && (
        <section className="bg-obsidian-900 border-y border-obsidian-800 py-20">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
              className="text-center mb-12">
              <p className="text-gold-600 text-xs tracking-[4px] uppercase mb-3">{t('عروض حصرية', 'Exclusive Deals')}</p>
              <h2 className="section-title text-3xl sm:text-4xl font-display font-light italic text-white">
                {t('العروض والكومبو', 'Offers & Combos')}
              </h2>
            </motion.div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {offers.map((offer, i) => (
                <motion.div key={offer.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }} viewport={{ once: true }}
                  className="card overflow-hidden">
                  {offer.image
                    ? <img src={offer.image} alt={offer.name} className="w-full h-44 object-cover" />
                    : <div className="w-full h-44 bg-gradient-to-br from-gold-900/30 to-obsidian-800 flex items-center justify-center text-5xl">🎁</div>
                  }
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-black text-white">{offer.name}</h3>
                      {offer.price && <span className="gold-text font-black text-lg whitespace-nowrap">{parseFloat(offer.price).toFixed(0)} {t('ج','EGP')}</span>}
                    </div>
                    {offer.description && <p className="text-obsidian-400 text-sm leading-relaxed">{offer.description}</p>}
                    {(offer.items || []).length > 0 && (
                      <div className="mt-3 space-y-1">
                        {offer.items.map((it, j) => (
                          <div key={j} className="text-xs text-obsidian-500 flex items-center gap-2">
                            <span className="text-gold-600">✦</span> {it.quantity}× {it.name}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── New items ── */}
      {newItems.length > 0 && (
        <section className="max-w-7xl mx-auto px-6 py-20">
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            className="text-center mb-12">
            <p className="text-gold-600 text-xs tracking-[4px] uppercase mb-3">{t('وصل حديثاً', 'Just Arrived')}</p>
            <h2 className="section-title text-3xl sm:text-4xl font-display font-light italic text-white">
              {t('الجديد في المنيو', 'New on the Menu')}
            </h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newItems.map((item, i) => (
              <motion.div key={item.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }} viewport={{ once: true }}>
                <ItemCard item={item} onAdd={() => handleAdd(item)} />
              </motion.div>
            ))}
          </div>
        </section>
      )}

      <GoldDivider />
    </div>
  )
}

// ─── Item Card ────────────────────────────────────────────────
function ItemCard({ item, onAdd }) {
  const t = useT()
  const navigate = useNavigate()
  const { settings } = useAppStore()
  const [adding, setAdding] = useState(false)
  const hasOptions = (item.extras?.length > 0) || (item.sizes?.length > 0)

  const handleAdd = () => {
    if (hasOptions) { navigate('/menu'); return }
    setAdding(true)
    onAdd()
    setTimeout(() => setAdding(false), 700)
  }

  return (
    <div className="card overflow-hidden group">
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        {item.image
          ? <img src={item.image} alt={item.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          : <div className="w-full h-full bg-gradient-to-br from-obsidian-700 to-obsidian-800 flex items-center justify-center text-5xl">🍽️</div>
        }
        {/* Tags */}
        <div className="absolute top-2 start-2 flex gap-1 flex-wrap">
          {item.is_featured === 1 && <span className="badge-gold">⭐ {t('مميز','TOP')}</span>}
          {item.is_new === 1 && <span className="badge-gold badge-new">{t('جديد','NEW')}</span>}
          {item.is_spicy === 1 && <span className="badge-gold badge-spicy">🌶️</span>}
        </div>
        {/* Unavailable */}
        {item.branch_available === 0 && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="bg-red-600 text-white px-4 py-1.5 rounded text-sm font-bold">{t('غير متاح','Unavailable')}</span>
          </div>
        )}
      </div>
      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-white leading-tight flex-1">{item.name}</h3>
          <span className="gold-text font-black text-lg whitespace-nowrap">
            {parseFloat(item.final_price || item.price).toFixed(0)} {settings?.currency || t('ج','EGP')}
          </span>
        </div>
        {item.description && (
          <p className="text-obsidian-400 text-xs leading-relaxed mb-3 truncate-2">{item.description}</p>
        )}
        <div className="flex items-center justify-between">
          <span className="text-obsidian-500 text-xs">⏱️ {item.preparation_time_minutes} {t('د','min')}</span>
          <motion.button whileTap={{ scale: 0.95 }} onClick={handleAdd}
            disabled={item.branch_available === 0}
            className={`btn-gold px-4 py-2 rounded-lg text-xs font-bold transition-all ${item.branch_available === 0 ? 'opacity-40 cursor-not-allowed' : ''}`}>
            {adding ? '✓' : hasOptions ? t('عرض الخيارات','View Options') : t('أضف للسلة', 'Add to Cart')}
          </motion.button>
        </div>
      </div>
    </div>
  )
}
