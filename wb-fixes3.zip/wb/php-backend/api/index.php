<?php
require_once __DIR__ . '/../config.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = preg_replace('#^/api/?#', '', $uri);
$uri = trim($uri, '/');
$parts = explode('/', $uri);
$resource = $parts[0] ?? '';
$action   = implode('/', array_slice($parts, 1));
$_GET['action'] = $action;

switch ($resource) {
    case 'menu':      require __DIR__.'/menu.php';      break;
    case 'orders':    require __DIR__.'/orders.php';    break;
    case 'branches':  require __DIR__.'/branches.php';  break;
    case 'customers': require __DIR__.'/customers.php'; break;
    case 'coupons':   require __DIR__.'/coupons.php';   break;
    case 'settings':  require __DIR__.'/settings.php';  break;
    case 'auth':      require __DIR__.'/auth.php';      break;
    case 'offers':    require __DIR__.'/offers.php';    break;
    case 'reports':   require __DIR__.'/reports.php';   break;
    case 'ai':        require __DIR__.'/ai.php';        break;
    case 'health':
        success(['status' => 'ok', 'time' => date('Y-m-d H:i:s')]);
        break;
    default:
        error('Not found: ' . $uri, 404);
}
