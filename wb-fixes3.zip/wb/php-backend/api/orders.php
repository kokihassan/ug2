<?php
// api/orders.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {

    // ─── PUBLIC: Track an order by order_number ────────────────────
    case 'GET:track':
        $orderNumber = $path[1] ?? ($_GET['order_number'] ?? null);
        if (!$orderNumber) error('order_number مطلوب');
        $db = getDB();
        $stmt = $db->prepare("SELECT id, order_number, status, total_amount, estimated_time,
                order_type, delivery_address, created_at, confirmed_at, preparing_at,
                ready_at, dispatched_at, delivered_at, cancelled_at, cancel_reason
            FROM orders WHERE order_number=?");
        $stmt->execute([$orderNumber]);
        $order = $stmt->fetch();
        if (!$order) error('الطلب غير موجود', 404);
        success($order);

    // ─── Create Order (requires customer login) ─────────────────────
    case 'POST:create':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();

        // Require a logged-in customer account
        $authCustomerId = optionalCustomerAuth();
        if (!$authCustomerId) error('يجب تسجيل الدخول لإتمام الطلب', 401);

        $stmt = $db->prepare("SELECT * FROM customers WHERE id=?");
        $stmt->execute([$authCustomerId]);
        $customer = $stmt->fetch();
        if (!$customer) error('الحساب غير موجود', 404);
        if ($customer['is_blacklisted']) error('عذراً، لا يمكن قبول طلبك حالياً');
        
        // Validate zone if delivery
        $zoneId = null;
        $deliveryFee = 0;
        $estimatedTime = 30;
        
        if ($data['order_type'] === 'delivery') {
            $stmt = $db->prepare("SELECT * FROM delivery_zones WHERE id=? AND is_active=1");
            $stmt->execute([$data['zone_id']]);
            $zone = $stmt->fetch();
            if (!$zone) error('منطقة التوصيل غير متاحة');
            $zoneId = $zone['id'];
            $deliveryFee = $zone['delivery_price'];
            $estimatedTime = $zone['delivery_time_minutes'];
        }
        
        // Check peak hours - add extra time
        $peakStmt = $db->prepare("SELECT extra_delivery_time FROM peak_hours 
            WHERE is_active=1 
            AND (branch_id=? OR branch_id IS NULL)
            AND (day_of_week=DAYOFWEEK(NOW())-1 OR day_of_week IS NULL)
            AND start_time <= TIME(NOW()) AND end_time >= TIME(NOW())
            LIMIT 1");
        $peakStmt->execute([$data['branch_id']]);
        $peak = $peakStmt->fetch();
        if ($peak) $estimatedTime += $peak['extra_delivery_time'];
        
        // Calculate totals
        $subtotal = 0;
        $orderItems = [];
        
        foreach ($data['items'] as $item) {
            $stmt = $db->prepare("SELECT * FROM menu_items WHERE id=?");
            $stmt->execute([$item['item_id']]);
            $menuItem = $stmt->fetch();
            if (!$menuItem) continue;
            
            // Check branch availability
            $avail = $db->prepare("SELECT is_available, override_price FROM item_branch_availability WHERE item_id=? AND branch_id=?");
            $avail->execute([$item['item_id'], $data['branch_id']]);
            $branchAvail = $avail->fetch();
            if ($branchAvail && !$branchAvail['is_available']) continue;
            
            $price = $branchAvail['override_price'] ?? $menuItem['price'];
            $extrasPrice = 0;
            $extrasData = [];
            $sizeAddition = 0;
            $sizeName = null;

            // Apply size price addition
            if (!empty($item['size_id'])) {
                $sizeStmt = $db->prepare("SELECT * FROM item_sizes WHERE id=? AND item_id=?");
                $sizeStmt->execute([$item['size_id'], $item['item_id']]);
                $sizeData = $sizeStmt->fetch();
                if ($sizeData) {
                    $sizeAddition = $sizeData['price_addition'];
                    $sizeName = $sizeData['size_name'];
                }
            }

            // Calculate extras
            if (!empty($item['extras'])) {
                foreach ($item['extras'] as $extraId) {
                    $extra = $db->prepare("SELECT * FROM item_extras WHERE id=? AND item_id=?");
                    $extra->execute([$extraId, $item['item_id']]);
                    $extraData = $extra->fetch();
                    if ($extraData) {
                        $extrasPrice += $extraData['price'];
                        $extrasData[] = $extraData['name'] . ' (+' . $extraData['price'] . ')';
                    }
                }
            }

            $itemTotal = ($price + $sizeAddition + $extrasPrice) * $item['quantity'];
            $subtotal += $itemTotal;

            $orderItems[] = [
                'item_id' => $item['item_id'],
                'item_name' => $menuItem['name'],
                'size_name' => $sizeName ?? ($item['size_name'] ?? null),
                'quantity' => $item['quantity'],
                'unit_price' => $price + $sizeAddition,
                'extras_price' => $extrasPrice,
                'total_price' => $itemTotal,
                'extras' => json_encode($extrasData, JSON_UNESCAPED_UNICODE),
                'notes' => $item['notes'] ?? null,
            ];
        }
        
        if (empty($orderItems)) error('لا توجد أصناف صالحة في الطلب');
        
        // Apply coupon
        $discountAmount = 0;
        $couponId = null;
        if (!empty($data['coupon_code'])) {
            $coup = $db->prepare("SELECT * FROM coupons WHERE code=? AND is_active=1 
                AND (valid_from IS NULL OR valid_from<=NOW()) 
                AND (valid_until IS NULL OR valid_until>=NOW())
                AND (usage_limit IS NULL OR used_count < usage_limit)");
            $coup->execute([$data['coupon_code']]);
            $coupon = $coup->fetch();
            // Personal coupons can only be used by their assigned customer
            $couponOk = $coupon && (empty($coupon['customer_id']) || (int)$coupon['customer_id'] === (int)$customer['id']);
            if ($couponOk && $subtotal >= $coupon['min_order_amount']) {
                if ($coupon['type'] === 'percentage') {
                    $discountAmount = $subtotal * ($coupon['value'] / 100);
                    if ($coupon['max_discount']) $discountAmount = min($discountAmount, $coupon['max_discount']);
                } else {
                    $discountAmount = $coupon['value'];
                }
                $discountAmount = min($discountAmount, $subtotal);
                $couponId = $coupon['id'];
            }
        }

        // Get settings for tax
        $settings = $db->query("SELECT * FROM restaurant_settings LIMIT 1")->fetch();
        $taxAmount = ($subtotal - $discountAmount) * ($settings['tax_percentage'] / 100);
        $totalBeforeBalance = $subtotal + $deliveryFee - $discountAmount + $taxAmount;

        // Apply wallet balance (customer can choose to use available credit)
        $balanceUsed = 0;
        if (!empty($data['use_balance']) && $customer['balance'] > 0) {
            $balanceUsed = min((float)$customer['balance'], $totalBeforeBalance);
        }
        $totalAmount = $totalBeforeBalance - $balanceUsed;
        
        // Create order
        $orderNumber = generateOrderNumber();
        $stmt = $db->prepare("INSERT INTO orders 
            (order_number, customer_id, branch_id, zone_id, order_type, status,
             recipient_name, recipient_phone, delivery_address, delivery_area,
             delivery_notes, subtotal, delivery_fee, discount_amount, balance_used, tax_amount,
             total_amount, payment_method, coupon_id, coupon_code, estimated_time,
             customer_notes, is_for_self)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $orderNumber, $customer['id'], $data['branch_id'], $zoneId,
            $data['order_type'], 'new',
            $data['recipient_name'] ?? $customer['name'],
            $data['recipient_phone'] ?? $customer['whatsapp_number'],
            $data['delivery_address'] ?? null,
            $data['delivery_area'] ?? null,
            $data['delivery_notes'] ?? null,
            $subtotal, $deliveryFee, $discountAmount, $balanceUsed, $taxAmount, $totalAmount,
            $data['payment_method'] ?? 'cash',
            $couponId, $data['coupon_code'] ?? null,
            $estimatedTime, $data['customer_notes'] ?? null,
            $data['is_for_self'] ?? 1
        ]);
        
        $orderId = $db->lastInsertId();

        // Deduct used balance from wallet
        if ($balanceUsed > 0) {
            $db->prepare("UPDATE customers SET balance = balance - ? WHERE id=?")->execute([$balanceUsed, $customer['id']]);
            $db->prepare("INSERT INTO balance_transactions (customer_id, amount, reason, order_id, created_by) VALUES (?,?,?,?,?)")
               ->execute([$customer['id'], -$balanceUsed, 'استخدام في الطلب '.$orderNumber, $orderId, 'order']);
        }
        
        // Insert order items
        foreach ($orderItems as $oi) {
            $stmt = $db->prepare("INSERT INTO order_items 
                (order_id, item_id, item_name, size_name, quantity, unit_price, extras_price, total_price, extras, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$orderId, $oi['item_id'], $oi['item_name'], $oi['size_name'],
                $oi['quantity'], $oi['unit_price'], $oi['extras_price'], $oi['total_price'],
                $oi['extras'], $oi['notes']]);
            
            // Update item order count
            $db->prepare("UPDATE menu_items SET total_orders=total_orders+? WHERE id=?")
               ->execute([$oi['quantity'], $oi['item_id']]);
        }
        
        // Update coupon usage
        if ($couponId) {
            $db->prepare("UPDATE coupons SET used_count=used_count+1 WHERE id=?")->execute([$couponId]);
            $db->prepare("INSERT INTO coupon_usage (coupon_id, customer_id, order_id, discount_amount) VALUES (?,?,?,?)")
               ->execute([$couponId, $customer['id'], $orderId, $discountAmount]);
        }
        
        // Update customer stats
        $db->prepare("UPDATE customers SET total_orders=total_orders+1, total_spent=total_spent+?, last_order_at=NOW() WHERE id=?")
           ->execute([$totalAmount, $customer['id']]);
        
        // Get branch notification number
        $branch = $db->prepare("SELECT * FROM branches WHERE id=?");
        $branch->execute([$data['branch_id']]);
        $branchData = $branch->fetch();
        
        // Notify branch
        $notifyMsg = "🔔 طلب جديد!\n";
        $notifyMsg .= "رقم: $orderNumber\n";
        $notifyMsg .= "نوع: " . ($data['order_type'] === 'delivery' ? 'توصيل' : 'تيك أواي') . "\n";
        $notifyMsg .= "الإجمالي: $totalAmount {$settings['currency']}\n";
        $notifyMsg .= "العميل: {$customer['name']} - {$customer['whatsapp_number']}";
        
        if ($branchData['whatsapp_number']) {
            sendWhatsApp($branchData['whatsapp_number'], $notifyMsg);
        }
        
        // Log notification
        $db->prepare("INSERT INTO notifications (type, target, message, order_id, status) VALUES ('new_order',?,?,?,'sent')")
           ->execute([$branchData['whatsapp_number'], $notifyMsg, $orderId]);
        
        success([
            'order_id' => $orderId,
            'order_number' => $orderNumber,
            'total' => $totalAmount,
            'balance_used' => $balanceUsed,
            'remaining_balance' => (float)$customer['balance'] - $balanceUsed,
            'estimated_time' => $estimatedTime,
            'currency' => $settings['currency']
        ], 'تم إنشاء الطلب بنجاح', 201);

    // ─── ADMIN: Get orders list ───────────────────────────────────
    case 'GET:list':
        requireAuth();
        $db = getDB();
        $status = $_GET['status'] ?? null;
        $branchId = $_GET['branch_id'] ?? null;
        $date = $_GET['date'] ?? date('Y-m-d');
        $page = intval($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT o.*, c.name as customer_name, c.whatsapp_number,
                b.name as branch_name, dz.zone_name
                FROM orders o 
                JOIN customers c ON o.customer_id=c.id
                JOIN branches b ON o.branch_id=b.id
                LEFT JOIN delivery_zones dz ON o.zone_id=dz.id
                WHERE DATE(o.created_at)=?";
        $params = [$date];
        
        if ($status) { $sql .= " AND o.status=?"; $params[] = $status; }
        if ($branchId) { $sql .= " AND o.branch_id=?"; $params[] = $branchId; }
        $sql .= " ORDER BY o.created_at DESC LIMIT $limit OFFSET $offset";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $orders = $stmt->fetchAll();
        
        foreach ($orders as &$order) {
            $items = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
            $items->execute([$order['id']]);
            $orderItems = $items->fetchAll();
            foreach ($orderItems as &$oi) {
                $oi['extras'] = !empty($oi['extras']) ? json_decode($oi['extras'], true) : [];
            }
            $order['items'] = $orderItems;
        }
        
        // Count totals
        $countSql = str_replace("SELECT o.*, c.name as customer_name, c.whatsapp_number, b.name as branch_name, dz.zone_name", "SELECT COUNT(*)", explode("ORDER BY", $sql)[0]);
        $countStmt = $db->prepare($countSql);
        $countStmt->execute($params);
        
        success(['orders' => $orders, 'page' => $page, 'limit' => $limit]);

    // ─── ADMIN: Update order status ───────────────────────────────
    // ─── ADMIN: Internal notes for an order ─────────────────────────
    case 'GET:notes':
        requireAuth();
        $orderId = $path[1] ?? null;
        if (!$orderId) error('Missing order ID');
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM order_notes WHERE order_id=? ORDER BY created_at DESC");
        $stmt->execute([$orderId]);
        success($stmt->fetchAll());

    case 'POST:notes':
        $auth = requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['order_id']) || empty($data['note'])) error('بيانات ناقصة');
        $db = getDB();
        $db->prepare("INSERT INTO order_notes (order_id, note, created_by) VALUES (?,?,?)")
           ->execute([$data['order_id'], $data['note'], $auth['email'] ?? 'admin']);
        success([], 'تمت إضافة الملاحظة', 201);

    case 'PUT:status':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        $statusFields = [
            'confirmed'        => 'confirmed_at',
            'preparing'        => 'preparing_at',
            'ready'            => 'ready_at',
            'out_for_delivery' => 'dispatched_at',
            'delivered'        => 'delivered_at',
            'cancelled'        => 'cancelled_at',
        ];
        
        $timeField = $statusFields[$data['status']] ?? null;
        $sql = "UPDATE orders SET status=?, admin_notes=?";
        $params = [$data['status'], $data['admin_notes'] ?? null];
        
        if ($timeField) { $sql .= ", $timeField=NOW()"; }
        if ($data['status'] === 'cancelled' && !empty($data['cancel_reason'])) {
            $sql .= ", cancel_reason=?";
            $params[] = $data['cancel_reason'];
        }
        
        $sql .= " WHERE id=?";
        $params[] = $id;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        // Get order details to notify customer
        $order = $db->prepare("SELECT o.*, c.whatsapp_number, c.name as customer_name 
            FROM orders o JOIN customers c ON o.customer_id=c.id WHERE o.id=?");
        $order->execute([$id]);
        $orderData = $order->fetch();
        
        // Send WhatsApp notification to customer
        $statusMessages = [
            'confirmed'        => "✅ تم تأكيد طلبك رقم {$orderData['order_number']}!\nوقت التوصيل المتوقع: {$orderData['estimated_time']} دقيقة 🕐",
            'preparing'        => "👨‍🍳 طلبك رقم {$orderData['order_number']} قيد التحضير الآن!",
            'ready'            => "✨ طلبك رقم {$orderData['order_number']} جاهز!",
            'out_for_delivery' => "🛵 طلبك رقم {$orderData['order_number']} في الطريق إليك!",
            'delivered'        => "🎉 تم تسليم طلبك رقم {$orderData['order_number']}!\nنتمنى تكون استمتعت بوجبتك 😊\nقيّمنا من 1 إلى 5: أرسل رقم التقييم",
            'cancelled'        => "❌ تم إلغاء طلبك رقم {$orderData['order_number']}.\nالسبب: " . ($data['cancel_reason'] ?? 'غير محدد'),
        ];
        
        if (isset($statusMessages[$data['status']]) && $orderData['whatsapp_number']) {
            sendWhatsApp($orderData['whatsapp_number'], $statusMessages[$data['status']]);
            $db->prepare("INSERT INTO notifications (type, target, message, order_id, status) VALUES ('order_status',?,?,?,'sent')")
               ->execute([$orderData['whatsapp_number'], $statusMessages[$data['status']], $id]);
        }
        
        success([], 'تم تحديث الحالة');

    // ─── ADMIN: Order stats/dashboard ────────────────────────────
    case 'GET:stats':
        requireAuth();
        $db = getDB();
        $date = $_GET['date'] ?? date('Y-m-d');
        
        $stats = [];
        
        // Today's totals
        $stmt = $db->prepare("SELECT 
            COUNT(*) as total_orders,
            SUM(total_amount) as total_revenue,
            SUM(CASE WHEN order_type='delivery' THEN 1 ELSE 0 END) as delivery_count,
            SUM(CASE WHEN order_type='takeaway' THEN 1 ELSE 0 END) as takeaway_count,
            SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) as cancelled_count,
            AVG(total_amount) as avg_order_value
            FROM orders WHERE DATE(created_at)=?");
        $stmt->execute([$date]);
        $stats['today'] = $stmt->fetch();

        // Yesterday (or day before the selected date) for comparison
        $prevDate = date('Y-m-d', strtotime($date . ' -1 day'));
        $stmt = $db->prepare("SELECT 
            COUNT(*) as total_orders,
            SUM(total_amount) as total_revenue
            FROM orders WHERE DATE(created_at)=? AND status != 'cancelled'");
        $stmt->execute([$prevDate]);
        $stats['yesterday'] = $stmt->fetch();
        
        // Status breakdown
        $stmt = $db->prepare("SELECT status, COUNT(*) as count FROM orders WHERE DATE(created_at)=? GROUP BY status");
        $stmt->execute([$date]);
        $stats['by_status'] = $stmt->fetchAll();
        
        // Top items today
        $stmt = $db->prepare("SELECT oi.item_name, SUM(oi.quantity) as total_qty, SUM(oi.total_price) as revenue
            FROM order_items oi JOIN orders o ON oi.order_id=o.id
            WHERE DATE(o.created_at)=?
            GROUP BY oi.item_name ORDER BY total_qty DESC LIMIT 5");
        $stmt->execute([$date]);
        $stats['top_items'] = $stmt->fetchAll();
        
        // Recent orders
        $stmt = $db->prepare("SELECT o.order_number, o.status, o.total_amount, o.order_type, 
            o.created_at, c.name as customer_name
            FROM orders o JOIN customers c ON o.customer_id=c.id
            ORDER BY o.created_at DESC LIMIT 10");
        $stmt->execute();
        $stats['recent_orders'] = $stmt->fetchAll();
        
        // New orders count (for badge)
        $stmt = $db->query("SELECT COUNT(*) as count FROM orders WHERE status='new'");
        $stats['new_orders_count'] = $stmt->fetchColumn();
        
        success($stats);

    // ─── Customer: Rate order ─────────────────────────────────────
    case 'POST:rate':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        
        if ($data['rating'] < 1 || $data['rating'] > 5) error('تقييم غير صالح');
        
        $stmt = $db->prepare("UPDATE orders SET rating=?, rating_comment=?, rated_at=NOW() 
            WHERE id=? AND customer_id=?");
        $stmt->execute([$data['rating'], $data['comment']??null, $data['order_id'], $data['customer_id']]);
        
        success([], 'شكراً على تقييمك! 🙏');

    default:
        error('Action not found', 404);
}
