<?php
// migrate.php
// Idempotent migration runner — safe to run multiple times.
// Adds any missing columns/tables needed by the latest features
// (AI providers, customer accounts, balance, addresses, SMTP, etc.)
// without erroring if they already exist.
//
// USAGE (run from /var/www/restaurant or anywhere, just point DB creds):
//   php migrate.php
//
// Or copy config.php's DB constants in here if running standalone.

require_once __DIR__ . '/config.php';

$db = getDB();

function columnExists($db, $table, $column) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return $stmt->fetchColumn() > 0;
}

function tableExists($db, $table) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
    $stmt->execute([$table]);
    return $stmt->fetchColumn() > 0;
}

function addColumn($db, $table, $column, $definition) {
    if (columnExists($db, $table, $column)) {
        echo "  - $table.$column already exists, skipping\n";
        return;
    }
    $db->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    echo "  + added $table.$column\n";
}

function createTable($db, $table, $sql) {
    if (tableExists($db, $table)) {
        echo "  - table $table already exists, skipping\n";
        return;
    }
    $db->exec($sql);
    echo "  + created table $table\n";
}

echo "=== Migration: customers (auth, balance, email, google) ===\n";
addColumn($db, 'customers', 'password', "VARCHAR(255) NULL AFTER whatsapp_number");
addColumn($db, 'customers', 'balance', "DECIMAL(10,2) DEFAULT 0 AFTER password");
addColumn($db, 'customers', 'email', "VARCHAR(100) NULL AFTER balance");
addColumn($db, 'customers', 'email_verified', "TINYINT(1) DEFAULT 0 AFTER email");
addColumn($db, 'customers', 'google_id', "VARCHAR(100) NULL AFTER email_verified");

// Unique index on email/google_id (only if not already present)
try {
    $db->exec("ALTER TABLE customers ADD UNIQUE INDEX idx_email_unique (email)");
    echo "  + added unique index on customers.email\n";
} catch (Exception $e) {
    echo "  - unique index on email already exists or skipped\n";
}
try {
    $db->exec("ALTER TABLE customers ADD UNIQUE INDEX idx_google_id_unique (google_id)");
    echo "  + added unique index on customers.google_id\n";
} catch (Exception $e) {
    echo "  - unique index on google_id already exists or skipped\n";
}

echo "\n=== Migration: coupons (personal coupons) ===\n";
addColumn($db, 'coupons', 'customer_id', "INT NULL AFTER applicable_ids");
try {
    $db->exec("ALTER TABLE coupons ADD CONSTRAINT fk_coupon_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE");
    echo "  + added FK coupons.customer_id -> customers.id\n";
} catch (Exception $e) {
    echo "  - FK on coupons.customer_id already exists or skipped\n";
}

echo "\n=== Migration: orders (wallet balance used) ===\n";
addColumn($db, 'orders', 'balance_used', "DECIMAL(10,2) DEFAULT 0 AFTER discount_amount");

echo "\n=== Migration: restaurant_settings (SMTP, auth, Google) ===\n";
addColumn($db, 'restaurant_settings', 'smtp_host', "VARCHAR(100) NULL");
addColumn($db, 'restaurant_settings', 'smtp_port', "INT DEFAULT 587");
addColumn($db, 'restaurant_settings', 'smtp_user', "VARCHAR(100) NULL");
addColumn($db, 'restaurant_settings', 'smtp_pass', "VARCHAR(255) NULL");
addColumn($db, 'restaurant_settings', 'smtp_from_email', "VARCHAR(100) NULL");
addColumn($db, 'restaurant_settings', 'smtp_from_name', "VARCHAR(100) NULL");
addColumn($db, 'restaurant_settings', 'smtp_secure', "VARCHAR(10) DEFAULT 'tls'");
addColumn($db, 'restaurant_settings', 'require_login_for_orders', "TINYINT(1) DEFAULT 1");
addColumn($db, 'restaurant_settings', 'require_email_verification', "TINYINT(1) DEFAULT 0");
addColumn($db, 'restaurant_settings', 'google_client_id', "VARCHAR(255) NULL");

echo "\n=== Migration: new tables ===\n";
createTable($db, 'ai_providers', "CREATE TABLE ai_providers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider VARCHAR(30) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    api_key VARCHAR(255) DEFAULT '',
    model VARCHAR(100) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    is_default TINYINT(1) DEFAULT 0,
    priority INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

createTable($db, 'balance_transactions', "CREATE TABLE balance_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    reason VARCHAR(255),
    order_id INT NULL,
    created_by VARCHAR(50) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

createTable($db, 'email_otps', "CREATE TABLE email_otps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    code VARCHAR(6) NOT NULL,
    purpose VARCHAR(30) DEFAULT 'verify',
    expires_at TIMESTAMP NOT NULL,
    used TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

createTable($db, 'order_notes', "CREATE TABLE order_notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    note TEXT NOT NULL,
    created_by VARCHAR(100) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

echo "\n=== Sanity check: restaurant_settings has at least 1 row ===\n";
$count = $db->query("SELECT COUNT(*) FROM restaurant_settings")->fetchColumn();
if ($count == 0) {
    $db->exec("INSERT INTO restaurant_settings (name, bot_name) VALUES ('مطعمي', 'نور')");
    echo "  + inserted default restaurant_settings row\n";
} else {
    echo "  - restaurant_settings has $count row(s), OK\n";
}

echo "\n✅ Migration complete!\n";
