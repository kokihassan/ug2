-- ============================================================
-- Migration: Customer accounts (phone + password login)
--   mysql -u botuser -p restaurant_bot < migration_customer_auth.sql
-- ============================================================
SET NAMES utf8mb4;

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS password VARCHAR(255) NULL AFTER whatsapp_number;
