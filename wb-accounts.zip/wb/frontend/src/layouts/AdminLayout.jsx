import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '../store'
import { adminApi } from '../api'

const NAV = [
  { path: '/admin/dashboard', icon: '📊', ar: 'الداشبورد', en: 'Dashboard' },
  { path: '/admin/orders', icon: '📦', ar: 'الطلبات', en: 'Orders' },
  { path: '/admin/menu', icon: '🍽️', ar: 'المنيو', en: 'Menu' },
  { path: '/admin/offers', icon: '🎁', ar: 'الأوفر', en: 'Offers' },
  { path: '/admin/branches', icon: '📍', ar: 'الفروع', en: 'Branches' },
  { path: '/admin/customers', icon: '👥', ar: 'العملاء', en: 'Customers' },
  { path: '/admin/coupons', icon: '🎫', ar: 'الكوبونات', en: 'Coupons' },
  { path: '/admin/reports', icon: '📈', ar: 'التقارير', en: 'Reports' },
  { path: '/admin/settings', icon: '⚙️', ar: 'الإعدادات', en: 'Settings' },
]

export default function AdminLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const { lang, settings } = useAppStore()
  const isAr = lang === 'ar'
  const t = (ar, en) => isAr ? ar : en
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [newOrders, setNewOrders] = useState(0)
  const [soundOn, setSoundOn] = useState(() => localStorage.getItem('admin_sound') !== 'off')
  const [user] = useState(() => { try { return JSON.parse(localStorage.getItem('admin_user')) } catch { return null } })
  const prevCountRef = useRef(0)
  const audioRef = useRef(null)

  const logout = () => {
    localStorage.removeItem('admin_token')
    localStorage.removeItem('admin_user')
    navigate('/admin/login')
  }

  const toggleSound = () => {
    const next = !soundOn
    setSoundOn(next)
    localStorage.setItem('admin_sound', next ? 'on' : 'off')
    if (next) playAlert() // quick test beep when turning on
  }

  const playAlert = () => {
    try {
      if (!audioRef.current) {
        // Short pleasant "ding" tone generated via WebAudio (no external file needed)
        const ctx = new (window.AudioContext || window.webkitAudioContext)()
        audioRef.current = ctx
      }
      const ctx = audioRef.current
      const playTone = (freq, start, duration) => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = 'sine'
        osc.frequency.value = freq
        gain.gain.setValueAtTime(0.0001, ctx.currentTime + start)
        gain.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + start + 0.02)
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration)
        osc.connect(gain); gain.connect(ctx.destination)
        osc.start(ctx.currentTime + start)
        osc.stop(ctx.currentTime + start + duration)
      }
      playTone(880, 0, 0.18)
      playTone(1175, 0.18, 0.22)
    } catch {}
  }

  // Request browser notification permission once
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission()
    }
  }, [])

  // Poll for new orders, alert on increase
  useEffect(() => {
    let firstPoll = true
    const poll = () => {
      adminApi.getStats(new Date().toISOString().split('T')[0]).then(r => {
        if (!r.success) return
        const count = r.data.new_orders_count || 0
        if (!firstPoll && count > prevCountRef.current) {
          if (soundOn) playAlert()
          if ('Notification' in window && Notification.permission === 'granted') {
            const n = new Notification(t('🔔 طلب جديد!','🔔 New Order!'), {
              body: t('لديك طلب جديد في المطعم — اضغط لعرض الطلبات','You have a new order — click to view'),
              icon: '🍽️',
              tag: 'new-order',
            })
            n.onclick = () => { window.focus(); navigate('/admin/orders') }
          }
        }
        prevCountRef.current = count
        setNewOrders(count)
        firstPoll = false
      }).catch(() => {})
    }
    poll()
    const interval = setInterval(poll, 8000)
    return () => clearInterval(interval)
  }, [soundOn])

  // Flash tab title when there are unseen new orders
  useEffect(() => {
    if (newOrders === 0) { document.title = t('لوحة التحكم','Admin Panel'); return }
    let flip = false
    const original = t('لوحة التحكم','Admin Panel')
    const alertTitle = `🔔 (${newOrders}) ${t('طلب جديد','New Order')}`
    const id = setInterval(() => {
      document.title = flip ? original : alertTitle
      flip = !flip
    }, 1200)
    return () => { clearInterval(id); document.title = original }
  }, [newOrders])

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-obsidian-900 border-e border-obsidian-800">
      {/* Logo */}
      <div className="p-5 border-b border-obsidian-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold-gradient flex items-center justify-center text-xl shadow-lg">🍽️</div>
          <div>
            <div className="gold-text font-black text-sm leading-tight">{settings?.name || t('مطعمنا','Restaurant')}</div>
            <div className="text-obsidian-500 text-[10px] mt-0.5">{t('لوحة التحكم','Admin Panel')}</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {NAV.map(item => {
          const active = location.pathname === item.path
          return (
            <button key={item.path}
              onClick={() => { navigate(item.path); setSidebarOpen(false) }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all text-start relative
                ${active
                  ? 'bg-gold-500/10 text-gold-400 border border-gold-500/30'
                  : 'text-obsidian-400 hover:bg-obsidian-800 hover:text-white'}`}>
              <span className="text-base">{item.icon}</span>
              <span>{t(item.ar, item.en)}</span>
              {item.path === '/admin/orders' && newOrders > 0 && (
                <span className="absolute end-3 bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">
                  {newOrders}
                </span>
              )}
            </button>
          )
        })}
      </nav>

      {/* User + logout */}
      <div className="p-3 border-t border-obsidian-800">
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-obsidian-800 mb-2">
          <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/30 flex items-center justify-center text-gold-400 text-sm font-black">
            {user?.name?.[0] || 'A'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-xs font-bold truncate">{user?.name || 'Admin'}</div>
            <div className="text-obsidian-500 text-[10px] truncate">{user?.email}</div>
          </div>
        </div>
        <button onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-obsidian-400 hover:bg-red-900/20 hover:text-red-400 transition-all text-sm">
          🚪 {t('خروج','Logout')}
        </button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-60 flex-shrink-0 fixed inset-y-0 start-0 z-30">
        <SidebarContent />
      </div>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
            <motion.div initial={{ x: isAr ? '100%' : '-100%' }} animate={{ x: 0 }} exit={{ x: isAr ? '100%' : '-100%' }}
              className="fixed inset-y-0 start-0 w-64 z-50 lg:hidden shadow-2xl">
              <SidebarContent />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className="flex-1 lg:ms-60 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-14 bg-obsidian-900 border-b border-obsidian-800 flex items-center px-4 gap-3 sticky top-0 z-20">
          <button onClick={() => setSidebarOpen(true)}
            className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg bg-obsidian-800 text-obsidian-400 hover:text-white">
            ☰
          </button>
          <span className="font-bold text-white text-sm">
            {NAV.find(n => n.path === location.pathname)?.[isAr ? 'ar' : 'en'] || 'Admin'}
          </span>
          {newOrders > 0 && (
            <button onClick={() => navigate('/admin/orders')}
              className="flex items-center gap-2 bg-red-900/30 border border-red-800 text-red-400 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
              🔔 {newOrders} {t('طلب جديد','new orders')}
            </button>
          )}
          <div className="ms-auto flex items-center gap-3">
            <button onClick={toggleSound}
              title={soundOn ? t('إيقاف صوت التنبيه','Mute alert sound') : t('تشغيل صوت التنبيه','Unmute alert sound')}
              className={`w-8 h-8 flex items-center justify-center rounded-lg border transition-colors ${soundOn?'bg-gold-500/10 border-gold-600/40 text-gold-400':'bg-obsidian-800 border-obsidian-700 text-obsidian-500'}`}>
              {soundOn ? '🔔' : '🔕'}
            </button>
            <div className="text-obsidian-500 text-xs hidden sm:block">
              {new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </header>

        {/* Page */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto bg-obsidian-950">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
