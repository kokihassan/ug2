import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { adminApi } from '../../api'
import { StatusBadge, Toggle, Modal, Empty, Spinner } from '../../components/ui'
import toast from 'react-hot-toast'

// ── shared helpers ────────────────────────────────────────────
const Field = ({ label, children }) => (
  <div className="space-y-1.5">
    <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">{label}</label>
    {children}
  </div>
)
const Inp = (props) => <input {...props} className={`input-gold ${props.className || ''}`} />
const Sel = ({ children, ...props }) => <select {...props} className={`input-gold ${props.className || ''}`}>{children}</select>
const Txt = (props) => <textarea {...props} className={`input-gold resize-none ${props.className || ''}`} />

// ══════════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════════
export function DashboardPage() {
  const [stats, setStats] = useState(null)
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    adminApi.getStats(date).then(r => { if (r.success) setStats(r.data); setLoading(false) })
  }, [date])

  if (loading) return <div className="flex justify-center py-20"><div className="w-10 h-10 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>

  const t = stats?.today || {}
  const cards = [
    { v: t.total_orders || 0, l: 'إجمالي الطلبات', icon: '📦', g: 'from-blue-600 to-blue-700' },
    { v: `${parseFloat(t.total_revenue || 0).toFixed(0)} ج`, l: 'الإيرادات', icon: '💰', g: 'from-emerald-600 to-emerald-700' },
    { v: t.delivery_count || 0, l: 'توصيل', icon: '🛵', g: 'from-orange-600 to-orange-700' },
    { v: t.takeaway_count || 0, l: 'تيك أواي', icon: '🥡', g: 'from-purple-600 to-purple-700' },
    { v: stats?.new_orders_count || 0, l: 'طلبات جديدة الآن', icon: '🔔', g: 'from-red-600 to-red-700' },
    { v: `${parseFloat(t.avg_order_value || 0).toFixed(0)} ج`, l: 'متوسط الطلب', icon: '📊', g: 'from-teal-600 to-teal-700' },
  ]

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-xl font-black text-white">الداشبورد 📊</h1>
        <div className="flex gap-2">
          <Inp type="date" value={date} onChange={e => setDate(e.target.value)} className="w-40 text-sm" />
          <button onClick={() => adminApi.getStats(date).then(r => r.success && setStats(r.data))}
            className="bg-obsidian-700 border border-obsidian-600 text-obsidian-300 px-3 py-2 rounded-xl text-sm hover:bg-obsidian-600 transition-colors">↻</button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map((c, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className={`bg-gradient-to-br ${c.g} rounded-2xl p-5 text-white shadow-lg`}>
            <div className="text-3xl mb-2">{c.icon}</div>
            <div className="text-2xl font-black">{c.v}</div>
            <div className="text-white/70 text-xs mt-1">{c.l}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5">
          <h3 className="font-black text-white mb-4">🔥 أكثر الأصناف طلباً</h3>
          {(stats?.top_items || []).map((item, i) => (
            <div key={i} className="flex items-center gap-3 mb-3 last:mb-0">
              <span className={`w-7 h-7 rounded-lg text-xs font-black text-white flex items-center justify-center flex-shrink-0
                ${['bg-gold-500','bg-obsidian-500','bg-orange-600','bg-teal-600','bg-blue-600'][i] || 'bg-obsidian-600'}`}>{i+1}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-white truncate">{item.item_name}</div>
                <div className="h-1.5 bg-obsidian-700 rounded-full mt-1">
                  <div className="h-1.5 bg-gold-500 rounded-full transition-all"
                    style={{ width: `${(item.total_qty/(stats.top_items[0]?.total_qty||1))*100}%` }} />
                </div>
              </div>
              <div className="text-right text-xs flex-shrink-0">
                <div className="font-black text-white">{item.total_qty}</div>
                <div className="text-obsidian-500">{parseFloat(item.revenue||0).toFixed(0)} ج</div>
              </div>
            </div>
          ))}
          {!(stats?.top_items?.length) && <p className="text-obsidian-500 text-sm text-center py-4">لا بيانات اليوم</p>}
        </div>

        <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5">
          <h3 className="font-black text-white mb-4">🕐 آخر الطلبات</h3>
          {(stats?.recent_orders || []).map((o, i) => (
            <div key={i} className="flex items-center justify-between py-2.5 border-b border-obsidian-700 last:border-0">
              <div>
                <div className="text-xs font-bold text-white">{o.order_number}</div>
                <div className="text-xs text-obsidian-500">{o.customer_name}</div>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={o.status} />
                <span className="text-xs font-black text-gold-400">{parseFloat(o.total_amount||0).toFixed(0)} ج</span>
              </div>
            </div>
          ))}
          {!(stats?.recent_orders?.length) && <p className="text-obsidian-500 text-sm text-center py-4">لا طلبات بعد</p>}
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// ORDERS PAGE
// ══════════════════════════════════════════════════════════════
export function OrdersPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [selected, setSelected] = useState(null)
  const [newCount, setNewCount] = useState(0)

  const FLOW = ['new','confirmed','preparing','ready','out_for_delivery','delivered']
  const NEXT_LABEL = { confirmed:'✅ تأكيد', preparing:'👨‍🍳 بدء التحضير', ready:'✨ جاهز', out_for_delivery:'🛵 خرج للتوصيل', delivered:'✅ تم التسليم' }

  const load = () => {
    const params = { date }
    if (filter !== 'all') params.status = filter
    adminApi.getOrders(params).then(r => {
      if (r.success) {
        setOrders(r.data.orders || [])
        setNewCount((r.data.orders || []).filter(o => o.status === 'new').length)
      }
      setLoading(false)
    })
  }

  useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t) }, [filter, date])

  const updateStatus = async (id, status) => {
    await adminApi.updateOrder(id, { status })
    toast.success('تم تحديث الحالة')
    load()
    if (selected?.id === id) setSelected(p => ({ ...p, status }))
  }

  const getNext = s => { const i = FLOW.indexOf(s); return i >= 0 && i < FLOW.length - 1 ? FLOW[i+1] : null }

  const FILTERS = [
    ['all','الكل'], ['new','🔵 جديد'], ['confirmed','مؤكد'], ['preparing','🔥 تحضير'],
    ['ready','✨ جاهز'], ['out_for_delivery','🛵 في الطريق'], ['delivered','✅ تم'], ['cancelled','ملغي']
  ]

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-black text-white">الطلبات 📦</h1>
          <span className="flex items-center gap-1 text-emerald-400 text-[10px] font-bold">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span> مباشر
          </span>
          {newCount > 0 && <span className="bg-red-500 text-white text-xs font-black px-3 py-1 rounded-full animate-pulse">🔔 {newCount} جديد</span>}
        </div>
        <div className="flex gap-2">
          <Inp type="date" value={date} onChange={e => setDate(e.target.value)} className="w-38 text-sm" />
          <button onClick={load} className="bg-obsidian-700 border border-obsidian-600 text-obsidian-300 px-3 py-2 rounded-xl text-sm hover:bg-obsidian-600 transition-colors">↻</button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold border transition-all ${filter===k?'bg-gold-500 text-obsidian-900 border-gold-500':'bg-transparent text-obsidian-400 border-obsidian-700 hover:border-gold-600'}`}>
            {l}
          </button>
        ))}
      </div>

      {loading ? <div className="flex justify-center py-10"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" /></div> : (
        <div className="space-y-3">
          {orders.length === 0 && <Empty icon="📭" title="لا توجد طلبات" />}
          {orders.map(o => (
            <motion.div key={o.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              onClick={() => setSelected(o)}
              className={`bg-obsidian-800 border-2 rounded-2xl p-4 cursor-pointer hover:shadow-lg transition-all ${o.status==='new'?'border-blue-500 bg-blue-950/20':'border-obsidian-700 hover:border-gold-600/40'}`}>
              <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-black text-white text-sm">{o.order_number}</span>
                  <StatusBadge status={o.status} />
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${o.order_type==='delivery'?'bg-orange-900/30 text-orange-400':'bg-teal-900/30 text-teal-400'}`}>
                    {o.order_type==='delivery'?'🛵 توصيل':'🥡 تيك أواي'}
                  </span>
                </div>
                <span className="gold-text font-black text-lg">{parseFloat(o.total_amount||0).toFixed(0)} ج</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-semibold text-white">{o.customer_name || 'عميل'}</span>
                  <span className="text-obsidian-500 text-xs me-2"> {o.whatsapp_number}</span>
                  {o.zone_name && <span className="text-obsidian-500 text-xs">· {o.zone_name}</span>}
                </div>
                <div className="flex gap-2" onClick={e => e.stopPropagation()}>
                  {!['delivered','cancelled'].includes(o.status) && getNext(o.status) && (
                    <button onClick={() => updateStatus(o.id, getNext(o.status))}
                      className="btn-gold px-3 py-1.5 rounded-xl text-xs font-bold">
                      {NEXT_LABEL[getNext(o.status)]}
                    </button>
                  )}
                  {!['delivered','cancelled'].includes(o.status) && (
                    <button onClick={() => updateStatus(o.id, 'cancelled')}
                      className="bg-red-900/30 border border-red-800 text-red-400 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-red-900/50 transition-colors">
                      إلغاء
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Order Detail Modal */}
      <AnimatePresence>
        {selected && (
          <Modal title={selected.order_number} onClose={() => setSelected(null)}>
            <div className="space-y-4" dir="rtl">
              <div className="flex gap-2 flex-wrap">
                <StatusBadge status={selected.status} />
                <span className={`text-xs px-2.5 py-1 rounded-lg font-bold border ${selected.order_type==='delivery'?'bg-orange-900/20 text-orange-400 border-orange-800':'bg-teal-900/20 text-teal-400 border-teal-800'}`}>
                  {selected.order_type==='delivery'?'🛵 توصيل':'🥡 تيك أواي'}
                </span>
              </div>
              <div className="bg-obsidian-700/50 rounded-xl p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-obsidian-400">العميل</span><span className="text-white font-bold">{selected.customer_name}</span></div>
                <div className="flex justify-between"><span className="text-obsidian-400">الهاتف</span><span className="text-white font-bold">{selected.whatsapp_number}</span></div>
                {selected.delivery_address && <div className="flex justify-between"><span className="text-obsidian-400">العنوان</span><span className="text-white font-bold text-end max-w-[60%]">{selected.delivery_address}</span></div>}
                {selected.zone_name && <div className="flex justify-between"><span className="text-obsidian-400">المنطقة</span><span className="text-white font-bold">{selected.zone_name}</span></div>}
              </div>
              <div className="bg-obsidian-700/50 rounded-xl p-4">
                <p className="font-black text-white mb-3 text-sm">الأصناف:</p>
                {(selected.items || []).map((item, i) => (
                  <div key={i} className="flex justify-between text-sm mb-2 gap-2">
                    <div className="min-w-0">
                      <span className="text-obsidian-300">{item.quantity}× {item.item_name}</span>
                      {item.size_name && <span className="text-obsidian-500 text-xs"> ({item.size_name})</span>}
                      {item.extras?.length > 0 && (
                        <div className="text-obsidian-500 text-xs">+ {item.extras.join('، ')}</div>
                      )}
                      {item.notes && <div className="text-gold-500/80 text-xs">📝 {item.notes}</div>}
                    </div>
                    <span className="font-bold text-white whitespace-nowrap">{parseFloat(item.total_price||0).toFixed(0)} ج</span>
                  </div>
                ))}
                <div className="border-t border-obsidian-600 mt-3 pt-3 space-y-1.5 text-sm">
                  {parseFloat(selected.delivery_fee)>0 && <div className="flex justify-between text-obsidian-400"><span>التوصيل</span><span>{parseFloat(selected.delivery_fee).toFixed(0)} ج</span></div>}
                  {parseFloat(selected.discount_amount)>0 && <div className="flex justify-between text-emerald-400"><span>خصم</span><span>-{parseFloat(selected.discount_amount).toFixed(0)} ج</span></div>}
                  <div className="flex justify-between items-center pt-1">
                    <span className="font-black text-white text-base">الإجمالي</span>
                    <span className="gold-text font-black text-xl">{parseFloat(selected.total_amount||0).toFixed(0)} ج</span>
                  </div>
                </div>
              </div>
              {selected.customer_notes && (
                <div className="bg-gold-900/20 border border-gold-800/30 rounded-xl p-3 text-sm text-gold-300">
                  📝 {selected.customer_notes}
                </div>
              )}
              <div className="flex gap-2 flex-wrap">
                {!['delivered','cancelled'].includes(selected.status) && getNext(selected.status) && (
                  <button onClick={() => updateStatus(selected.id, getNext(selected.status))} className="btn-gold flex-1 py-3 rounded-xl text-sm font-bold">
                    {NEXT_LABEL[getNext(selected.status)]}
                  </button>
                )}
                {!['delivered','cancelled'].includes(selected.status) && (
                  <button onClick={() => { updateStatus(selected.id,'cancelled'); setSelected(null) }}
                    className="bg-red-900/30 border border-red-800 text-red-400 px-5 py-3 rounded-xl text-sm font-bold">
                    إلغاء الطلب
                  </button>
                )}
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// ITEM OPTIONS MANAGER (Extras & Sizes) — used inside item edit modal
// ══════════════════════════════════════════════════════════════
function ItemOptionsManager({ itemId }) {
  const [extras, setExtras] = useState([])
  const [sizes, setSizes] = useState([])
  const [newExtra, setNewExtra] = useState({ name:'', price:'' })
  const [newSize, setNewSize] = useState({ size_name:'', price_addition:'', is_default:0 })
  const [loading, setLoading] = useState(true)

  const load = async () => {
    const [e,s] = await Promise.all([adminApi.getExtras(itemId), adminApi.getSizes(itemId)])
    if (e.success) setExtras(e.data||[])
    if (s.success) setSizes(s.data||[])
    setLoading(false)
  }
  useEffect(() => { load() }, [itemId])

  const addExtra = async () => {
    if (!newExtra.name.trim()) return toast.error('أدخل اسم الإضافة')
    const res = await adminApi.createExtra({ item_id: itemId, name: newExtra.name, price: newExtra.price||0 })
    if (res.success) { setNewExtra({name:'',price:''}); load() } else toast.error(res.message||'خطأ')
  }
  const removeExtra = async (id) => { await adminApi.deleteExtra(id); load() }
  const toggleExtraAvail = async (extra) => { await adminApi.updateExtra(extra.id, {...extra, is_available: extra.is_available?0:1}); load() }

  const addSize = async () => {
    if (!newSize.size_name.trim()) return toast.error('أدخل اسم الحجم')
    const res = await adminApi.createSize({ item_id: itemId, size_name: newSize.size_name, price_addition: newSize.price_addition||0, is_default: newSize.is_default?1:0 })
    if (res.success) { setNewSize({size_name:'',price_addition:'',is_default:0}); load() } else toast.error(res.message||'خطأ')
  }
  const removeSize = async (id) => { await adminApi.deleteSize(id); load() }
  const makeDefaultSize = async (size) => { await adminApi.updateSize(size.id, {...size, is_default:1}); load() }

  if (loading) return null

  return (
    <div className="bg-gold-950/10 border border-gold-800/30 rounded-xl p-4 space-y-5">
      <p className="font-bold text-gold-400 text-sm">⚙️ خيارات الصنف (إضافات وأحجام)</p>

      {/* Sizes */}
      <div>
        <p className="text-xs font-bold text-obsidian-400 uppercase tracking-wide mb-2">📏 الأحجام</p>
        <div className="space-y-2 mb-2">
          {sizes.map(s => (
            <div key={s.id} className={`flex items-center justify-between p-2.5 rounded-xl border text-sm ${s.is_default?'border-gold-600 bg-gold-500/5':'border-obsidian-700'}`}>
              <div className="flex items-center gap-2">
                <span className="text-white font-semibold">{s.size_name}</span>
                {parseFloat(s.price_addition)>0 && <span className="text-gold-400 text-xs">+{parseFloat(s.price_addition).toFixed(0)} ج</span>}
                {!!s.is_default && <span className="text-[10px] bg-gold-500 text-obsidian-900 px-2 py-0.5 rounded-full font-bold">افتراضي</span>}
              </div>
              <div className="flex items-center gap-2">
                {!s.is_default && <button onClick={()=>makeDefaultSize(s)} className="text-obsidian-500 hover:text-gold-400 text-xs transition-colors">تعيين كافتراضي</button>}
                <button onClick={()=>removeSize(s.id)} className="text-obsidian-600 hover:text-red-400 transition-colors">🗑️</button>
              </div>
            </div>
          ))}
          {sizes.length===0 && <p className="text-obsidian-600 text-xs">لا توجد أحجام — الصنف بحجم واحد فقط</p>}
        </div>
        <div className="flex gap-2">
          <Inp value={newSize.size_name} onChange={e=>setNewSize(p=>({...p,size_name:e.target.value}))} placeholder="اسم الحجم (وسط، كبير...)" className="flex-1 text-sm" />
          <Inp type="number" value={newSize.price_addition} onChange={e=>setNewSize(p=>({...p,price_addition:e.target.value}))} placeholder="+سعر" className="w-24 text-sm" />
          <button onClick={addSize} className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex-shrink-0">+</button>
        </div>
      </div>

      {/* Extras */}
      <div>
        <p className="text-xs font-bold text-obsidian-400 uppercase tracking-wide mb-2">➕ الإضافات</p>
        <div className="space-y-2 mb-2">
          {extras.map(ex => (
            <div key={ex.id} className={`flex items-center justify-between p-2.5 rounded-xl border text-sm ${ex.is_available?'border-obsidian-700':'border-obsidian-700 opacity-50'}`}>
              <div className="flex items-center gap-2">
                <span className="text-white font-semibold">{ex.name}</span>
                {parseFloat(ex.price)>0 && <span className="text-gold-400 text-xs">+{parseFloat(ex.price).toFixed(0)} ج</span>}
              </div>
              <div className="flex items-center gap-2">
                <Toggle checked={!!ex.is_available} onChange={()=>toggleExtraAvail(ex)} size="sm" />
                <button onClick={()=>removeExtra(ex.id)} className="text-obsidian-600 hover:text-red-400 transition-colors">🗑️</button>
              </div>
            </div>
          ))}
          {extras.length===0 && <p className="text-obsidian-600 text-xs">لا توجد إضافات لهذا الصنف</p>}
        </div>
        <div className="flex gap-2">
          <Inp value={newExtra.name} onChange={e=>setNewExtra(p=>({...p,name:e.target.value}))} placeholder="اسم الإضافة (جبنة إكسترا...)" className="flex-1 text-sm" />
          <Inp type="number" value={newExtra.price} onChange={e=>setNewExtra(p=>({...p,price:e.target.value}))} placeholder="السعر" className="w-24 text-sm" />
          <button onClick={addExtra} className="btn-gold px-4 py-2 rounded-xl text-sm font-bold flex-shrink-0">+</button>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// MENU PAGE
// ══════════════════════════════════════════════════════════════
export function AdminMenuPage() {
  const [categories, setCategories] = useState([])
  const [items, setItems] = useState([])
  const [branches, setBranches] = useState([])
  const [catFilter, setCatFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editItem, setEditItem] = useState(null)
  const [showCatForm, setShowCatForm] = useState(false)
  const [editCat, setEditCat] = useState(null)
  const [uploading, setUploading] = useState(false)
  const excelRef = useRef()
  const emptyForm = { category_id:'', name:'', name_en:'', description:'', price:'', preparation_time_minutes:15, calories:'', is_available:1, is_featured:0, is_new:0, is_spicy:0, is_vegetarian:0 }
  const [form, setForm] = useState(emptyForm)
  const emptyCatForm = { name:'', name_en:'', description:'', icon:'🍽️', sort_order:0, is_active:1 }
  const [catForm, setCatForm] = useState(emptyCatForm)

  const loadAll = async () => {
    const [c,i,b] = await Promise.all([adminApi.getCategories(), adminApi.getMenuItems({}), adminApi.getBranches()])
    if (c.success) setCategories(c.data||[])
    if (i.success) setItems(i.data||[])
    if (b.success) setBranches(b.data||[])
  }
  useEffect(() => { loadAll() }, [])

  const saveItem = async () => {
    if (!form.name||!form.category_id||!form.price) return toast.error('أكمل البيانات المطلوبة')
    const res = editItem ? await adminApi.updateItem(editItem.id, form) : await adminApi.createItem(form)
    if (res.success) { toast.success(editItem?'تم التحديث':'تمت الإضافة'); setShowForm(false); setEditItem(null); loadAll() }
    else toast.error(res.message||'خطأ')
  }

  const saveCategory = async () => {
    if (!catForm.name?.trim()) return toast.error('أدخل اسم القسم')
    const res = editCat ? await adminApi.updateCategory(editCat.id, catForm) : await adminApi.createCategory(catForm)
    if (res.success) { toast.success(editCat?'تم تحديث القسم':'تمت إضافة القسم'); setShowCatForm(false); setEditCat(null); loadAll() }
    else toast.error(res.message||'خطأ')
  }

  const uploadImg = (id, file) => {
    if (!file) return
    setUploading(true)
    adminApi.uploadImage(id, file).then(r => { setUploading(false); if(r.success){toast.success('تم رفع الصورة');loadAll()} else toast.error(r.message||'فشل رفع الصورة') })
  }

  const importExcel = (file) => {
    if (!file) return
    setUploading(true)
    adminApi.importExcel(file).then(r => { setUploading(false); if(r.success){toast.success(`تم استيراد ${r.data?.imported||0} صنف`);loadAll()} else toast.error(r.message||'فشل') })
  }

  const toggleBranch = async (itemId, branchId, cur) => {
    await adminApi.toggleBranchAvail({ item_id:itemId, branch_id:branchId, is_available: cur?0:1 })
    toast.success(cur?'تم إيقاف الصنف':'تم تفعيل الصنف')
    loadAll()
  }

  const filtered = items.filter(i =>
    (catFilter==='all'||i.category_id==catFilter) &&
    (!search||i.name.includes(search)||i.name.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <h1 className="text-xl font-black text-white">المنيو 🍽️</h1>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => window.open(`/api/menu/excel-template`)} className="bg-emerald-900/30 border border-emerald-800 text-emerald-400 px-3 py-2 rounded-xl text-xs font-bold hover:bg-emerald-900/50 transition-colors">
            📥 Template
          </button>
          <button onClick={() => excelRef.current?.click()} disabled={uploading}
            className="bg-blue-900/30 border border-blue-800 text-blue-400 px-3 py-2 rounded-xl text-xs font-bold hover:bg-blue-900/50 transition-colors disabled:opacity-50">
            📤 {uploading?'...':'Excel'}
          </button>
          <input ref={excelRef} type="file" accept=".csv,.xlsx" className="hidden" onChange={e=>{importExcel(e.target.files[0]);e.target.value=''}} />
          <button onClick={() => { setEditCat(null); setCatForm(emptyCatForm); setShowCatForm(true) }}
            className="bg-obsidian-700 border border-obsidian-600 text-obsidian-200 px-4 py-2 rounded-xl text-xs font-bold hover:border-gold-600 transition-colors">+ قسم جديد</button>
          <button onClick={() => { setEditItem(null); setForm(emptyForm); setShowForm(true) }}
            className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ إضافة صنف</button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-48">
          <span className="absolute start-3 top-1/2 -translate-y-1/2 text-obsidian-500 text-sm">🔍</span>
          <Inp value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث..." className="ps-8 text-sm" />
        </div>
        <div className="flex gap-1 overflow-x-auto">
          <button onClick={()=>setCatFilter('all')} className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${catFilter==='all'?'bg-gold-500 text-obsidian-900 border-gold-500':'bg-transparent text-obsidian-400 border-obsidian-700'}`}>
            الكل ({items.length})
          </button>
          {categories.map(c=>(
            <div key={c.id} className="flex items-center flex-shrink-0">
              <button onClick={()=>setCatFilter(c.id)} className={`px-3 py-1.5 rounded-s-lg text-xs font-bold transition-all border whitespace-nowrap ${catFilter==c.id?'bg-gold-500 text-obsidian-900 border-gold-500':'bg-transparent text-obsidian-400 border-obsidian-700'} ${!c.is_active?'opacity-50':''}`}>
                {c.icon} {c.name}{!c.is_active?' (مخفي)':''}
              </button>
              <button onClick={()=>{setEditCat(c);setCatForm({name:c.name,name_en:c.name_en||'',description:c.description||'',icon:c.icon||'🍽️',sort_order:c.sort_order||0,is_active:c.is_active});setShowCatForm(true)}}
                className={`px-2 py-1.5 rounded-e-lg text-xs border border-s-0 transition-all ${catFilter==c.id?'bg-gold-500 text-obsidian-900 border-gold-500':'bg-transparent text-obsidian-500 border-obsidian-700 hover:text-white'}`}>
                ✏️
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item => (
          <div key={item.id} className={`bg-obsidian-800 border border-obsidian-700 rounded-2xl overflow-hidden hover:border-gold-600/40 transition-all ${!item.is_available?'opacity-60':''}`}>
            <div className="relative group h-40">
              {item.image ? <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                : <div className="w-full h-full bg-obsidian-700 flex items-center justify-center text-4xl">🍽️</div>}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <label className="bg-white text-obsidian-900 px-4 py-2 rounded-xl text-xs font-bold cursor-pointer hover:bg-gold-100 transition-colors">
                  📷 رفع صورة
                  <input type="file" accept="image/*" className="hidden" onChange={e=>uploadImg(item.id,e.target.files[0])} />
                </label>
              </div>
              <div className="absolute top-2 start-2 flex gap-1 flex-wrap">
                {item.is_featured===1 && <span className="badge-gold text-[9px] px-2 py-0.5 rounded-full">⭐</span>}
                {item.is_new===1 && <span className="badge-gold badge-new text-[9px] px-2 py-0.5 rounded-full">NEW</span>}
              </div>
            </div>
            <div className="p-3">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h3 className="font-bold text-white text-sm truncate flex-1">{item.name}</h3>
                <span className="gold-text font-black text-sm whitespace-nowrap">{parseFloat(item.price).toFixed(0)} ج</span>
              </div>
              <div className="text-obsidian-500 text-xs mb-2">⏱️ {item.preparation_time_minutes}د | {item.category_name} | 🛒 {item.total_orders||0}</div>
              {/* Branch availability */}
              {branches.length > 0 && (
                <div className="bg-obsidian-700/50 rounded-xl p-2 mb-2 space-y-1">
                  {branches.map(b => {
                    const avail = item[`branch_${b.id}_available`] !== 0
                    return (
                      <div key={b.id} className="flex items-center justify-between">
                        <span className="text-obsidian-400 text-xs">{b.name}</span>
                        <Toggle checked={avail} onChange={()=>toggleBranch(item.id,b.id,avail)} size="sm" />
                      </div>
                    )
                  })}
                </div>
              )}
              <button onClick={() => { setEditItem(item); setForm({category_id:item.category_id,name:item.name,name_en:item.name_en||'',description:item.description||'',price:item.price,preparation_time_minutes:item.preparation_time_minutes||15,calories:item.calories||'',is_available:item.is_available,is_featured:item.is_featured,is_new:item.is_new,is_spicy:item.is_spicy,is_vegetarian:item.is_vegetarian}); setShowForm(true) }}
                className="w-full bg-obsidian-700 border border-obsidian-600 text-obsidian-300 py-2 rounded-xl text-xs font-bold hover:bg-obsidian-600 hover:text-white transition-colors">
                ✏️ تعديل
              </button>
            </div>
          </div>
        ))}
        {filtered.length===0 && <div className="col-span-3"><Empty icon="🍽️" title="لا توجد أصناف" /></div>}
      </div>

      {/* Item Form Modal */}
      <AnimatePresence>
        {showForm && (
          <Modal title={editItem?`✏️ تعديل: ${editItem.name}`:'✨ إضافة صنف'} onClose={()=>setShowForm(false)}>
            <div className="space-y-4" dir="rtl">
              <Field label="القسم *">
                <Sel value={form.category_id} onChange={e=>setForm(p=>({...p,category_id:e.target.value}))}>
                  <option value="">اختر القسم</option>
                  {categories.map(c=><option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                </Sel>
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="الاسم عربي *"><Inp value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} /></Field>
                <Field label="الاسم إنجليزي"><Inp value={form.name_en} onChange={e=>setForm(p=>({...p,name_en:e.target.value}))} /></Field>
              </div>
              <Field label="الوصف"><Txt rows={2} value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} /></Field>
              <div className="grid grid-cols-3 gap-3">
                <Field label="السعر *"><Inp type="number" value={form.price} onChange={e=>setForm(p=>({...p,price:e.target.value}))} /></Field>
                <Field label="وقت التحضير (د)"><Inp type="number" value={form.preparation_time_minutes} onChange={e=>setForm(p=>({...p,preparation_time_minutes:e.target.value}))} /></Field>
                <Field label="السعرات"><Inp type="number" value={form.calories} onChange={e=>setForm(p=>({...p,calories:e.target.value}))} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[['is_available','✅ متاح'],['is_featured','⭐ مميز'],['is_new','🆕 جديد'],['is_spicy','🌶️ حار'],['is_vegetarian','🥗 نباتي']].map(([k,l])=>(
                  <label key={k} className="flex items-center gap-3 cursor-pointer p-3 border border-obsidian-700 rounded-xl hover:border-gold-600 transition-colors">
                    <input type="checkbox" checked={!!form[k]} onChange={e=>setForm(p=>({...p,[k]:e.target.checked?1:0}))} className="w-4 h-4 accent-gold-500" />
                    <span className="text-sm text-obsidian-300">{l}</span>
                  </label>
                ))}
              </div>
              {editItem ? <ItemOptionsManager itemId={editItem.id} /> : (
                <div className="bg-obsidian-700/30 border border-obsidian-700 rounded-xl p-3 text-xs text-obsidian-500 text-center">
                  💡 احفظ الصنف أولاً، ثم افتح التعديل لإضافة أحجام وإضافات
                </div>
              )}
              <button onClick={saveItem} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">
                {editItem?'💾 حفظ التعديلات':'✅ إضافة الصنف'}
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>

      {/* Category Form Modal */}
      <AnimatePresence>
        {showCatForm && (
          <Modal title={editCat?`✏️ تعديل القسم: ${editCat.name}`:'📂 قسم جديد'} onClose={()=>setShowCatForm(false)} maxW="max-w-md">
            <div className="space-y-4" dir="rtl">
              <div className="grid grid-cols-2 gap-3">
                <Field label="الاسم عربي *"><Inp value={catForm.name} onChange={e=>setCatForm(p=>({...p,name:e.target.value}))} placeholder="مثال: مشويات" /></Field>
                <Field label="الاسم إنجليزي"><Inp value={catForm.name_en} onChange={e=>setCatForm(p=>({...p,name_en:e.target.value}))} placeholder="Grills" /></Field>
              </div>
              <Field label="الوصف"><Txt rows={2} value={catForm.description} onChange={e=>setCatForm(p=>({...p,description:e.target.value}))} /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="الأيقونة (إيموجي)">
                  <Inp value={catForm.icon} onChange={e=>setCatForm(p=>({...p,icon:e.target.value}))} placeholder="🍽️" maxLength={4} />
                </Field>
                <Field label="ترتيب العرض"><Inp type="number" value={catForm.sort_order} onChange={e=>setCatForm(p=>({...p,sort_order:e.target.value}))} /></Field>
              </div>
              {/* Quick icon picker */}
              <div className="flex flex-wrap gap-2">
                {['🍖','🍗','🍔','🍕','🥗','🍟','🍰','🥤','🍲','🥙','🍝','🐟','🍤','🥘','🧆','☕'].map(emoji=>(
                  <button key={emoji} type="button" onClick={()=>setCatForm(p=>({...p,icon:emoji}))}
                    className={`w-9 h-9 rounded-xl border text-lg flex items-center justify-center transition-all ${catForm.icon===emoji?'border-gold-500 bg-gold-500/10':'border-obsidian-700 hover:border-obsidian-600'}`}>
                    {emoji}
                  </button>
                ))}
              </div>
              {editCat && (
                <label className="flex items-center gap-3 cursor-pointer p-3 border border-obsidian-700 rounded-xl hover:border-gold-600 transition-colors">
                  <input type="checkbox" checked={!!catForm.is_active} onChange={e=>setCatForm(p=>({...p,is_active:e.target.checked?1:0}))} className="w-4 h-4 accent-gold-500" />
                  <span className="text-sm text-obsidian-300">✅ القسم ظاهر في المنيو</span>
                </label>
              )}
              <button onClick={saveCategory} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">
                {editCat?'💾 حفظ التعديلات':'✅ إضافة القسم'}
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// BRANCHES PAGE
// ══════════════════════════════════════════════════════════════
export function BranchesPage() {
  const [branches, setBranches] = useState([])
  const [showBranch, setShowBranch] = useState(false)
  const [showZone, setShowZone] = useState(null)
  const [showHours, setShowHours] = useState(null)
  const [editBranch, setEditBranch] = useState(null)
  const emptyB = { name:'',address:'',phone:'',whatsapp_number:'',notification_phone:'',is_active:1 }
  const emptyZ = { zone_name:'',delivery_price:'',delivery_time_minutes:45,min_order_amount:0,notes:'',is_active:1 }
  const [bForm, setBForm] = useState(emptyB)
  const [zForm, setZForm] = useState(emptyZ)
  const DAYS = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت']
  const [hours, setHours] = useState(DAYS.map((_,i)=>({ day_of_week:i, open_time:'10:00', close_time:'24:00', is_closed:0 })))

  const load = () => adminApi.getBranches().then(r => r.success && setBranches(r.data||[]))
  useEffect(load, [])

  const saveBranch = async () => {
    if (!bForm.name||!bForm.address) return toast.error('أدخل الاسم والعنوان')
    const res = editBranch ? await adminApi.updateBranch(editBranch.id,bForm) : await adminApi.createBranch(bForm)
    if (res.success) { toast.success('تم الحفظ'); setShowBranch(false); setEditBranch(null); load() }
    else toast.error(res.message||'خطأ')
  }

  const saveZone = async () => {
    if (!zForm.zone_name||!zForm.delivery_price) return toast.error('أدخل الاسم والسعر')
    const res = await adminApi.createZone({ ...zForm, branch_id: showZone })
    if (res.success) { toast.success('تمت الإضافة'); setShowZone(null); load() }
    else toast.error(res.message||'خطأ')
  }

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-black text-white">الفروع والمناطق 📍</h1>
        <button onClick={()=>{setEditBranch(null);setBForm(emptyB);setShowBranch(true)}} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ فرع جديد</button>
      </div>

      {branches.map(branch => (
        <div key={branch.id} className="bg-obsidian-800 border border-obsidian-700 rounded-2xl overflow-hidden">
          <div className="p-4 flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 ${branch.is_active?'bg-gold-500/10':'bg-obsidian-700'}`}>
              {branch.is_active?'🏪':'🔴'}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-black text-white">{branch.name}</h3>
              <p className="text-obsidian-500 text-sm truncate">{branch.address}</p>
              <div className="flex gap-3 mt-1 text-xs text-obsidian-600">
                {branch.phone && <span>📞 {branch.phone}</span>}
                {branch.whatsapp_number && <span>📱 {branch.whatsapp_number}</span>}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button onClick={()=>{setEditBranch(branch);setBForm({name:branch.name,address:branch.address,phone:branch.phone||'',whatsapp_number:branch.whatsapp_number||'',notification_phone:branch.notification_phone||'',is_active:branch.is_active});setShowBranch(true)}}
                className="w-8 h-8 bg-obsidian-700 border border-obsidian-600 rounded-xl flex items-center justify-center text-obsidian-400 hover:text-white text-sm transition-colors">✏️</button>
              <button onClick={()=>{const h=branch.working_hours||DAYS.map((_,i)=>({day_of_week:i,open_time:'10:00',close_time:'24:00',is_closed:0}));setHours(h);setShowHours(branch.id)}}
                className="w-8 h-8 bg-obsidian-700 border border-obsidian-600 rounded-xl flex items-center justify-center text-obsidian-400 hover:text-white text-sm transition-colors">🕐</button>
              <Toggle checked={!!branch.is_active} onChange={()=>adminApi.toggleBranch(branch.id).then(load)} />
            </div>
          </div>
          <div className="border-t border-obsidian-700 px-4 pb-4">
            <div className="flex items-center justify-between py-3">
              <span className="text-sm font-black text-obsidian-300">مناطق التوصيل ({branch.zones?.filter(z=>z.is_active).length||0}/{branch.zones?.length||0})</span>
              <button onClick={()=>{setZForm(emptyZ);setShowZone(branch.id)}}
                className="bg-obsidian-700 border border-obsidian-600 text-obsidian-300 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-obsidian-600 hover:text-white transition-colors">+ منطقة</button>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {(branch.zones||[]).map(z => (
                <div key={z.id} className={`flex items-center justify-between p-3 rounded-xl border transition-all ${z.is_active?'border-emerald-800 bg-emerald-950/20':'border-obsidian-700 bg-obsidian-700/30 opacity-60'}`}>
                  <div>
                    <div className="font-bold text-white text-sm">{z.zone_name}</div>
                    <div className="text-obsidian-500 text-xs">{parseFloat(z.delivery_price).toFixed(0)} ج | ⏱️ {z.delivery_time_minutes}د</div>
                    {z.notes && <div className="text-gold-600 text-xs">{z.notes}</div>}
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Toggle checked={!!z.is_active} onChange={()=>adminApi.updateZone(z.id,{...z,is_active:z.is_active?0:1}).then(load)} size="sm" />
                    <button onClick={()=>adminApi.deleteZone(z.id).then(load)} className="text-obsidian-600 hover:text-red-400 transition-colors text-sm">🗑️</button>
                  </div>
                </div>
              ))}
              {(!branch.zones||branch.zones.length===0) && <p className="text-obsidian-600 text-sm col-span-2 py-2">لا توجد مناطق بعد</p>}
            </div>
          </div>
        </div>
      ))}

      {/* Branch Form */}
      <AnimatePresence>
        {showBranch && (
          <Modal title={editBranch?'✏️ تعديل الفرع':'🏪 فرع جديد'} onClose={()=>setShowBranch(false)} maxW="max-w-md">
            <div className="space-y-4" dir="rtl">
              <div className="grid grid-cols-2 gap-3">
                <Field label="اسم الفرع *"><Inp value={bForm.name} onChange={e=>setBForm(p=>({...p,name:e.target.value}))} /></Field>
                <Field label="التليفون"><Inp value={bForm.phone} onChange={e=>setBForm(p=>({...p,phone:e.target.value}))} /></Field>
              </div>
              <Field label="العنوان *"><Txt rows={2} value={bForm.address} onChange={e=>setBForm(p=>({...p,address:e.target.value}))} /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="واتساب الفرع"><Inp value={bForm.whatsapp_number} onChange={e=>setBForm(p=>({...p,whatsapp_number:e.target.value}))} placeholder="01XXXXXXXXX" /></Field>
                <Field label="رقم الإشعارات"><Inp value={bForm.notification_phone} onChange={e=>setBForm(p=>({...p,notification_phone:e.target.value}))} placeholder="01XXXXXXXXX" /></Field>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <Toggle checked={!!bForm.is_active} onChange={()=>setBForm(p=>({...p,is_active:p.is_active?0:1}))} />
                <span className="text-sm text-obsidian-300">الفرع مفعّل</span>
              </label>
              <button onClick={saveBranch} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">💾 حفظ الفرع</button>
            </div>
          </Modal>
        )}
        {showZone && (
          <Modal title="📍 منطقة توصيل جديدة" onClose={()=>setShowZone(null)} maxW="max-w-md">
            <div className="space-y-4" dir="rtl">
              <Field label="اسم المنطقة *"><Inp value={zForm.zone_name} onChange={e=>setZForm(p=>({...p,zone_name:e.target.value}))} placeholder="مثال: المعادي" /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="سعر التوصيل (ج) *"><Inp type="number" value={zForm.delivery_price} onChange={e=>setZForm(p=>({...p,delivery_price:e.target.value}))} /></Field>
                <Field label="وقت التوصيل (د)"><Inp type="number" value={zForm.delivery_time_minutes} onChange={e=>setZForm(p=>({...p,delivery_time_minutes:e.target.value}))} /></Field>
              </div>
              <Field label="الحد الأدنى للطلب (ج)"><Inp type="number" value={zForm.min_order_amount} onChange={e=>setZForm(p=>({...p,min_order_amount:e.target.value}))} /></Field>
              <Field label="ملاحظة"><Inp value={zForm.notes} onChange={e=>setZForm(p=>({...p,notes:e.target.value}))} placeholder="مثال: توصيل بعد 6 مساءً فقط" /></Field>
              <button onClick={saveZone} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">✅ إضافة المنطقة</button>
            </div>
          </Modal>
        )}
        {showHours && (
          <Modal title="🕐 أوقات العمل" onClose={()=>setShowHours(null)}>
            <div className="space-y-2" dir="rtl">
              {hours.map((h,i)=>(
                <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${h.is_closed?'border-obsidian-700 opacity-60':'border-gold-800/30 bg-gold-950/10'}`}>
                  <span className="w-14 text-sm font-bold text-obsidian-300 flex-shrink-0">{DAYS[i]}</span>
                  <Toggle checked={!h.is_closed} onChange={()=>setHours(p=>p.map((d,j)=>j===i?{...d,is_closed:d.is_closed?0:1}:d))} size="sm" />
                  {!h.is_closed ? (
                    <>
                      <Inp type="time" value={h.open_time} onChange={e=>setHours(p=>p.map((d,j)=>j===i?{...d,open_time:e.target.value}:d))} className="flex-1 text-xs py-1.5" />
                      <span className="text-obsidian-500 text-xs">→</span>
                      <Inp type="time" value={h.close_time} onChange={e=>setHours(p=>p.map((d,j)=>j===i?{...d,close_time:e.target.value}:d))} className="flex-1 text-xs py-1.5" />
                    </>
                  ) : <span className="text-obsidian-500 text-xs flex-1">مغلق</span>}
                </div>
              ))}
              <button onClick={()=>adminApi.saveHours({branch_id:showHours,hours}).then(()=>{toast.success('تم الحفظ');setShowHours(null)})}
                className="btn-gold w-full py-3 rounded-xl font-bold text-sm mt-2">💾 حفظ الأوقات</button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// CUSTOMERS PAGE
// ══════════════════════════════════════════════════════════════
export function CustomersPage() {
  const [customers, setCustomers] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)

  const load = (q='') => { setLoading(true); adminApi.getCustomers(q).then(r=>{if(r.success)setCustomers(r.data||[]);setLoading(false)}) }
  useEffect(()=>load(),[])

  const toggleBlacklist = async (c) => {
    const newVal = c.is_blacklisted?0:1
    const reason = newVal ? prompt('سبب الحظر؟') : null
    if (newVal&&!reason) return
    await adminApi.blacklistCustomer(c.id,{is_blacklisted:newVal,reason})
    toast.success(newVal?'تم حظر العميل':'تم رفع الحظر')
    load(search)
    if (selected?.id===c.id) setSelected({...selected,is_blacklisted:newVal})
  }

  return (
    <div className="space-y-4" dir="rtl">
      <h1 className="text-xl font-black text-white">العملاء 👥</h1>
      <div className="relative">
        <span className="absolute start-3 top-1/2 -translate-y-1/2 text-obsidian-500 text-sm">🔍</span>
        <Inp value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load(search)}
          placeholder="ابحث بالاسم أو الهاتف..." className="ps-8" />
      </div>
      {loading?<div className="flex justify-center py-10"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>:(
        <div className="space-y-2">
          {customers.map(c=>(
            <div key={c.id} onClick={()=>setSelected(c)}
              className={`bg-obsidian-800 border border-obsidian-700 rounded-2xl p-4 cursor-pointer hover:border-gold-600/40 transition-all flex items-center gap-4 ${c.is_blacklisted?'border-red-900/50 opacity-70':''}`}>
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${c.is_blacklisted?'bg-red-900/20':'bg-gold-500/10'}`}>
                {c.is_blacklisted?'🚫':'👤'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-sm">{c.name||'بدون اسم'}</span>
                  {c.is_blacklisted&&<span className="text-[10px] bg-red-900/30 text-red-400 px-2 py-0.5 rounded-full border border-red-800">محظور</span>}
                </div>
                <div className="text-obsidian-500 text-xs">{c.whatsapp_number}</div>
                <div className="text-obsidian-600 text-xs mt-0.5">{c.total_orders||0} طلب | {parseFloat(c.total_spent||0).toFixed(0)} ج إجمالي</div>
              </div>
              <button onClick={e=>{e.stopPropagation();toggleBlacklist(c)}}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex-shrink-0 ${c.is_blacklisted?'bg-emerald-900/30 border border-emerald-800 text-emerald-400 hover:bg-emerald-900/50':'bg-red-900/30 border border-red-800 text-red-400 hover:bg-red-900/50'}`}>
                {c.is_blacklisted?'رفع الحظر':'حظر'}
              </button>
            </div>
          ))}
          {customers.length===0&&<Empty icon="👥" title="لا يوجد عملاء" />}
        </div>
      )}
      <AnimatePresence>
        {selected&&(
          <Modal title={`👤 ${selected.name||selected.whatsapp_number}`} onClose={()=>setSelected(null)}>
            <div className="space-y-3" dir="rtl">
              <div className="grid grid-cols-2 gap-3">
                {[['واتساب',selected.whatsapp_number],['الاسم',selected.name||'—'],['الهاتف',selected.phone||'—'],['إجمالي الطلبات',selected.total_orders||0],['إجمالي الإنفاق',`${parseFloat(selected.total_spent||0).toFixed(0)} ج`]].map(([l,v])=>(
                  <div key={l} className="bg-obsidian-700 rounded-xl p-3">
                    <div className="text-xs text-obsidian-500 mb-0.5">{l}</div>
                    <div className="font-bold text-white text-sm">{v}</div>
                  </div>
                ))}
              </div>
              {selected.blacklist_reason&&<div className="bg-red-900/20 border border-red-800 rounded-xl p-3 text-sm text-red-300">🚫 {selected.blacklist_reason}</div>}
              <button onClick={()=>toggleBlacklist(selected)}
                className={`w-full py-3 rounded-xl font-bold text-sm transition-colors ${selected.is_blacklisted?'bg-emerald-900/30 border border-emerald-800 text-emerald-400 hover:bg-emerald-900/50':'bg-red-900/30 border border-red-800 text-red-400 hover:bg-red-900/50'}`}>
                {selected.is_blacklisted?'✅ رفع الحظر':'🚫 حظر العميل'}
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// COUPONS PAGE
// ══════════════════════════════════════════════════════════════
export function CouponsPage() {
  const [coupons, setCoupons] = useState([])
  const [showForm, setShowForm] = useState(false)
  const empty = { code:'',description:'',type:'percentage',value:'',min_order_amount:0,max_discount:'',usage_limit:'',usage_per_customer:1,valid_from:'',valid_until:'' }
  const [form, setForm] = useState(empty)

  const load = () => adminApi.getCoupons().then(r=>r.success&&setCoupons(r.data||[]))
  useEffect(load,[])

  const save = async () => {
    if (!form.code||!form.value) return toast.error('أدخل الكود والقيمة')
    const payload = {
      ...form,
      code: form.code.toUpperCase(),
      valid_from: form.valid_from || null,
      valid_until: form.valid_until || null,
      max_discount: form.max_discount || null,
      usage_limit: form.usage_limit || null,
    }
    const res = await adminApi.createCoupon(payload)
    if (res.success){toast.success('تم الإنشاء');setShowForm(false);load()} else toast.error(res.message||'خطأ')
  }

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-black text-white">الكوبونات 🎫</h1>
        <button onClick={()=>{setForm(empty);setShowForm(true)}} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ كوبون جديد</button>
      </div>
      <div className="space-y-3">
        {coupons.map(c=>(
          <div key={c.id} className={`bg-obsidian-800 border border-obsidian-700 rounded-2xl p-4 flex items-center gap-4 ${!c.is_active?'opacity-60':''}`}>
            <div className="bg-gradient-to-br from-gold-900/40 to-obsidian-800 border border-gold-800/40 rounded-xl px-5 py-3 text-center flex-shrink-0">
              <div className="font-black text-gold-400 text-lg tracking-widest font-mono">{c.code}</div>
              <div className="text-gold-600 text-xs mt-0.5">{c.type==='percentage'?`${c.value}%`:`${c.value} ج`}</div>
            </div>
            <div className="flex-1 min-w-0">
              {c.description&&<div className="font-semibold text-white text-sm">{c.description}</div>}
              <div className="text-obsidian-500 text-xs space-y-0.5 mt-1">
                {parseFloat(c.min_order_amount)>0&&<div>حد أدنى: {c.min_order_amount} ج</div>}
                <div>استُخدم {c.used_count} مرة {c.usage_limit?`من ${c.usage_limit}`:''}</div>
                {c.valid_until&&<div>ينتهي: {new Date(c.valid_until).toLocaleDateString('ar-EG')}</div>}
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              <Toggle checked={!!c.is_active} onChange={()=>adminApi.toggleCoupon(c.id).then(load)} size="sm" />
              <button onClick={()=>adminApi.deleteCoupon(c.id).then(load)} className="text-obsidian-600 hover:text-red-400 transition-colors text-sm">🗑️</button>
            </div>
          </div>
        ))}
        {coupons.length===0&&<Empty icon="🎫" title="لا توجد كوبونات" />}
      </div>
      <AnimatePresence>
        {showForm&&(
          <Modal title="🎫 كوبون جديد" onClose={()=>setShowForm(false)} maxW="max-w-md">
            <div className="space-y-4" dir="rtl">
              <Field label="كود الكوبون *"><Inp value={form.code} onChange={e=>setForm(p=>({...p,code:e.target.value.toUpperCase()}))} placeholder="SUMMER25" className="font-mono tracking-widest font-bold text-gold-400" /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="نوع الخصم">
                  <Sel value={form.type} onChange={e=>setForm(p=>({...p,type:e.target.value}))}>
                    <option value="percentage">نسبة %</option>
                    <option value="fixed">مبلغ ثابت</option>
                  </Sel>
                </Field>
                <Field label="القيمة *"><Inp type="number" value={form.value} onChange={e=>setForm(p=>({...p,value:e.target.value}))} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="الحد الأدنى (ج)"><Inp type="number" value={form.min_order_amount} onChange={e=>setForm(p=>({...p,min_order_amount:e.target.value}))} /></Field>
                <Field label="حد أقصى للخصم"><Inp type="number" value={form.max_discount} onChange={e=>setForm(p=>({...p,max_discount:e.target.value}))} placeholder="اختياري" /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="عدد مرات الاستخدام"><Inp type="number" value={form.usage_limit} onChange={e=>setForm(p=>({...p,usage_limit:e.target.value}))} placeholder="غير محدود" /></Field>
                <Field label="لكل عميل"><Inp type="number" value={form.usage_per_customer} onChange={e=>setForm(p=>({...p,usage_per_customer:e.target.value}))} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="تاريخ البداية"><Inp type="datetime-local" value={form.valid_from} onChange={e=>setForm(p=>({...p,valid_from:e.target.value}))} /></Field>
                <Field label="تاريخ الانتهاء"><Inp type="datetime-local" value={form.valid_until} onChange={e=>setForm(p=>({...p,valid_until:e.target.value}))} /></Field>
              </div>
              <Field label="وصف"><Inp value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} /></Field>
              <button onClick={save} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">✅ إنشاء الكوبون</button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// OFFERS PAGE
// ══════════════════════════════════════════════════════════════
export function OffersPage() {
  const [offers, setOffers] = useState([])
  const [menuItems, setMenuItems] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editOffer, setEditOffer] = useState(null)
  const empty = { name:'',description:'',type:'combo',price:'',valid_from:'',valid_until:'',items:[] }
  const [form, setForm] = useState(empty)
  const [selItem, setSelItem] = useState(''); const [selQty, setSelQty] = useState(1)

  const load = async () => {
    const [o,m] = await Promise.all([adminApi.getOffers(),adminApi.getMenuItems({})])
    if(o.success)setOffers(o.data||[])
    if(m.success)setMenuItems(m.data||[])
  }
  useEffect(load,[])

  const addItem = () => {
    if (!selItem) return
    const item = menuItems.find(m=>m.id==selItem)
    if (!item||form.items.find(i=>i.item_id==selItem)) return
    setForm(p=>({...p,items:[...p.items,{item_id:item.id,item_name:item.name,price:item.price,quantity:selQty}]}))
    setSelItem(''); setSelQty(1)
  }

  const save = async () => {
    if (!form.name) return toast.error('أدخل اسم الأوفر')
    const payload = {
      ...form,
      valid_from: form.valid_from || null,
      valid_until: form.valid_until || null,
      price: form.price || null,
    }
    const res = editOffer ? await adminApi.updateOffer(editOffer.id,payload) : await adminApi.createOffer(payload)
    if(res.success){toast.success(editOffer?'تم التحديث':'تم الإنشاء');setShowForm(false);setEditOffer(null);load()} else toast.error(res.message||'خطأ')
  }

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-black text-white">الأوفر والعروض 🎁</h1>
        <button onClick={()=>{setEditOffer(null);setForm(empty);setShowForm(true)}} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ أوفر جديد</button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {offers.map(offer=>(
          <div key={offer.id} className={`bg-obsidian-800 border border-obsidian-700 rounded-2xl overflow-hidden ${!offer.is_active?'opacity-60':''}`}>
            {offer.image?<img src={offer.image} alt={offer.name} className="w-full h-36 object-cover"/>
              :<div className="w-full h-36 bg-gradient-to-br from-gold-900/20 to-obsidian-700 flex items-center justify-center text-5xl">🎁</div>}
            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-black text-white">{offer.name}</h3>
                {offer.price&&<span className="gold-text font-black text-lg">{parseFloat(offer.price).toFixed(0)} ج</span>}
              </div>
              {offer.description&&<p className="text-obsidian-400 text-xs mb-2">{offer.description}</p>}
              {(offer.items||[]).length>0&&(
                <div className="bg-obsidian-700/50 rounded-xl p-2 mb-3 space-y-1">
                  {offer.items.map((it,i)=>(
                    <div key={i} className="flex justify-between text-xs">
                      <span className="text-obsidian-300">{it.quantity}× {it.item_name}</span>
                      <span className="text-obsidian-500">{parseFloat(it.price||0).toFixed(0)} ج</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex items-center justify-between">
                <Toggle checked={!!offer.is_active} onChange={()=>adminApi.toggleOffer(offer.id).then(load)} size="sm" />
                <div className="flex gap-2">
                  <button onClick={()=>{setEditOffer(offer);setForm({name:offer.name,description:offer.description||'',type:offer.type,price:offer.price||'',valid_from:offer.valid_from||'',valid_until:offer.valid_until||'',items:(offer.items||[])});setShowForm(true)}}
                    className="w-8 h-8 bg-obsidian-700 rounded-xl text-obsidian-400 hover:text-white text-sm transition-colors flex items-center justify-center">✏️</button>
                  <button onClick={()=>adminApi.deleteOffer(offer.id).then(load)}
                    className="w-8 h-8 bg-obsidian-700 rounded-xl text-obsidian-400 hover:text-red-400 text-sm transition-colors flex items-center justify-center">🗑️</button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {offers.length===0&&<div className="col-span-3"><Empty icon="🎁" title="لا توجد عروض" /></div>}
      </div>
      <AnimatePresence>
        {showForm&&(
          <Modal title={editOffer?'✏️ تعديل الأوفر':'🎁 أوفر جديد'} onClose={()=>setShowForm(false)}>
            <div className="space-y-4" dir="rtl">
              <Field label="اسم الأوفر *"><Inp value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} placeholder="مثال: وجبة عيلة" /></Field>
              <Field label="الوصف"><Txt rows={2} value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="النوع">
                  <Sel value={form.type} onChange={e=>setForm(p=>({...p,type:e.target.value}))}>
                    <option value="combo">كومبو</option>
                    <option value="discount">خصم</option>
                    <option value="free_item">صنف مجاني</option>
                  </Sel>
                </Field>
                <Field label="سعر الأوفر (ج)"><Inp type="number" value={form.price} onChange={e=>setForm(p=>({...p,price:e.target.value}))} placeholder="اختياري" /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="تاريخ البداية"><Inp type="datetime-local" value={form.valid_from} onChange={e=>setForm(p=>({...p,valid_from:e.target.value}))} /></Field>
                <Field label="تاريخ الانتهاء"><Inp type="datetime-local" value={form.valid_until} onChange={e=>setForm(p=>({...p,valid_until:e.target.value}))} /></Field>
              </div>
              <div className="bg-gold-950/20 border border-gold-800/30 rounded-xl p-4 space-y-3">
                <p className="font-bold text-gold-400 text-sm">أصناف الأوفر</p>
                <div className="flex gap-2">
                  <Sel value={selItem} onChange={e=>setSelItem(e.target.value)} className="flex-1 text-sm">
                    <option value="">اختر صنف</option>
                    {menuItems.map(m=><option key={m.id} value={m.id}>{m.name} — {parseFloat(m.price).toFixed(0)} ج</option>)}
                  </Sel>
                  <Inp type="number" value={selQty} onChange={e=>setSelQty(parseInt(e.target.value)||1)} className="w-16 text-sm" min={1} />
                  <button onClick={addItem} className="btn-gold px-4 py-2 rounded-xl text-sm font-bold">+</button>
                </div>
                {form.items.map((it,i)=>(
                  <div key={i} className="flex items-center justify-between bg-obsidian-700 rounded-xl p-2.5 text-sm">
                    <span className="text-white">{it.quantity}× {it.item_name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-gold-400 text-xs">{parseFloat(it.price||0).toFixed(0)} ج</span>
                      <button onClick={()=>setForm(p=>({...p,items:p.items.filter((_,j)=>j!==i)}))} className="text-obsidian-500 hover:text-red-400 transition-colors">✕</button>
                    </div>
                  </div>
                ))}
              </div>
              <button onClick={save} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">
                {editOffer?'💾 حفظ التعديلات':'✅ إنشاء الأوفر'}
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// REPORTS PAGE
// ══════════════════════════════════════════════════════════════
export function ReportsPage() {
  const [data, setData] = useState(null)
  const [ratings, setRatings] = useState(null)
  const [from, setFrom] = useState(new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().split('T')[0])
  const [to, setTo] = useState(new Date().toISOString().split('T')[0])
  const [loading, setLoading] = useState(false)

  const load = async () => {
    setLoading(true)
    const [r,rat] = await Promise.all([adminApi.getReports({from,to}),adminApi.getRatings()])
    if(r.success)setData(r.data)
    if(rat.success)setRatings(rat.data)
    setLoading(false)
  }
  useEffect(load,[])

  const t = data?.totals||{}
  const cards = [
    {v:t.total_orders||0,l:'الطلبات',g:'from-blue-600 to-blue-700',icon:'📦'},
    {v:`${parseFloat(t.total_revenue||0).toFixed(0)} ج`,l:'الإيرادات',g:'from-emerald-600 to-emerald-700',icon:'💰'},
    {v:`${parseFloat(t.total_delivery||0).toFixed(0)} ج`,l:'دخل التوصيل',g:'from-orange-600 to-orange-700',icon:'🛵'},
    {v:`${parseFloat(t.total_discounts||0).toFixed(0)} ج`,l:'الخصومات',g:'from-red-600 to-red-700',icon:'🏷️'},
    {v:`${parseFloat(t.avg_order||0).toFixed(0)} ج`,l:'متوسط الطلب',g:'from-purple-600 to-purple-700',icon:'📊'},
    {v:data?.customers?.new_customers||0,l:'عملاء جدد',g:'from-teal-600 to-teal-700',icon:'👥'},
  ]

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <h1 className="text-xl font-black text-white">التقارير 📈</h1>
        <div className="flex flex-wrap gap-2 items-center">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-obsidian-500">من</span>
            <Inp type="date" value={from} onChange={e=>setFrom(e.target.value)} className="w-36 text-sm" />
            <span className="text-obsidian-500">إلى</span>
            <Inp type="date" value={to} onChange={e=>setTo(e.target.value)} className="w-36 text-sm" />
          </div>
          <button onClick={load} disabled={loading} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold disabled:opacity-50">
            {loading?'⏳...':'🔍 عرض'}
          </button>
          <a href={adminApi.exportCsv({from,to})} target="_blank" rel="noreferrer"
            className="bg-emerald-900/30 border border-emerald-800 text-emerald-400 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-900/50 transition-colors">
            📥 CSV
          </a>
        </div>
      </div>

      {loading&&<div className="flex justify-center py-10"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>}
      
      {!loading&&data&&(
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {cards.map((c,i)=>(
              <motion.div key={i} initial={{opacity:0,y:15}} animate={{opacity:1,y:0}} transition={{delay:i*0.05}}
                className={`bg-gradient-to-br ${c.g} rounded-2xl p-4 text-white`}>
                <div className="text-2xl mb-1">{c.icon}</div>
                <div className="text-xl font-black">{c.v}</div>
                <div className="text-white/70 text-xs mt-0.5">{c.l}</div>
              </motion.div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5">
              <h3 className="font-black text-white mb-4">🔥 أكثر الأصناف طلباً</h3>
              {(data.top_items||[]).map((item,i)=>(
                <div key={i} className="flex items-center gap-3 mb-3 last:mb-0">
                  <span className={`w-6 h-6 rounded-lg text-xs font-black text-white flex items-center justify-center flex-shrink-0 ${['bg-gold-500','bg-obsidian-500','bg-orange-600','bg-teal-600','bg-blue-600'][i]||'bg-obsidian-600'}`}>{i+1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-white truncate">{item.item_name}</div>
                    <div className="h-1 bg-obsidian-700 rounded mt-1">
                      <div className="h-1 bg-gold-500 rounded" style={{width:`${(item.total_qty/(data.top_items[0]?.total_qty||1))*100}%`}} />
                    </div>
                  </div>
                  <div className="text-right text-xs flex-shrink-0">
                    <div className="font-black text-white">{item.total_qty}</div>
                    <div className="text-obsidian-500">{parseFloat(item.revenue||0).toFixed(0)} ج</div>
                  </div>
                </div>
              ))}
              {!(data.top_items?.length)&&<p className="text-obsidian-500 text-sm text-center py-4">لا بيانات</p>}
            </div>

            <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5">
              <h3 className="font-black text-white mb-3">⭐ التقييمات</h3>
              {ratings?.summary&&(
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-4xl font-black text-gold-400">{parseFloat(ratings.summary.avg||0).toFixed(1)}</span>
                  <div>
                    <div className="text-gold-400 text-xl">{'★'.repeat(Math.round(ratings.summary.avg||0))}{'☆'.repeat(5-Math.round(ratings.summary.avg||0))}</div>
                    <div className="text-obsidian-500 text-xs">{ratings.summary.total} تقييم</div>
                  </div>
                </div>
              )}
              {[5,4,3,2,1].map(star=>{
                const r=ratings?.ratings?.find(x=>x.rating==star)
                return (
                  <div key={star} className="flex items-center gap-2 text-xs mb-2">
                    <span className="text-gold-400 w-12 text-sm">{'★'.repeat(star)}</span>
                    <div className="flex-1 h-2 bg-obsidian-700 rounded-full">
                      <div className="h-2 bg-gold-500 rounded-full transition-all" style={{width:`${r?.pct||0}%`}} />
                    </div>
                    <span className="text-obsidian-500 w-8 text-right">{r?.count||0}</span>
                  </div>
                )
              })}
              {/* Daily chart */}
              {(data.daily||[]).length>0&&(
                <>
                  <h4 className="font-black text-white mt-5 mb-3 text-sm">📅 المبيعات اليومية</h4>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {data.daily.map((d,i)=>(
                      <div key={i} className="flex items-center justify-between text-xs py-1.5 border-b border-obsidian-700 last:border-0">
                        <span className="text-obsidian-400">{new Date(d.date).toLocaleDateString('ar-EG',{weekday:'short',month:'short',day:'numeric'})}</span>
                        <div className="flex gap-3">
                          <span className="text-obsidian-500">{d.orders} طلب</span>
                          <span className="font-black text-emerald-400">{parseFloat(d.revenue||0).toFixed(0)} ج</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// AI PROVIDERS TAB — multi-provider AI with fallback
// ══════════════════════════════════════════════════════════════

// Provider presets: free models + how-to-get-token instructions
const AI_PROVIDER_PRESETS = {
  gemini: {
    label: 'Google Gemini',
    icon: '✨',
    color: 'from-blue-600 to-indigo-700',
    models: [
      { value: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash (موصى به - سريع ومجاني)' },
      { value: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash Lite (أخف وأسرع)' },
      { value: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash' },
    ],
    howTo: [
      'افتح aistudio.google.com/app/apikey',
      'سجّل دخول بحساب جوجل',
      'اضغط "Create API Key"',
      'انسخ المفتاح وضعه هنا',
    ],
    link: 'https://aistudio.google.com/app/apikey',
    free: 'مجاني بحد أقصى ~1500 طلب/يوم',
  },
  groq: {
    label: 'Groq',
    icon: '⚡',
    color: 'from-orange-600 to-red-700',
    models: [
      { value: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B (قوي جداً ومجاني)' },
      { value: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B (سريع جداً)' },
      { value: 'gemma2-9b-it', label: 'Gemma 2 9B' },
    ],
    howTo: [
      'افتح console.groq.com/keys',
      'سجّل دخول (مجاني بدون بطاقة)',
      'اضغط "Create API Key"',
      'انسخ المفتاح وضعه هنا',
    ],
    link: 'https://console.groq.com/keys',
    free: 'مجاني — سريع جداً (يصلح كـ Backup)',
  },
  openrouter: {
    label: 'OpenRouter',
    icon: '🌐',
    color: 'from-purple-600 to-pink-700',
    models: [
      { value: 'meta-llama/llama-3.3-70b-instruct:free', label: 'Llama 3.3 70B (مجاني)' },
      { value: 'google/gemini-2.0-flash-exp:free', label: 'Gemini 2.0 Flash Exp (مجاني)' },
      { value: 'deepseek/deepseek-chat-v3-0324:free', label: 'DeepSeek V3 (مجاني)' },
    ],
    howTo: [
      'افتح openrouter.ai/keys',
      'سجّل دخول (مجاني)',
      'اضغط "Create Key"',
      'انسخ المفتاح وضعه هنا (يبدأ بـ sk-or-)',
    ],
    link: 'https://openrouter.ai/keys',
    free: 'موديلات مجانية متعددة (لاحظ :free في الاسم)',
  },
}

function AiProvidersTab() {
  const [providers, setProviders] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editProvider, setEditProvider] = useState(null)
  const emptyForm = { provider:'gemini', display_name:'', api_key:'', model:AI_PROVIDER_PRESETS.gemini.models[0].value, is_active:1, is_default:0, priority:0 }
  const [form, setForm] = useState(emptyForm)

  const load = () => adminApi.getAiProviders().then(r=>{ if(r.success) setProviders(r.data||[]); setLoading(false) })
  useEffect(load,[])

  const openAdd = () => { setEditProvider(null); setForm(emptyForm); setShowForm(true) }
  const openEdit = (p) => { setEditProvider(p); setForm({...p, api_key: p.api_key ? '••••••••' : ''}); setShowForm(true) }

  const onProviderChange = (providerKey) => {
    const preset = AI_PROVIDER_PRESETS[providerKey]
    setForm(p => ({ ...p, provider: providerKey, model: preset.models[0].value, display_name: p.display_name || preset.label }))
  }

  const save = async () => {
    if (!form.display_name?.trim()) return toast.error('أدخل اسم يميّز هذا المزود')
    if (!editProvider && !form.api_key?.trim()) return toast.error('أدخل API Key')
    const payload = { ...form }
    const res = editProvider ? await adminApi.updateAiProvider(editProvider.id, payload) : await adminApi.createAiProvider(payload)
    if (res.success) { toast.success(editProvider?'تم التحديث':'تمت الإضافة'); setShowForm(false); load() }
    else toast.error(res.message||'خطأ')
  }

  const toggleActive = async (p) => { await adminApi.updateAiProvider(p.id, {...p, is_active: p.is_active?0:1, api_key:'••••••••'}); load() }
  const setDefault = async (p) => { await adminApi.updateAiProvider(p.id, {...p, is_default:1, api_key:'••••••••'}); load() }
  const remove = async (p) => { if(!confirm(`حذف "${p.display_name}"؟`)) return; await adminApi.deleteAiProvider(p.id); load() }

  if (loading) return <div className="flex justify-center py-10"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>

  return (
    <div className="space-y-4">
      <div className="bg-gold-950/20 border border-gold-800/30 rounded-xl p-4 text-sm text-gold-300 space-y-1">
        <p className="font-bold">🧠 نظام AI متعدد المزودين</p>
        <p className="text-xs text-gold-400/80 leading-relaxed">
          أضف أكتر من مزود AI مجاني. لو المزود الأساسي فشل (انتهت الحدود المجانية مثلاً)،
          البوت بيجرب المزود التالي تلقائياً بدون توقف. المزود المُعلّم "افتراضي" يُجرَّب أولاً.
        </p>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-obsidian-400 text-sm">{providers.length} مزود مُضاف</p>
        <button onClick={openAdd} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ إضافة مزود</button>
      </div>

      <div className="space-y-3">
        {providers.map(p => {
          const preset = AI_PROVIDER_PRESETS[p.provider] || {}
          return (
            <div key={p.id} className={`bg-obsidian-800 border rounded-2xl p-4 flex items-center gap-4 ${p.is_active?'border-obsidian-700':'border-obsidian-700 opacity-50'}`}>
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${preset.color||'from-obsidian-600 to-obsidian-700'} flex items-center justify-center text-2xl flex-shrink-0`}>
                {preset.icon||'🤖'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-white text-sm">{p.display_name}</span>
                  {!!p.is_default && <span className="text-[10px] bg-gold-500 text-obsidian-900 px-2 py-0.5 rounded-full font-bold">افتراضي</span>}
                  <span className="text-[10px] bg-obsidian-700 text-obsidian-400 px-2 py-0.5 rounded-full">أولوية {p.priority}</span>
                </div>
                <div className="text-obsidian-500 text-xs mt-0.5 truncate">{preset.label} · {p.model}</div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {!p.is_default && <button onClick={()=>setDefault(p)} className="text-obsidian-500 hover:text-gold-400 text-xs transition-colors">تعيين كافتراضي</button>}
                <Toggle checked={!!p.is_active} onChange={()=>toggleActive(p)} size="sm" />
                <button onClick={()=>openEdit(p)} className="w-8 h-8 bg-obsidian-700 rounded-xl text-obsidian-400 hover:text-white text-sm transition-colors flex items-center justify-center">✏️</button>
                <button onClick={()=>remove(p)} className="w-8 h-8 bg-obsidian-700 rounded-xl text-obsidian-400 hover:text-red-400 text-sm transition-colors flex items-center justify-center">🗑️</button>
              </div>
            </div>
          )
        })}
        {providers.length===0 && (
          <Empty icon="🧠" title="لا يوجد مزود AI" desc="أضف مزود واحد على الأقل ليعمل المساعد الذكي" />
        )}
      </div>

      <AnimatePresence>
        {showForm && (
          <Modal title={editProvider?`✏️ تعديل: ${editProvider.display_name}`:'🧠 إضافة مزود AI'} onClose={()=>setShowForm(false)} maxW="max-w-lg">
            <div className="space-y-4" dir="rtl">
              {/* Provider selector */}
              <div>
                <p className="text-xs font-bold text-obsidian-400 uppercase tracking-wide mb-2">المزود</p>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(AI_PROVIDER_PRESETS).map(([key, preset]) => (
                    <button key={key} type="button" onClick={()=>onProviderChange(key)}
                      disabled={!!editProvider}
                      className={`p-3 rounded-xl border-2 transition-all text-center ${form.provider===key?'border-gold-500 bg-gold-500/10':'border-obsidian-700 hover:border-obsidian-600'} ${editProvider?'opacity-50 cursor-not-allowed':''}`}>
                      <div className="text-2xl mb-1">{preset.icon}</div>
                      <div className="text-xs font-bold text-white">{preset.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* How to get token */}
              <div className="bg-obsidian-700/50 rounded-xl p-3 text-xs space-y-1.5">
                <p className="font-bold text-gold-400">🔑 إزاي تجيب الـ API Key؟ ({AI_PROVIDER_PRESETS[form.provider].free})</p>
                {AI_PROVIDER_PRESETS[form.provider].howTo.map((step,i)=>(
                  <p key={i} className="text-obsidian-400">{i+1}. {step}</p>
                ))}
                <a href={AI_PROVIDER_PRESETS[form.provider].link} target="_blank" rel="noreferrer"
                  className="inline-block text-gold-400 hover:text-gold-300 underline mt-1">
                  {AI_PROVIDER_PRESETS[form.provider].link} ↗
                </a>
              </div>

              <Field label="اسم يميّز هذا المزود *">
                <Inp value={form.display_name} onChange={e=>setForm(p=>({...p,display_name:e.target.value}))} placeholder="مثال: Gemini الأساسي" />
              </Field>

              <Field label="API Key *">
                <Inp value={form.api_key} onChange={e=>setForm(p=>({...p,api_key:e.target.value}))}
                  placeholder={editProvider?'اتركه •••••••• للحفاظ على المفتاح الحالي':'الصق المفتاح هنا'}
                  className="font-mono text-xs" type="password" />
              </Field>

              <Field label="الموديل">
                <Sel value={form.model} onChange={e=>setForm(p=>({...p,model:e.target.value}))}>
                  {AI_PROVIDER_PRESETS[form.provider].models.map(m=>(
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                </Sel>
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="الأولوية (0 = أول)">
                  <Inp type="number" value={form.priority} onChange={e=>setForm(p=>({...p,priority:e.target.value}))} min={0} />
                </Field>
                <div className="flex items-end gap-4 pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={!!form.is_active} onChange={e=>setForm(p=>({...p,is_active:e.target.checked?1:0}))} className="w-4 h-4 accent-gold-500" />
                    <span className="text-sm text-obsidian-300">مفعّل</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={!!form.is_default} onChange={e=>setForm(p=>({...p,is_default:e.target.checked?1:0}))} className="w-4 h-4 accent-gold-500" />
                    <span className="text-sm text-obsidian-300">افتراضي</span>
                  </label>
                </div>
              </div>

              <button onClick={save} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">
                {editProvider?'💾 حفظ التعديلات':'✅ إضافة المزود'}
              </button>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ══════════════════════════════════════════════════════════════
export function SettingsPage() {
  const [settings, setSettings] = useState(null)
  const [form, setForm] = useState({})
  const [faqs, setFaqs] = useState([])
  const [faqForm, setFaqForm] = useState({question:'',answer:'',category:'general'})
  const [showFaq, setShowFaq] = useState(false)
  const [tab, setTab] = useState('general')

  useEffect(()=>{
    adminApi.getSettings().then(r=>{if(r.success){setSettings(r.data);setForm(r.data)}})
    adminApi.getFaq().then(r=>r.success&&setFaqs(r.data||[]))
  },[])

  const save = async () => {
    const res = await adminApi.updateSettings(form)
    if(res.success)toast.success('✅ تم حفظ الإعدادات') else toast.error(res.message||'خطأ')
  }

  const toggle = async (field) => {
    const res = await (field==='is_open'?adminApi.toggleOpen():adminApi.toggleOrders())
    if(res.success){
      const key = Object.keys(res.data)[0]
      setForm(p=>({...p,[key]:res.data[key]}))
      toast.success(field==='is_open'?(res.data[key]?'🟢 المطعم مفتوح الآن':'🔴 المطعم مغلق الآن'):(res.data[key]?'⚠️ الطلبات موقوفة':'✅ الطلبات تعمل'))
    }
  }

  const addFaq = async () => {
    if(!faqForm.question||!faqForm.answer) return toast.error('أكمل السؤال والجواب')
    const res = await adminApi.addFaq(faqForm)
    if(res.success){toast.success('تمت الإضافة');setShowFaq(false);adminApi.getFaq().then(r=>r.success&&setFaqs(r.data||[]))} else toast.error('خطأ')
  }

  if(!settings) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>

  const TABS = [['general','⚙️ عام'],['bot','🤖 البوت'],['ai','🧠 مزودات AI'],['toggles','🔴 تحكم سريع'],['faq','❓ FAQ']]

  return (
    <div className="space-y-5 max-w-2xl" dir="rtl">
      <h1 className="text-xl font-black text-white">الإعدادات ⚙️</h1>
      <div className="flex gap-2 overflow-x-auto">
        {TABS.map(([k,l])=>(
          <button key={k} onClick={()=>setTab(k)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold border transition-all ${tab===k?'bg-gold-500 text-obsidian-900 border-gold-500':'bg-transparent text-obsidian-400 border-obsidian-700 hover:border-gold-600'}`}>
            {l}
          </button>
        ))}
      </div>

      {tab==='toggles'&&(
        <div className="space-y-4">
          {[
            {field:'is_open',label:'حالة المطعم',on:'🟢 مفتوح الآن',off:'🔴 مغلق الآن'},
            {field:'orders_paused',label:'الطلبات',on:'⚠️ موقوفة مؤقتاً',off:'✅ تعمل بشكل طبيعي',invert:true},
          ].map(item=>{
            const active = !!form[item.field]
            const isGood = item.invert?!active:active
            return (
              <div key={item.field} className={`bg-obsidian-800 border-2 rounded-2xl p-5 flex items-center justify-between ${isGood?'border-emerald-800':'border-red-900'}`}>
                <div>
                  <div className="font-black text-white mb-1">{item.label}</div>
                  <div className={`text-sm font-bold ${isGood?'text-emerald-400':'text-red-400'}`}>
                    {item.invert?(active?item.on:item.off):(active?item.on:item.off)}
                  </div>
                </div>
                <Toggle checked={active} onChange={()=>toggle(item.field)} />
              </div>
            )
          })}
        </div>
      )}

      {tab==='general'&&(
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="اسم المطعم *"><Inp value={form.name||''} onChange={e=>setForm(p=>({...p,name:e.target.value}))} /></Field>
            <Field label="العملة"><Inp value={form.currency||'جنيه'} onChange={e=>setForm(p=>({...p,currency:e.target.value}))} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="التليفون"><Inp value={form.phone||''} onChange={e=>setForm(p=>({...p,phone:e.target.value}))} /></Field>
            <Field label="البريد"><Inp value={form.email||''} onChange={e=>setForm(p=>({...p,email:e.target.value}))} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الحد الأدنى للطلب (ج)"><Inp type="number" value={form.min_order_amount||0} onChange={e=>setForm(p=>({...p,min_order_amount:e.target.value}))} /></Field>
            <Field label="الضريبة %"><Inp type="number" value={form.tax_percentage||0} onChange={e=>setForm(p=>({...p,tax_percentage:e.target.value}))} /></Field>
          </div>
          <Field label="رسالة الإغلاق"><Inp value={form.closed_message||''} onChange={e=>setForm(p=>({...p,closed_message:e.target.value}))} /></Field>
          <Field label="رسالة إيقاف الطلبات"><Inp value={form.paused_message||''} onChange={e=>setForm(p=>({...p,paused_message:e.target.value}))} /></Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="فيسبوك"><Inp value={form.facebook||''} onChange={e=>setForm(p=>({...p,facebook:e.target.value}))} /></Field>
            <Field label="انستجرام"><Inp value={form.instagram||''} onChange={e=>setForm(p=>({...p,instagram:e.target.value}))} /></Field>
            <Field label="الموقع"><Inp value={form.website||''} onChange={e=>setForm(p=>({...p,website:e.target.value}))} /></Field>
          </div>
          <button onClick={save} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">💾 حفظ الإعدادات</button>
        </div>
      )}

      {tab==='bot'&&(
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 space-y-4">
          <div className="bg-gold-950/20 border border-gold-800/30 rounded-xl p-3 text-xs text-gold-300">
            🤖 هذه الإعدادات تؤثر مباشرة على ردود الـ AI Bot
          </div>
          <Field label="اسم البوت"><Inp value={form.bot_name||'نور'} onChange={e=>setForm(p=>({...p,bot_name:e.target.value}))} /></Field>
          <Field label="رسالة الترحيب">
            <Txt rows={3} value={form.welcome_message||''} onChange={e=>setForm(p=>({...p,welcome_message:e.target.value}))} />
          </Field>
          <Field label="شخصية البوت (System Prompt)">
            <Txt rows={6} value={form.bot_personality||''} onChange={e=>setForm(p=>({...p,bot_personality:e.target.value}))} placeholder="اكتب كيف تريد البوت أن يتصرف..." />
          </Field>
          <button onClick={save} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">💾 حفظ إعدادات البوت</button>
        </div>
      )}

      {tab==='ai'&&<AiProvidersTab />}

      {tab==='faq'&&(
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-obsidian-400 text-sm">أسئلة يجاوب عنها البوت تلقائياً</p>
            <button onClick={()=>{setFaqForm({question:'',answer:'',category:'general'});setShowFaq(true)}} className="btn-gold px-4 py-2 rounded-xl text-xs font-bold">+ سؤال جديد</button>
          </div>
          <div className="space-y-3">
            {faqs.map((f,i)=>(
              <div key={i} className="bg-obsidian-800 border border-obsidian-700 rounded-xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <p className="font-bold text-white text-sm">❓ {f.question}</p>
                    <p className="text-obsidian-400 text-sm mt-1 leading-relaxed">✅ {f.answer}</p>
                  </div>
                  <button onClick={()=>adminApi.deleteFaq(f.id).then(()=>adminApi.getFaq().then(r=>r.success&&setFaqs(r.data||[])))}
                    className="text-obsidian-600 hover:text-red-400 transition-colors text-sm flex-shrink-0">🗑️</button>
                </div>
              </div>
            ))}
            {faqs.length===0&&<p className="text-obsidian-500 text-sm text-center py-6">لا أسئلة بعد. أضف أسئلة شائعة يسألها عملاؤك.</p>}
          </div>
          <AnimatePresence>
            {showFaq&&(
              <Modal title="❓ سؤال جديد" onClose={()=>setShowFaq(false)} maxW="max-w-md">
                <div className="space-y-4" dir="rtl">
                  <Field label="السؤال *"><Inp value={faqForm.question} onChange={e=>setFaqForm(p=>({...p,question:e.target.value}))} placeholder="مثال: ما أوقات العمل؟" /></Field>
                  <Field label="الجواب *"><Txt rows={3} value={faqForm.answer} onChange={e=>setFaqForm(p=>({...p,answer:e.target.value}))} placeholder="الجواب الذي سيقوله البوت..." /></Field>
                  <Field label="التصنيف">
                    <Sel value={faqForm.category} onChange={e=>setFaqForm(p=>({...p,category:e.target.value}))}>
                      <option value="general">عام</option>
                      <option value="delivery">توصيل</option>
                      <option value="payment">دفع</option>
                      <option value="menu">منيو</option>
                    </Sel>
                  </Field>
                  <button onClick={addFaq} className="btn-gold w-full py-3 rounded-xl font-bold text-sm">✅ إضافة السؤال</button>
                </div>
              </Modal>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
