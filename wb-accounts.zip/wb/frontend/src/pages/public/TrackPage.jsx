import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useT } from '../../components/ui'
import { useAppStore } from '../../store'
import { publicApi } from '../../api'

const ORDER_STEPS = [
  { key: 'new', icon: '📥', ar: 'تم الاستلام', en: 'Order Received' },
  { key: 'confirmed', icon: '✅', ar: 'تم التأكيد', en: 'Confirmed' },
  { key: 'preparing', icon: '👨‍🍳', ar: 'قيد التحضير', en: 'Preparing' },
  { key: 'ready', icon: '✨', ar: 'جاهز', en: 'Ready' },
  { key: 'out_for_delivery', icon: '🛵', ar: 'في الطريق', en: 'On The Way' },
  { key: 'delivered', icon: '🎉', ar: 'تم التسليم', en: 'Delivered' },
]

const STATUS_LABELS = {
  new: { ar: 'تم استلام طلبك!', en: 'Order Received!', icon: '🎉' },
  confirmed: { ar: 'تم تأكيد طلبك ✅', en: 'Order Confirmed ✅', icon: '✅' },
  preparing: { ar: 'طلبك قيد التحضير 👨‍🍳', en: 'Preparing your order 👨‍🍳', icon: '👨‍🍳' },
  ready: { ar: 'طلبك جاهز! ✨', en: 'Your order is ready! ✨', icon: '✨' },
  out_for_delivery: { ar: 'طلبك في الطريق 🛵', en: 'Your order is on the way 🛵', icon: '🛵' },
  delivered: { ar: 'تم تسليم طلبك 🎉', en: 'Order delivered 🎉', icon: '🎉' },
  cancelled: { ar: 'تم إلغاء الطلب', en: 'Order Cancelled', icon: '✕' },
}

export default function TrackPage() {
  const t = useT()
  const navigate = useNavigate()
  const { orderNumber } = useParams()
  const { state } = useLocation()
  const { settings } = useAppStore()
  const currency = settings?.currency || t('ج', 'EGP')

  // Seed from navigation state (just-placed order), then poll for live updates
  const initial = state?.order
  const [order, setOrder] = useState(initial ? {
    order_number: initial.order_number,
    status: 'new',
    total_amount: initial.total,
    estimated_time: initial.estimated_time,
  } : null)
  const [loading, setLoading] = useState(!initial)

  useEffect(() => {
    const num = orderNumber || initial?.order_number
    if (!num) return
    const poll = () => {
      publicApi.trackOrder(num).then(r => {
        if (r.success) setOrder(r.data)
        setLoading(false)
      }).catch(() => setLoading(false))
    }
    poll()
    const interval = setInterval(poll, 10000)
    return () => clearInterval(interval)
  }, [orderNumber])

  const status = order?.status || 'new'
  const currentIdx = ORDER_STEPS.findIndex(s => s.key === status)
  const isCancelled = status === 'cancelled'
  const label = STATUS_LABELS[status] || STATUS_LABELS.new

  if (loading) return (
    <div className="pt-20 min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  if (!order) return (
    <div className="pt-20 min-h-screen flex items-center justify-center px-4 text-center">
      <div>
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-xl font-black text-white mb-2">{t('الطلب غير موجود','Order not found')}</h1>
        <button onClick={() => navigate('/')} className="btn-gold px-6 py-3 rounded-xl mt-4">{t('الرئيسية','Home')}</button>
      </div>
    </div>
  )

  return (
    <div className="pt-20 min-h-screen flex items-center justify-center px-4 py-12">
      <div className="max-w-lg w-full">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring' }}
          className="text-center mb-8">
          <motion.div key={status} initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="text-7xl mb-4 anim-float">{label.icon}</motion.div>
          <h1 className="text-3xl font-black text-white mb-2">{t(label.ar, label.en)}</h1>
          <div className="gold-text text-2xl font-black">{order.order_number}</div>
        </motion.div>

        {/* Cancelled banner */}
        {isCancelled ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="bg-red-950/30 border border-red-800 rounded-2xl p-6 mb-5 text-center">
            <p className="text-red-400 font-bold mb-1">{t('تم إلغاء هذا الطلب','This order was cancelled')}</p>
            {order.cancel_reason && <p className="text-obsidian-400 text-sm">{order.cancel_reason}</p>}
          </motion.div>
        ) : (
          /* Progress tracker */
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-6 mb-5">
            <div className="relative">
              <div className="absolute top-5 start-[8%] end-[8%] h-0.5 bg-obsidian-700" />
              <div className="absolute top-5 start-[8%] h-0.5 bg-gradient-to-r from-gold-500 to-gold-300 transition-all duration-700"
                style={{ width: `${Math.max(0, (currentIdx / (ORDER_STEPS.length - 1)) * 84)}%` }} />

              <div className="relative flex justify-between">
                {ORDER_STEPS.map((step, i) => (
                  <div key={step.key} className="flex flex-col items-center gap-2 flex-1">
                    <motion.div
                      animate={{ scale: i === currentIdx ? [1, 1.2, 1] : 1 }}
                      transition={{ repeat: i === currentIdx ? Infinity : 0, duration: 1.5 }}
                      className={`w-10 h-10 rounded-full flex items-center justify-center text-lg transition-all border-2 z-10
                        ${i < currentIdx ? 'bg-gold-500 border-gold-500 text-obsidian-900'
                          : i === currentIdx ? 'bg-gold-500/20 border-gold-500 text-gold-400'
                          : 'bg-obsidian-700 border-obsidian-600 text-obsidian-500'}`}>
                      {i < currentIdx ? '✓' : step.icon}
                    </motion.div>
                    <span className={`text-[9px] sm:text-xs font-bold text-center leading-tight transition-colors
                      ${i === currentIdx ? 'text-gold-400' : i < currentIdx ? 'text-gold-600' : 'text-obsidian-600'}`}>
                      {t(step.ar, step.en)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Order details */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 mb-5 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-obsidian-400">{t('إجمالي الطلب', 'Order Total')}</span>
            <span className="gold-text font-black text-xl">{parseFloat(order.total_amount ?? order.total ?? 0).toFixed(0)} {currency}</span>
          </div>
          {order.estimated_time && !isCancelled && (
            <div className="flex justify-between text-sm">
              <span className="text-obsidian-400">{t('وقت التوصيل المتوقع', 'Est. Delivery')}</span>
              <span className="text-white font-bold">⏱️ {order.estimated_time} {t('دقيقة', 'min')}</span>
            </div>
          )}
          {!isCancelled && (
            <div className="bg-gold-900/20 border border-gold-800/30 rounded-xl p-3 text-sm text-gold-300 text-center">
              {t('الصفحة تتحدث تلقائياً 🔄', 'This page updates automatically 🔄')}
            </div>
          )}
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
          className="flex gap-3">
          <button onClick={() => navigate('/')} className="btn-gold flex-1 py-3 rounded-xl text-sm font-bold">
            {t('الرئيسية', 'Home')}
          </button>
          <button onClick={() => navigate('/menu')} className="btn-ghost flex-1 py-3 rounded-xl text-sm font-bold">
            {t('طلب جديد', 'New Order')}
          </button>
        </motion.div>
      </div>
    </div>
  )
}
