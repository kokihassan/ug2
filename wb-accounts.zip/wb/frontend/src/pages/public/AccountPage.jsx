import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '../../store'
import { publicApi } from '../../api'
import { useT, Empty, StatusBadge } from '../../components/ui'
import toast from 'react-hot-toast'

const ORDER_STEPS = [
  { key: 'new', icon: '📥', ar: 'تم الاستلام', en: 'Received' },
  { key: 'confirmed', icon: '✅', ar: 'تم التأكيد', en: 'Confirmed' },
  { key: 'preparing', icon: '👨‍🍳', ar: 'قيد التحضير', en: 'Preparing' },
  { key: 'ready', icon: '✨', ar: 'جاهز', en: 'Ready' },
  { key: 'out_for_delivery', icon: '🛵', ar: 'في الطريق', en: 'On The Way' },
  { key: 'delivered', icon: '🎉', ar: 'تم التسليم', en: 'Delivered' },
]

export default function AccountPage() {
  const t = useT()
  const { authCustomer, setAuthCustomer, logoutCustomer } = useAppStore()
  const [loading, setLoading] = useState(true)

  // On mount, verify token is still valid and refresh profile
  useEffect(() => {
    const token = localStorage.getItem('customer_token')
    if (!token) { setLoading(false); return }
    publicApi.getMe().then(r => {
      if (r.success) setAuthCustomer(r.data)
      else logoutCustomer()
      setLoading(false)
    }).catch(() => { logoutCustomer(); setLoading(false) })
  }, [])

  if (loading) return (
    <div className="pt-24 min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="pt-20 min-h-screen">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {authCustomer ? <AccountDashboard /> : <AuthForm />}
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// AUTH FORM — Login / Register
// ══════════════════════════════════════════════════════════════
function AuthForm() {
  const t = useT()
  const { setAuthCustomer } = useAppStore()
  const [mode, setMode] = useState('login') // 'login' | 'register'
  const [form, setForm] = useState({ name: '', whatsapp_number: '', password: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const submit = async () => {
    setError('')
    if (!form.whatsapp_number.trim()) return setError(t('أدخل رقم الهاتف', 'Enter phone number'))
    if (!form.password.trim()) return setError(t('أدخل كلمة المرور', 'Enter password'))
    if (mode === 'register' && form.password.length < 6) return setError(t('كلمة المرور 6 أحرف على الأقل', 'Password must be 6+ characters'))

    setLoading(true)
    try {
      const res = mode === 'login'
        ? await publicApi.login({ whatsapp_number: form.whatsapp_number, password: form.password })
        : await publicApi.register(form)

      if (res.success) {
        localStorage.setItem('customer_token', res.data.token)
        setAuthCustomer(res.data.customer)
        toast.success(mode === 'login' ? t('أهلاً بعودتك! 👋', 'Welcome back! 👋') : t('تم إنشاء حسابك بنجاح 🎉', 'Account created 🎉'))
      } else {
        setError(res.message || t('حدث خطأ', 'An error occurred'))
      }
    } catch (e) {
      setError(e.message || t('حدث خطأ', 'An error occurred'))
    }
    setLoading(false)
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
      <div className="text-center mb-8">
        <div className="text-5xl mb-3">👤</div>
        <h1 className="text-2xl font-black text-white">
          {mode === 'login' ? t('تسجيل الدخول', 'Sign In') : t('حساب جديد', 'Create Account')}
        </h1>
        <p className="text-obsidian-500 text-sm mt-1">
          {t('لمتابعة طلباتك وحفظ بياناتك', 'Track your orders and save your info')}
        </p>
      </div>

      <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-6 space-y-4">
        {/* Mode tabs */}
        <div className="grid grid-cols-2 gap-2 bg-obsidian-900 rounded-xl p-1">
          {[['login', t('تسجيل الدخول','Sign In')], ['register', t('حساب جديد','Sign Up')]].map(([m, label]) => (
            <button key={m} onClick={() => { setMode(m); setError('') }}
              className={`py-2 rounded-lg text-sm font-bold transition-all ${mode===m?'bg-gold-500 text-obsidian-900':'text-obsidian-400'}`}>
              {label}
            </button>
          ))}
        </div>

        {error && <div className="bg-red-900/20 border border-red-800 rounded-xl p-3 text-red-400 text-sm">⚠️ {error}</div>}

        {mode === 'register' && (
          <div>
            <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('الاسم','Name')}</label>
            <input value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} className="input-gold" placeholder={t('اسمك','Your name')} />
          </div>
        )}

        <div>
          <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('رقم الهاتف *','Phone *')}</label>
          <input type="tel" value={form.whatsapp_number} onChange={e=>setForm(p=>({...p,whatsapp_number:e.target.value}))}
            className="input-gold" placeholder="01xxxxxxxxx" />
        </div>

        <div>
          <label className="block text-xs text-obsidian-400 font-bold uppercase tracking-wide mb-1.5">{t('كلمة المرور *','Password *')}</label>
          <input type="password" value={form.password} onChange={e=>setForm(p=>({...p,password:e.target.value}))}
            onKeyDown={e=>e.key==='Enter' && submit()}
            className="input-gold" placeholder="••••••••" />
        </div>

        <button onClick={submit} disabled={loading} className="btn-gold w-full py-3.5 rounded-xl font-bold text-sm disabled:opacity-50">
          {loading ? t('⏳ جاري التحميل...','⏳ Loading...') : mode === 'login' ? t('دخول ←','Sign In →') : t('إنشاء الحساب ←','Create Account →')}
        </button>

        {mode === 'register' && (
          <p className="text-center text-xs text-obsidian-600">
            {t('لو سبق وطلبت بنفس رقم الهاتف، حسابك هيتربط تلقائياً بطلباتك السابقة', 'If you ordered before with this number, your history will link automatically')}
          </p>
        )}
      </div>
    </motion.div>
  )
}

// ══════════════════════════════════════════════════════════════
// ACCOUNT DASHBOARD — profile + order history
// ══════════════════════════════════════════════════════════════
function AccountDashboard() {
  const t = useT()
  const { settings, authCustomer, logoutCustomer } = useAppStore()
  const navigate = useNavigate()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const currency = settings?.currency || t('ج','EGP')

  const load = () => {
    publicApi.getMyOrders().then(r => { if (r.success) setOrders(r.data || []); setLoading(false) })
  }

  // Poll order list every 20s so statuses update without manual refresh
  useEffect(() => {
    load()
    const interval = setInterval(load, 20000)
    return () => clearInterval(interval)
  }, [])

  const handleLogout = () => {
    logoutCustomer()
    toast.success(t('تم تسجيل الخروج','Logged out'))
  }

  const activeOrders = orders.filter(o => !['delivered','cancelled'].includes(o.status))
  const pastOrders = orders.filter(o => ['delivered','cancelled'].includes(o.status))

  return (
    <div>
      {/* Profile header */}
      <div className="flex items-center gap-4 mb-6">
        <div className="w-14 h-14 rounded-2xl bg-gold-gradient flex items-center justify-center text-2xl flex-shrink-0">👤</div>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black text-white truncate">{authCustomer.name || t('عميلنا العزيز','Valued Customer')}</h1>
          <p className="text-obsidian-500 text-sm">{authCustomer.whatsapp_number}</p>
        </div>
        <button onClick={handleLogout} className="btn-ghost px-4 py-2 rounded-xl text-xs font-bold flex-shrink-0">
          🚪 {t('خروج','Logout')}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-xl p-4 text-center">
          <div className="gold-text text-2xl font-black">{authCustomer.total_orders || 0}</div>
          <div className="text-obsidian-500 text-xs mt-1">{t('إجمالي الطلبات','Total Orders')}</div>
        </div>
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-xl p-4 text-center">
          <div className="gold-text text-2xl font-black">{parseFloat(authCustomer.total_spent||0).toFixed(0)} {currency}</div>
          <div className="text-obsidian-500 text-xs mt-1">{t('إجمالي الإنفاق','Total Spent')}</div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
      ) : orders.length === 0 ? (
        <Empty icon="📦" title={t('لا توجد طلبات بعد','No orders yet')}
          desc={t('ابدأ بطلب أول وجبة لك','Place your first order')}
          action={<button onClick={()=>navigate('/menu')} className="btn-gold px-8 py-3 rounded-xl mt-2">{t('تصفح المنيو','Browse Menu')}</button>} />
      ) : (
        <div className="space-y-6">
          {/* Active orders with live tracker */}
          {activeOrders.length > 0 && (
            <div>
              <h2 className="text-sm font-black text-gold-400 mb-3 uppercase tracking-wide">🔥 {t('طلبات جارية','Active Orders')}</h2>
              <div className="space-y-3">
                {activeOrders.map(o => <ActiveOrderCard key={o.id} order={o} currency={currency} t={t} />)}
              </div>
            </div>
          )}

          {/* Past orders */}
          {pastOrders.length > 0 && (
            <div>
              <h2 className="text-sm font-black text-obsidian-400 mb-3 uppercase tracking-wide">📜 {t('طلبات سابقة','Order History')}</h2>
              <div className="space-y-2">
                {pastOrders.map(o => (
                  <div key={o.id} onClick={()=>setSelected(o)}
                    className="bg-obsidian-800 border border-obsidian-700 rounded-xl p-4 flex items-center justify-between cursor-pointer hover:border-gold-600/40 transition-all">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-white text-sm">{o.order_number}</span>
                        <StatusBadge status={o.status} />
                      </div>
                      <div className="text-obsidian-500 text-xs">{new Date(o.created_at).toLocaleDateString('ar-EG',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</div>
                    </div>
                    <span className="gold-text font-black">{parseFloat(o.total_amount||0).toFixed(0)} {currency}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Order detail modal */}
      <AnimatePresence>
        {selected && (
          <OrderDetailModal order={selected} currency={currency} t={t} onClose={()=>setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── Active order card with live progress tracker ────────────────
function ActiveOrderCard({ order, currency, t }) {
  const currentIdx = ORDER_STEPS.findIndex(s => s.key === order.status)
  return (
    <div className="bg-obsidian-800 border-2 border-gold-600/30 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="font-black text-white text-sm">{order.order_number}</span>
        <span className="gold-text font-black text-sm">{parseFloat(order.total_amount||0).toFixed(0)} {currency}</span>
      </div>
      {/* Mini progress tracker */}
      <div className="relative mb-2">
        <div className="absolute top-3 start-[6%] end-[6%] h-0.5 bg-obsidian-700" />
        <div className="absolute top-3 start-[6%] h-0.5 bg-gradient-to-r from-gold-500 to-gold-300 transition-all duration-700"
          style={{ width: `${Math.max(0,(currentIdx/(ORDER_STEPS.length-1)))*88}%` }} />
        <div className="relative flex justify-between">
          {ORDER_STEPS.map((step,i)=>(
            <div key={step.key} className="flex flex-col items-center gap-1 flex-1">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs border-2 z-10
                ${i<currentIdx?'bg-gold-500 border-gold-500 text-obsidian-900':i===currentIdx?'bg-gold-500/20 border-gold-500 text-gold-400 animate-pulse':'bg-obsidian-700 border-obsidian-600 text-obsidian-500'}`}>
                {i<currentIdx?'✓':step.icon}
              </div>
              <span className={`text-[8px] text-center leading-tight ${i===currentIdx?'text-gold-400 font-bold':'text-obsidian-600'}`}>{t(step.ar,step.en)}</span>
            </div>
          ))}
        </div>
      </div>
      {order.estimated_time && (
        <p className="text-center text-obsidian-500 text-xs mt-2">⏱️ {t('الوقت المتوقع','Est. time')}: {order.estimated_time} {t('دقيقة','min')}</p>
      )}
    </div>
  )
}

// ─── Order detail modal ────────────────────────────────────────
function OrderDetailModal({ order, currency, t, onClose }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
        className="bg-obsidian-800 border border-obsidian-700 rounded-2xl max-w-md w-full max-h-[85vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
        <div className="p-5 border-b border-obsidian-700 flex items-center justify-between">
          <div>
            <h3 className="font-black text-white">{order.order_number}</h3>
            <StatusBadge status={order.status} />
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl bg-obsidian-700 text-obsidian-300 text-sm">✕</button>
        </div>
        <div className="p-5 space-y-2">
          {(order.items||[]).map((item,i)=>(
            <div key={i} className="flex justify-between text-sm gap-2">
              <div className="min-w-0">
                <span className="text-obsidian-300">{item.quantity}× {item.item_name}</span>
                {item.size_name && <span className="text-obsidian-500 text-xs"> ({item.size_name})</span>}
                {item.extras?.length>0 && <div className="text-obsidian-500 text-xs">+ {item.extras.join('، ')}</div>}
              </div>
              <span className="font-bold text-white whitespace-nowrap">{parseFloat(item.total_price||0).toFixed(0)} {currency}</span>
            </div>
          ))}
          <div className="border-t border-obsidian-700 pt-3 flex justify-between">
            <span className="font-black text-white">{t('الإجمالي','Total')}</span>
            <span className="gold-text font-black text-lg">{parseFloat(order.total_amount||0).toFixed(0)} {currency}</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}
