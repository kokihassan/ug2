import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import { Toaster } from 'react-hot-toast'
import { useAppStore } from './store'
import { publicApi } from './api'

// Public
import PublicLayout from './layouts/PublicLayout'
import HomePage from './pages/public/HomePage'
import MenuPage from './pages/public/MenuPage'
import CartPage from './pages/public/CartPage'
import TrackPage from './pages/public/TrackPage'
import AccountPage from './pages/public/AccountPage'

// Admin
import AdminLayout from './layouts/AdminLayout'
import LoginPage from './pages/admin/LoginPage'
import {
  DashboardPage, OrdersPage, AdminMenuPage, BranchesPage,
  CustomersPage, CouponsPage, OffersPage, ReportsPage, SettingsPage
} from './pages/admin/AdminPages'

function AdminGuard({ children }) {
  const token = localStorage.getItem('admin_token')
  if (!token) return <Navigate to="/admin/login" replace />
  return children
}

export default function App() {
  const { isDark, setSettings, setBranches } = useAppStore()

  useEffect(() => {
    document.body.className = isDark ? 'dark' : 'light'
  }, [isDark])

  useEffect(() => {
    publicApi.getSettings().then(r => { if (r.success) setSettings(r.data) }).catch(() => {})
    publicApi.getBranches().then(r => { if (r.success) setBranches(r.data) }).catch(() => {})
  }, [])

  return (
    <>
      <Toaster position="top-center" toastOptions={{
        style: {
          background: isDark ? '#1e1e1a' : '#fff',
          color: isDark ? '#f0ede8' : '#1a1a14',
          border: '1px solid #c9a84c40',
          fontFamily: 'inherit',
        },
        success: { iconTheme: { primary: '#c9a84c', secondary: '#0a0a08' } },
      }} />
      <Routes>
        <Route path="/" element={<PublicLayout />}>
          <Route index element={<HomePage />} />
          <Route path="menu" element={<MenuPage />} />
          <Route path="cart" element={<CartPage />} />
          <Route path="track/:orderNumber" element={<TrackPage />} />
          <Route path="account" element={<AccountPage />} />
        </Route>
        <Route path="/admin/login" element={<LoginPage />} />
        <Route path="/admin" element={<AdminGuard><AdminLayout /></AdminGuard>}>
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="orders" element={<OrdersPage />} />
          <Route path="menu" element={<AdminMenuPage />} />
          <Route path="branches" element={<BranchesPage />} />
          <Route path="customers" element={<CustomersPage />} />
          <Route path="coupons" element={<CouponsPage />} />
          <Route path="offers" element={<OffersPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  )
}
