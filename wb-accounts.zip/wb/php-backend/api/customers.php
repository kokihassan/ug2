<?php
// api/customers.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    // ─── Customer Account: Register (phone + password) ────────────
    case 'POST:register':
        $data = json_decode(file_get_contents('php://input'), true);
        $phone = trim($data['whatsapp_number'] ?? '');
        $password = $data['password'] ?? '';
        $name = trim($data['name'] ?? '');
        if (!$phone || !$password) error('رقم الهاتف وكلمة المرور مطلوبان');
        if (strlen($password) < 6) error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');

        $db = getDB();
        $stmt = $db->prepare("SELECT id, password FROM customers WHERE whatsapp_number=?");
        $stmt->execute([$phone]);
        $existing = $stmt->fetch();

        if ($existing) {
            if (!empty($existing['password'])) {
                error('هذا الرقم مسجل بالفعل، يرجى تسجيل الدخول');
            }
            // Existing guest customer (created via get-or-create) — add password
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare("UPDATE customers SET password=?, name=COALESCE(NULLIF(name,''), ?) WHERE id=?")
               ->execute([$hash, $name, $existing['id']]);
            $customerId = $existing['id'];
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare("INSERT INTO customers (whatsapp_number, password, name) VALUES (?,?,?)")
               ->execute([$phone, $hash, $name]);
            $customerId = $db->lastInsertId();
        }

        $token = generateToken(['customer_id' => $customerId, 'type' => 'customer']);
        $cust = $db->prepare("SELECT id, whatsapp_number, name, phone, email FROM customers WHERE id=?");
        $cust->execute([$customerId]);
        success(['token' => $token, 'customer' => $cust->fetch()], 'تم إنشاء الحساب بنجاح', 201);

    // ─── Customer Account: Login ───────────────────────────────────
    case 'POST:login':
        $data = json_decode(file_get_contents('php://input'), true);
        $phone = trim($data['whatsapp_number'] ?? '');
        $password = $data['password'] ?? '';
        if (!$phone || !$password) error('رقم الهاتف وكلمة المرور مطلوبان');

        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM customers WHERE whatsapp_number=?");
        $stmt->execute([$phone]);
        $customer = $stmt->fetch();

        if (!$customer || empty($customer['password']) || !password_verify($password, $customer['password'])) {
            error('رقم الهاتف أو كلمة المرور غير صحيحة', 401);
        }
        if ($customer['is_blacklisted']) {
            error('هذا الحساب محظور. تواصل مع المطعم لمزيد من المعلومات', 403);
        }

        $token = generateToken(['customer_id' => $customer['id'], 'type' => 'customer']);
        unset($customer['password']);
        success(['token' => $token, 'customer' => $customer], 'تم تسجيل الدخول');

    // ─── Customer Account: Get current profile ─────────────────────
    case 'GET:me':
        $customerData = requireCustomerAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT id, whatsapp_number, name, phone, email, total_orders, total_spent FROM customers WHERE id=?");
        $stmt->execute([$customerData['customer_id']]);
        $customer = $stmt->fetch();
        if (!$customer) error('الحساب غير موجود', 404);

        $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
        $addrs->execute([$customer['id']]);
        $customer['addresses'] = $addrs->fetchAll();
        success($customer);

    // ─── Customer Account: My Orders ────────────────────────────────
    case 'GET:my-orders':
        $customerData = requireCustomerAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT o.*, b.name as branch_name FROM orders o LEFT JOIN branches b ON o.branch_id=b.id WHERE o.customer_id=? ORDER BY o.created_at DESC LIMIT 50");
        $stmt->execute([$customerData['customer_id']]);
        $orders = $stmt->fetchAll();
        foreach ($orders as &$order) {
            $items = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
            $items->execute([$order['id']]);
            $orderItems = $items->fetchAll();
            foreach ($orderItems as &$oi) {
                $oi['extras'] = !empty($oi['extras']) ? json_decode($oi['extras'], true) : [];
            }
            $order['items'] = $orderItems;
        }
        success($orders);

    // ─── Get or create customer by WhatsApp ──────────────────────
    case 'POST:get-or-create':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("SELECT c.*, GROUP_CONCAT(ca.label,':', ca.address ORDER BY ca.is_default DESC SEPARATOR '||') as addresses_str FROM customers c LEFT JOIN customer_addresses ca ON c.id=ca.customer_id WHERE c.whatsapp_number=? GROUP BY c.id");
        $stmt->execute([$data['whatsapp_number']]);
        $customer = $stmt->fetch();
        
        if (!$customer) {
            $db->prepare("INSERT INTO customers (whatsapp_number) VALUES (?)")->execute([$data['whatsapp_number']]);
            $customer = ['id' => $db->lastInsertId(), 'whatsapp_number' => $data['whatsapp_number'], 'name' => null, 'is_blacklisted' => 0, 'total_orders' => 0, 'addresses' => []];
        } else {
            $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
            $addrs->execute([$customer['id']]);
            $customer['addresses'] = $addrs->fetchAll();
            
            // Get last order
            $lastOrder = $db->prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY created_at DESC LIMIT 1");
            $lastOrder->execute([$customer['id']]);
            $customer['last_order'] = $lastOrder->fetch();
            
            // Get favorite items
            $favs = $db->prepare("SELECT oi.item_name, SUM(oi.quantity) as count FROM order_items oi JOIN orders o ON oi.order_id=o.id WHERE o.customer_id=? GROUP BY oi.item_name ORDER BY count DESC LIMIT 3");
            $favs->execute([$customer['id']]);
            $customer['favorite_items'] = $favs->fetchAll();
        }
        success($customer);

    case 'PUT:update':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET name=?, phone=?, email=? WHERE whatsapp_number=?")
           ->execute([$data['name'], $data['phone']??null, $data['email']??null, $data['whatsapp_number']]);
        success([], 'تم تحديث البيانات');

    case 'POST:add-address':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        // Set default to 0 for others if this is default
        if ($data['is_default'] ?? 0) {
            $db->prepare("UPDATE customer_addresses SET is_default=0 WHERE customer_id=?")->execute([$data['customer_id']]);
        }
        $db->prepare("INSERT INTO customer_addresses (customer_id, label, address, area, zone_id, is_default) VALUES (?,?,?,?,?,?)")
           ->execute([$data['customer_id'], $data['label']??'بيت', $data['address'], $data['area']??null, $data['zone_id']??null, $data['is_default']??0]);
        success(['id' => $db->lastInsertId()], 'تم حفظ العنوان');

    // ─── ADMIN: List customers ────────────────────────────────────
    case 'GET:list':
        requireAuth();
        $db = getDB();
        $search = $_GET['search'] ?? null;
        $sql = "SELECT c.*, COUNT(o.id) as order_count, SUM(o.total_amount) as total_spent FROM customers c LEFT JOIN orders o ON c.id=o.customer_id WHERE 1=1";
        $params = [];
        if ($search) { $sql .= " AND (c.name LIKE ? OR c.whatsapp_number LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $sql .= " GROUP BY c.id ORDER BY c.created_at DESC LIMIT 50";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        success($stmt->fetchAll());

    case 'PUT:blacklist':
        requireAuth();
        $id = $path[1] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET is_blacklisted=?, blacklist_reason=? WHERE id=?")
           ->execute([$data['is_blacklisted'], $data['reason']??null, $id]);
        success([], 'تم التحديث');

    default:
        error('Action not found', 404);
}
