<?php
// ============================================================
// PATCH for /var/www/restaurant/config.php
// Adds: customer-token-aware requireAuth(), requireCustomerAuth(),
//       optionalCustomerAuth()
//
// HOW TO APPLY:
//   1. Open /var/www/restaurant/config.php
//   2. Find the existing `function requireAuth() { ... }` block
//   3. REPLACE it entirely with the requireAuth() below
//   4. ADD the requireCustomerAuth() and optionalCustomerAuth()
//      functions anywhere after it (e.g. right after requireAuth)
// ============================================================

function requireAuth() {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    $token = null;
    if (str_starts_with($auth, 'Bearer ')) {
        $token = substr($auth, 7);
    } elseif (!empty($_GET['token'])) {
        $token = $_GET['token'];
    }
    if (!$token) error('Unauthorized', 401);
    $data = verifyToken($token);
    if (!$data || ($data['type'] ?? '') === 'customer') error('Invalid or expired token', 401);
    return $data;
}

// ============================================================
// CUSTOMER AUTH (separate token type from admin)
// ============================================================
function requireCustomerAuth() {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!str_starts_with($auth, 'Bearer ')) error('يجب تسجيل الدخول', 401);
    $data = verifyToken(substr($auth, 7));
    if (!$data || ($data['type'] ?? '') !== 'customer') error('جلسة غير صالحة، يرجى تسجيل الدخول مرة أخرى', 401);
    return $data;
}

// Optional customer auth - returns customer_id if logged in, null otherwise.
function optionalCustomerAuth() {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!str_starts_with($auth, 'Bearer ')) return null;
    $data = verifyToken(substr($auth, 7));
    if (!$data || ($data['type'] ?? '') !== 'customer') return null;
    return $data['customer_id'];
}
