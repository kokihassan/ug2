<?php
// apply_error_handler_patch.php
// Run this once: php apply_error_handler_patch.php
// It automatically inserts the global fatal-error JSON handler
// into config.php right after the CORS/OPTIONS block.

$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    die("❌ config.php not found at $configFile\n");
}

$content = file_get_contents($configFile);

if (strpos($content, 'register_shutdown_function') !== false) {
    die("✅ Already patched - nothing to do.\n");
}

$marker = "if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }";

if (strpos($content, $marker) === false) {
    die("❌ Could not find the expected marker line in config.php. No changes made.\n" .
        "   Looking for: $marker\n");
}

$patch = <<<'PATCH'


// ============================================================
// GLOBAL FATAL ERROR HANDLER (auto-added by apply_error_handler_patch.php)
// Ensures PHP fatal errors return JSON instead of an empty response.
// ============================================================
register_shutdown_function(function() {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في السيرفر: ' . $err['message'] . ' (' . basename($err['file']) . ':' . $err['line'] . ')',
            'data' => [],
        ], JSON_UNESCAPED_UNICODE);
    }
});
PATCH;

$newContent = str_replace($marker, $marker . $patch, $content);

// Backup first
copy($configFile, $configFile . '.bak-' . date('YmdHis'));

file_put_contents($configFile, $newContent);
echo "✅ Patched successfully! Backup saved as config.php.bak-*\n";
