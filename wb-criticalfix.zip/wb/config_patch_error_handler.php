<?php
// ============================================================
// PATCH for /var/www/restaurant/config.php
//
// PROBLEM: When a PHP fatal error happens (parse error, undefined
// function, missing extension, DB error not caught, etc.), the
// response body is EMPTY. The frontend then shows a generic
// "حدث خطأ غير متوقع" with zero information about what broke.
//
// FIX: Add this register_shutdown_function call near the TOP of
// config.php, right after the CORS/header() lines and the OPTIONS
// early-exit check (and BEFORE any require_once of api files).
//
// HOW TO APPLY:
//   1. Open /var/www/restaurant/config.php
//   2. Find this existing block:
//
//        header('Content-Type: application/json; charset=utf-8');
//        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }
//
//   3. Paste the code below IMMEDIATELY AFTER that block.
// ============================================================

register_shutdown_function(function() {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في السيرفر: ' . $err['message'] . ' (' . basename($err['file']) . ':' . $err['line'] . ')',
            'data' => [],
        ], JSON_UNESCAPED_UNICODE);
    }
});
