-- ============================================================
-- Migration: AI Providers (multi-provider chatbot with fallback)
-- Run this on EXISTING databases that don't have ai_providers yet:
--   mysql -u botuser -p restaurant_bot < migration_ai_providers.sql
-- ============================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS ai_providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider VARCHAR(30) NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  api_key VARCHAR(255) DEFAULT '',
  model VARCHAR(100) NOT NULL,
  is_active TINYINT(1) DEFAULT 1,
  is_default TINYINT(1) DEFAULT 0,
  priority INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
