<?php
// api/ai.php
// Multi-provider AI chat proxy with automatic fallback.
// Keeps API keys server-side (never exposed to the browser bundle).
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch ("$method:$action") {

    // ─── Public: send a chat message to AI (with restaurant context) ──
    case 'POST:chat':
        $data = json_decode(file_get_contents('php://input'), true);
        $messages = $data['messages'] ?? [];
        if (!is_array($messages) || count($messages) === 0) error('messages مطلوبة');

        $db = getDB();

        // ── Build system prompt from restaurant data ──────────────────
        $settings = $db->query("SELECT * FROM restaurant_settings LIMIT 1")->fetch();
        $botName = $settings['bot_name'] ?? 'نور';
        $restaurantName = $settings['name'] ?? 'مطعمنا';
        $currency = $settings['currency'] ?? 'جنيه';

        // Menu (limit categories/items for prompt size)
        $catStmt = $db->query("SELECT id, name, icon FROM categories WHERE is_active=1 ORDER BY sort_order LIMIT 10");
        $categories = $catStmt->fetchAll();
        $menuText = '';
        foreach ($categories as $cat) {
            $itemStmt = $db->prepare("SELECT name, price, description, is_featured, is_spicy, is_vegetarian, preparation_time_minutes
                FROM menu_items WHERE category_id=? AND is_available=1 ORDER BY is_featured DESC, sort_order LIMIT 8");
            $itemStmt->execute([$cat['id']]);
            $items = $itemStmt->fetchAll();
            if (!$items) continue;
            $menuText .= "\n{$cat['icon']} {$cat['name']}:\n";
            foreach ($items as $it) {
                $tags = [];
                if ($it['is_featured']) $tags[] = 'مميز ⭐';
                if ($it['is_spicy']) $tags[] = 'حار 🌶️';
                if ($it['is_vegetarian']) $tags[] = 'نباتي 🥗';
                $tagStr = $tags ? ' ['.implode(', ', $tags).']' : '';
                $menuText .= "- {$it['name']}: ".number_format($it['price'],0)." $currency (⏱️ {$it['preparation_time_minutes']} د)$tagStr\n";
            }
        }

        // Branches & delivery zones
        $branchStmt = $db->query("SELECT id, name, address, phone FROM branches WHERE is_active=1");
        $branches = $branchStmt->fetchAll();
        $branchText = '';
        foreach ($branches as $b) {
            $branchText .= "- {$b['name']}: {$b['address']}" . ($b['phone'] ? " (📞 {$b['phone']})" : '') . "\n";
            $zoneStmt = $db->prepare("SELECT zone_name, delivery_price, delivery_time_minutes FROM delivery_zones WHERE branch_id=? AND is_active=1 LIMIT 10");
            $zoneStmt->execute([$b['id']]);
            foreach ($zoneStmt->fetchAll() as $z) {
                $branchText .= "    • {$z['zone_name']}: توصيل {$z['delivery_price']} $currency (⏱️ {$z['delivery_time_minutes']} د)\n";
            }
        }

        // FAQ
        $faqStmt = $db->query("SELECT question, answer FROM faq WHERE is_active=1 ORDER BY sort_order LIMIT 10");
        $faqText = '';
        foreach ($faqStmt->fetchAll() as $f) {
            $faqText .= "س: {$f['question']}\nج: {$f['answer']}\n";
        }

        // Working hours / open status
        $statusText = $settings['is_open']
            ? 'المطعم مفتوح الآن ويستقبل طلبات.'
            : 'المطعم مغلق حالياً. ' . ($settings['closed_message'] ?? '');
        if (!empty($settings['orders_paused'])) {
            $statusText .= ' ⚠️ الطلبات متوقفة مؤقتاً: ' . ($settings['paused_message'] ?? '');
        }

        $personality = $settings['bot_personality'] ?? 'أنت مساعد ذكي ودود، تتكلم بالعربي بأسلوب محترم ومرحب.';

        $systemPrompt = <<<PROMPT
أنت {$botName}، المساعد الذكي لمطعم "{$restaurantName}".

{$personality}

═══ القواعد ═══
- أجب بإيجاز ووضوح (٢-٤ جمل قصار كحد أقصى)
- استخدم المعلومات أدناه فقط، ولا تخترع أصناف أو أسعار غير موجودة
- لو السؤال عن الطلب، وجّه العميل لزر "اطلب الآن" أو صفحة المنيو
- لو سُئلت عن شيء غير متعلق بالمطعم، أعد التوجيه بلطف لخدمات المطعم

═══ حالة المطعم ═══
{$statusText}

═══ المنيو ═══
{$menuText}

═══ الفروع ومناطق التوصيل ═══
{$branchText}

═══ أسئلة شائعة ═══
{$faqText}
PROMPT;

        // ── Load active AI providers in priority order ────────────────
        $providers = $db->query("SELECT * FROM ai_providers WHERE is_active=1 ORDER BY is_default DESC, priority ASC, id ASC")->fetchAll();

        if (!$providers) {
            error('لم يتم إعداد أي مزود AI. يرجى إضافة مزود من لوحة التحكم → الإعدادات → AI', 503);
        }

        $lastError = null;
        foreach ($providers as $provider) {
            $result = callAiProvider($provider, $messages, $systemPrompt);
            if ($result['success']) {
                success(['reply' => $result['reply'], 'provider' => $provider['display_name']]);
            }
            $lastError = $result['error'];
            // try next provider on failure
        }

        error('تعذر الحصول على رد من أي مزود AI. آخر خطأ: ' . $lastError, 503);

    default:
        error('Action not found', 404);
}

// ════════════════════════════════════════════════════════════════
// PROVIDER CALLERS
// ════════════════════════════════════════════════════════════════

function callAiProvider($provider, $messages, $systemPrompt) {
    switch ($provider['provider']) {
        case 'gemini':     return callGemini($provider, $messages, $systemPrompt);
        case 'groq':       return callOpenAiCompatible($provider, $messages, $systemPrompt, 'https://api.groq.com/openai/v1/chat/completions');
        case 'openrouter': return callOpenAiCompatible($provider, $messages, $systemPrompt, 'https://openrouter.ai/api/v1/chat/completions');
        default:
            return ['success' => false, 'error' => 'مزود غير معروف: ' . $provider['provider']];
    }
}

function callGemini($provider, $messages, $systemPrompt) {
    if (empty($provider['api_key'])) return ['success'=>false,'error'=>'Gemini: لا يوجد API Key'];

    $contents = [
        ['role'=>'user', 'parts'=>[['text'=>"[SYSTEM]\n$systemPrompt"]]],
        ['role'=>'model', 'parts'=>[['text'=>'مفهوم! أنا جاهز أساعد. 😊']]],
    ];
    foreach ($messages as $m) {
        $contents[] = ['role'=> $m['role']==='user'?'user':'model', 'parts'=>[['text'=>$m['content']]]];
    }

    $url = "https://generativelanguage.googleapis.com/v1beta/models/{$provider['model']}:generateContent?key={$provider['api_key']}";
    $body = [
        'contents' => $contents,
        'generationConfig' => ['temperature'=>0.8,'maxOutputTokens'=>500],
        'safetySettings' => [
            ['category'=>'HARM_CATEGORY_HARASSMENT','threshold'=>'BLOCK_NONE'],
            ['category'=>'HARM_CATEGORY_HATE_SPEECH','threshold'=>'BLOCK_NONE'],
            ['category'=>'HARM_CATEGORY_SEXUALLY_EXPLICIT','threshold'=>'BLOCK_NONE'],
            ['category'=>'HARM_CATEGORY_DANGEROUS_CONTENT','threshold'=>'BLOCK_NONE'],
        ],
    ];

    [$status, $resBody] = httpPostJson($url, $body, []);
    $d = json_decode($resBody, true);

    if ($status !== 200) {
        $msg = $d['error']['message'] ?? "HTTP $status";
        return ['success'=>false,'error'=>"Gemini: $msg"];
    }
    $candidate = $d['candidates'][0] ?? null;
    if (!$candidate) return ['success'=>false,'error'=>'Gemini: لا يوجد رد (candidates فاضية)'];
    if (($candidate['finishReason'] ?? '') === 'SAFETY') return ['success'=>false,'error'=>'Gemini: تم حظر الرد لأسباب أمان'];
    $text = $candidate['content']['parts'][0]['text'] ?? null;
    if (!$text) return ['success'=>false,'error'=>'Gemini: رد فاضي'];

    return ['success'=>true,'reply'=>$text];
}

// Groq & OpenRouter both use the OpenAI-compatible /chat/completions format
function callOpenAiCompatible($provider, $messages, $systemPrompt, $endpoint) {
    if (empty($provider['api_key'])) return ['success'=>false,'error'=>"{$provider['provider']}: لا يوجد API Key"];

    $chatMessages = [['role'=>'system','content'=>$systemPrompt]];
    foreach ($messages as $m) {
        $chatMessages[] = ['role'=> $m['role']==='user'?'user':'assistant', 'content'=>$m['content']];
    }

    $body = [
        'model' => $provider['model'],
        'messages' => $chatMessages,
        'temperature' => 0.8,
        'max_tokens' => 500,
    ];

    $headers = ['Authorization: Bearer ' . $provider['api_key']];
    // OpenRouter recommends these headers (optional but improves routing/analytics)
    if ($provider['provider'] === 'openrouter') {
        $headers[] = 'HTTP-Referer: ' . (defined('APP_URL') ? APP_URL : 'http://localhost');
        $headers[] = 'X-Title: Restaurant AI Assistant';
    }

    [$status, $resBody] = httpPostJson($endpoint, $body, $headers);
    $d = json_decode($resBody, true);

    if ($status !== 200) {
        $msg = $d['error']['message'] ?? "HTTP $status";
        return ['success'=>false,'error'=>"{$provider['display_name']}: $msg"];
    }
    $text = $d['choices'][0]['message']['content'] ?? null;
    if (!$text) return ['success'=>false,'error'=>"{$provider['display_name']}: رد فاضي"];

    return ['success'=>true,'reply'=>trim($text)];
}

// ─── Shared HTTP helper ─────────────────────────────────────────────
function httpPostJson($url, $body, $extraHeaders = []) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $extraHeaders),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($response === false) {
        $err = curl_error($ch);
        curl_close($ch);
        return [0, json_encode(['error'=>['message'=>"cURL error: $err"]])];
    }
    curl_close($ch);
    return [$status, $response];
}
