import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore, useCartStore } from '../store'
import { askAI } from '../api'
import { useT } from '../components/ui'

export default function PublicLayout() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Outlet />
      </main>
      <AIChat />
      <Footer />
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// NAVBAR
// ══════════════════════════════════════════════════════════════
function Navbar() {
  const navigate = useNavigate()
  const location = useLocation()
  const t = useT()
  const { isDark, toggleTheme, lang, toggleLang, settings } = useAppStore()
  const items = useCartStore(s => s.items)
  const unitPrice = useCartStore(s => s.unitPrice)
  const count = items.reduce((s, i) => s + i.qty, 0)
  const total = items.reduce((s, i) => s + unitPrice(i) * i.qty, 0)
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', h)
    return () => window.removeEventListener('scroll', h)
  }, [])

  const navLinks = [
    { path: '/', label: t('الرئيسية', 'Home') },
    { path: '/menu', label: t('المنيو', 'Menu') },
  ]

  return (
    <motion.nav
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-obsidian-900/95 backdrop-blur-xl border-b border-obsidian-700 shadow-2xl'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center gap-4">
        {/* Logo */}
        <button onClick={() => navigate('/')} className="flex-1 text-start no-select">
          <div className="gold-text font-display text-xl sm:text-2xl font-bold tracking-wide leading-none">
            {settings?.name || t('مطعمنا', 'Our Restaurant')}
          </div>
          <div className="text-obsidian-500 text-[9px] tracking-[4px] uppercase mt-0.5 hidden sm:block">
            {t('مطبخ راقي', 'Fine Dining')}
          </div>
        </button>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map(link => (
            <button key={link.path} onClick={() => navigate(link.path)}
              className={`px-4 py-2 text-sm font-semibold transition-all border-b-2 ${
                location.pathname === link.path
                  ? 'text-gold-400 border-gold-500'
                  : 'text-obsidian-400 border-transparent hover:text-gold-400'
              }`}>
              {link.label}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Theme */}
          <button onClick={toggleTheme}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-obsidian-800 border border-obsidian-700 hover:border-gold-600 transition-all text-lg">
            {isDark ? '☀️' : '🌙'}
          </button>

          {/* Lang */}
          <button onClick={toggleLang}
            className="h-9 px-3 rounded-xl bg-obsidian-800 border border-obsidian-700 hover:border-gold-600 text-obsidian-300 text-xs font-black tracking-widest transition-all">
            {lang === 'ar' ? 'EN' : 'عر'}
          </button>

          {/* Cart */}
          <button onClick={() => navigate('/cart')}
            className="btn-gold h-9 px-4 rounded-xl flex items-center gap-2 text-sm">
            🛒
            {count > 0 && (
              <>
                <span className="bg-obsidian-950 text-gold-400 rounded-full w-5 h-5 flex items-center justify-center text-[11px] font-black">
                  {count}
                </span>
                <span className="text-xs hidden sm:block">{total} {t('ج', 'EGP')}</span>
              </>
            )}
          </button>

          {/* Admin */}
          <button onClick={() => navigate('/admin')}
            className="hidden sm:flex h-9 px-3 rounded-xl border border-obsidian-700 hover:border-gold-600 text-obsidian-400 hover:text-gold-400 items-center text-xs transition-all">
            ⚙️
          </button>
        </div>
      </div>
    </motion.nav>
  )
}

// ══════════════════════════════════════════════════════════════
// AI CHAT
// ══════════════════════════════════════════════════════════════
function AIChat() {
  const t = useT()
  const { settings, lang } = useAppStore()
  const { add: addToCart } = useCartStore()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef()

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{
        role: 'assistant',
        content: t(
          `أهلاً وسهلاً! 👋 أنا ${settings?.bot_name || 'نور'}، مساعدك في ${settings?.name || 'مطعمنا'}.\nكيف أقدر أساعدك النهارده؟ 😊`,
          `Welcome! 👋 I'm ${settings?.bot_name || 'Nour'}, your assistant at ${settings?.name || 'our restaurant'}.\nHow can I help you today? 😊`
        )
      }])
    }
  }, [open])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = async () => {
    if (!input.trim() || loading) return
    const userMsg = { role: 'user', content: input }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setInput('')
    setLoading(true)
    const reply = await askAI(newMessages)
    setMessages(p => [...p, { role: 'assistant', content: reply }])
    setLoading(false)
  }

  const quickActions = [
    [t('🍽️ المنيو', '🍽️ Menu'), t('إيه أحسن حاجة عندكم؟', 'What\'s your best dish?')],
    [t('🛵 التوصيل', '🛵 Delivery'), t('بتوصلوا إمتى؟', 'When do you deliver?')],
    [t('⭐ الأكثر طلباً', '⭐ Popular'), t('إيه الأكثر طلباً؟', 'What\'s most ordered?')],
  ]

  return (
    <>
      {/* Toggle */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 end-6 z-50 w-14 h-14 rounded-full btn-gold shadow-2xl flex items-center justify-center text-2xl anim-pulse"
        style={{ animationDuration: open ? '0s' : '2s' }}
      >
        {open ? '✕' : '🤖'}
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="fixed bottom-24 end-6 z-50 w-80 sm:w-96 h-[500px] bg-obsidian-800 border border-obsidian-700 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gold-gradient p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-obsidian-900 flex items-center justify-center text-xl">🤖</div>
              <div>
                <div className="font-black text-obsidian-900 text-sm">{settings?.bot_name || 'نور'}</div>
                <div className="text-obsidian-800 text-xs opacity-70 flex items-center gap-1">
                  <span className="w-2 h-2 bg-emerald-600 rounded-full"></span>
                  {t('متاح الآن', 'Online now')}
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  <div className={`max-w-[80%] px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap
                    ${msg.role === 'user' ? 'bubble-user' : 'bubble-bot'}`}>
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {loading && (
                <div className="flex justify-end">
                  <div className="bubble-bot px-4 py-3 flex gap-1">
                    {[0,1,2].map(i => (
                      <div key={i} className="w-2 h-2 rounded-full bg-gold-500 anim-pulse" style={{ animationDelay: `${i*0.15}s` }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick actions */}
            <div className="px-3 py-2 flex gap-2 overflow-x-auto border-t border-obsidian-700">
              {quickActions.map(([label, msg]) => (
                <button key={label} onClick={() => setInput(msg)}
                  className="flex-shrink-0 bg-obsidian-700 hover:bg-obsidian-600 border border-obsidian-600 text-obsidian-300 text-xs px-3 py-1.5 rounded-full transition-colors whitespace-nowrap">
                  {label}
                </button>
              ))}
            </div>

            {/* Input */}
            <div className="p-3 border-t border-obsidian-700 flex gap-2">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && send()}
                placeholder={t('اكتب رسالتك...', 'Type a message...')}
                className="flex-1 bg-obsidian-700 border border-obsidian-600 rounded-xl px-4 py-2 text-sm text-white placeholder-obsidian-400 outline-none focus:border-gold-600 transition-colors font-inherit"
              />
              <button onClick={send} disabled={loading || !input.trim()}
                className="btn-gold w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-sm disabled:opacity-40">
                ←
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// ══════════════════════════════════════════════════════════════
// FOOTER
// ══════════════════════════════════════════════════════════════
function Footer() {
  const t = useT()
  const { settings } = useAppStore()
  return (
    <footer className="border-t border-obsidian-800 bg-obsidian-900 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 sm:grid-cols-3 gap-8">
        <div>
          <div className="gold-text font-display text-xl font-bold mb-3">
            {settings?.name || t('مطعمنا', 'Our Restaurant')}
          </div>
          <p className="text-obsidian-400 text-sm leading-relaxed">
            {t('تجربة طعام راقية — أجود المكونات، أمهر الطهاة، أجمل اللحظات',
              'A luxury dining experience — finest ingredients, master chefs, beautiful moments')}
          </p>
        </div>
        <div>
          <h4 className="text-gold-500 text-xs tracking-[3px] uppercase font-bold mb-4">{t('تواصل معنا','Contact Us')}</h4>
          <div className="space-y-2 text-sm text-obsidian-400">
            {settings?.phone && <p>📞 {settings.phone}</p>}
            {settings?.email && <p>✉️ {settings.email}</p>}
          </div>
        </div>
        <div>
          <h4 className="text-gold-500 text-xs tracking-[3px] uppercase font-bold mb-4">{t('أوقات العمل','Working Hours')}</h4>
          <p className="text-sm text-obsidian-400">{t('يومياً: ١٠ ص — ١٢ م','Daily: 10 AM — 12 AM')}</p>
        </div>
      </div>
      <div className="border-t border-obsidian-800 py-4 text-center text-xs text-obsidian-600">
        © {new Date().getFullYear()} {settings?.name} — {t('جميع الحقوق محفوظة','All Rights Reserved')}
      </div>
    </footer>
  )
}
