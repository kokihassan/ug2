<?php
// api/customers.php
require_once '../config.php';
require_once '../includes/mailer.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    // ─── Send email OTP (registration/verification) ────────────────
    case 'POST:send-otp':
        $data = json_decode(file_get_contents('php://input'), true);
        $email = trim(strtolower($data['email'] ?? ''));
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) error('بريد إلكتروني غير صالح');

        $db = getDB();
        $settings = $db->query("SELECT * FROM restaurant_settings LIMIT 1")->fetch();

        // Rate limit: max 1 OTP per 60 seconds per email
        $recent = $db->prepare("SELECT created_at FROM email_otps WHERE email=? ORDER BY created_at DESC LIMIT 1");
        $recent->execute([$email]);
        $last = $recent->fetch();
        if ($last && (time() - strtotime($last['created_at'])) < 60) {
            error('يرجى الانتظار دقيقة قبل طلب رمز جديد');
        }

        $code = generateOtpCode();
        $expiresAt = date('Y-m-d H:i:s', time() + 600); // 10 minutes
        $db->prepare("INSERT INTO email_otps (email, code, purpose, expires_at) VALUES (?,?,?,?)")
           ->execute([$email, $code, $data['purpose'] ?? 'verify', $expiresAt]);

        $restaurantName = $settings['name'] ?? 'المطعم';
        $html = "
            <div style='font-family:Tahoma,Arial,sans-serif;direction:rtl;text-align:center;padding:24px;background:#0a0a08;color:#f0ede8'>
                <h2 style='color:#c9a84c'>$restaurantName</h2>
                <p>رمز التحقق الخاص بك هو:</p>
                <div style='font-size:32px;font-weight:bold;letter-spacing:8px;color:#c9a84c;margin:16px 0'>$code</div>
                <p style='color:#888;font-size:12px'>صالح لمدة 10 دقائق. لا تشاركه مع أي شخص.</p>
            </div>";

        $result = smtpSendMail($settings, $email, "$restaurantName - رمز التحقق: $code", $html);
        if (!$result['success']) error($result['error'], 500);
        success([], 'تم إرسال رمز التحقق إلى بريدك الإلكتروني');

    // ─── Verify email OTP ────────────────────────────────────────
    case 'POST:verify-otp':
        $data = json_decode(file_get_contents('php://input'), true);
        $email = trim(strtolower($data['email'] ?? ''));
        $code = trim($data['code'] ?? '');
        if (!$email || !$code) error('البريد والرمز مطلوبان');

        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM email_otps WHERE email=? AND code=? AND used=0 AND expires_at >= NOW() ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$email, $code]);
        $otp = $stmt->fetch();
        if (!$otp) error('رمز غير صحيح أو منتهي الصلاحية');

        $db->prepare("UPDATE email_otps SET used=1 WHERE id=?")->execute([$otp['id']]);

        // If a logged-in customer is verifying their email, mark it verified
        $authCustomerId = optionalCustomerAuth();
        if ($authCustomerId) {
            $db->prepare("UPDATE customers SET email=?, email_verified=1 WHERE id=?")->execute([$email, $authCustomerId]);
        }

        success(['verified' => true], 'تم التحقق بنجاح');

    // ─── Customer Account: Register (phone + password) ────────────
    case 'POST:register':
        $data = json_decode(file_get_contents('php://input'), true);
        $phone = trim($data['whatsapp_number'] ?? '');
        $password = $data['password'] ?? '';
        $name = trim($data['name'] ?? '');
        $email = trim(strtolower($data['email'] ?? ''));
        if (!$phone || !$password) error('رقم الهاتف وكلمة المرور مطلوبان');
        if (strlen($password) < 6) error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');

        $db = getDB();

        // If email is provided, require it to have been verified via OTP just now
        $emailVerified = 0;
        if ($email) {
            $otpCheck = $db->prepare("SELECT id FROM email_otps WHERE email=? AND used=1 AND purpose='verify' AND created_at >= (NOW() - INTERVAL 30 MINUTE) ORDER BY id DESC LIMIT 1");
            $otpCheck->execute([$email]);
            $emailVerified = $otpCheck->fetch() ? 1 : 0;
        }

        $stmt = $db->prepare("SELECT id, password FROM customers WHERE whatsapp_number=?");
        $stmt->execute([$phone]);
        $existing = $stmt->fetch();

        if ($existing) {
            if (!empty($existing['password'])) {
                error('هذا الرقم مسجل بالفعل، يرجى تسجيل الدخول');
            }
            // Existing guest customer (created via get-or-create) — add password
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare("UPDATE customers SET password=?, name=COALESCE(NULLIF(name,''), ?), email=COALESCE(?, email), email_verified=? WHERE id=?")
               ->execute([$hash, $name, $email ?: null, $emailVerified, $existing['id']]);
            $customerId = $existing['id'];
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $db->prepare("INSERT INTO customers (whatsapp_number, password, name, email, email_verified) VALUES (?,?,?,?,?)")
               ->execute([$phone, $hash, $name, $email ?: null, $emailVerified]);
            $customerId = $db->lastInsertId();
        }

        $token = generateToken(['customer_id' => $customerId, 'type' => 'customer']);
        $cust = $db->prepare("SELECT id, whatsapp_number, name, phone, email FROM customers WHERE id=?");
        $cust->execute([$customerId]);
        success(['token' => $token, 'customer' => $cust->fetch()], 'تم إنشاء الحساب بنجاح', 201);

    // ─── Customer Account: Login ───────────────────────────────────
    case 'POST:login':
        $data = json_decode(file_get_contents('php://input'), true);
        $phone = trim($data['whatsapp_number'] ?? '');
        $password = $data['password'] ?? '';
        if (!$phone || !$password) error('رقم الهاتف وكلمة المرور مطلوبان');

        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM customers WHERE whatsapp_number=?");
        $stmt->execute([$phone]);
        $customer = $stmt->fetch();

        if (!$customer || empty($customer['password']) || !password_verify($password, $customer['password'])) {
            error('رقم الهاتف أو كلمة المرور غير صحيحة', 401);
        }
        if ($customer['is_blacklisted']) {
            error('هذا الحساب محظور. تواصل مع المطعم لمزيد من المعلومات', 403);
        }

        $token = generateToken(['customer_id' => $customer['id'], 'type' => 'customer']);
        unset($customer['password']);
        success(['token' => $token, 'customer' => $customer], 'تم تسجيل الدخول');

    // ─── Customer Account: Get current profile ─────────────────────
    case 'GET:me':
        $customerData = requireCustomerAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT id, whatsapp_number, name, phone, email, balance, total_orders, total_spent FROM customers WHERE id=?");
        $stmt->execute([$customerData['customer_id']]);
        $customer = $stmt->fetch();
        if (!$customer) error('الحساب غير موجود', 404);

        $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
        $addrs->execute([$customer['id']]);
        $customer['addresses'] = $addrs->fetchAll();
        success($customer);

    // ─── Customer Account: My Orders ────────────────────────────────
    case 'GET:my-orders':
        $customerData = requireCustomerAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT o.*, b.name as branch_name FROM orders o LEFT JOIN branches b ON o.branch_id=b.id WHERE o.customer_id=? ORDER BY o.created_at DESC LIMIT 50");
        $stmt->execute([$customerData['customer_id']]);
        $orders = $stmt->fetchAll();
        foreach ($orders as &$order) {
            $items = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
            $items->execute([$order['id']]);
            $orderItems = $items->fetchAll();
            foreach ($orderItems as &$oi) {
                $oi['extras'] = !empty($oi['extras']) ? json_decode($oi['extras'], true) : [];
            }
            $order['items'] = $orderItems;
        }
        success($orders);

    // ─── Get or create customer by WhatsApp ──────────────────────
    case 'POST:get-or-create':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("SELECT c.*, GROUP_CONCAT(ca.label,':', ca.address ORDER BY ca.is_default DESC SEPARATOR '||') as addresses_str FROM customers c LEFT JOIN customer_addresses ca ON c.id=ca.customer_id WHERE c.whatsapp_number=? GROUP BY c.id");
        $stmt->execute([$data['whatsapp_number']]);
        $customer = $stmt->fetch();
        
        if (!$customer) {
            $db->prepare("INSERT INTO customers (whatsapp_number) VALUES (?)")->execute([$data['whatsapp_number']]);
            $customer = ['id' => $db->lastInsertId(), 'whatsapp_number' => $data['whatsapp_number'], 'name' => null, 'is_blacklisted' => 0, 'total_orders' => 0, 'addresses' => []];
        } else {
            $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
            $addrs->execute([$customer['id']]);
            $customer['addresses'] = $addrs->fetchAll();
            
            // Get last order
            $lastOrder = $db->prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY created_at DESC LIMIT 1");
            $lastOrder->execute([$customer['id']]);
            $customer['last_order'] = $lastOrder->fetch();
            
            // Get favorite items
            $favs = $db->prepare("SELECT oi.item_name, SUM(oi.quantity) as count FROM order_items oi JOIN orders o ON oi.order_id=o.id WHERE o.customer_id=? GROUP BY oi.item_name ORDER BY count DESC LIMIT 3");
            $favs->execute([$customer['id']]);
            $customer['favorite_items'] = $favs->fetchAll();
        }
        success($customer);

    case 'PUT:update':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET name=?, phone=?, email=? WHERE whatsapp_number=?")
           ->execute([$data['name'], $data['phone']??null, $data['email']??null, $data['whatsapp_number']]);
        success([], 'تم تحديث البيانات');

    // ─── Customer: Add address ─────────────────────────────────────
    case 'POST:add-address':
        $authData = requireCustomerAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $customerId = $authData['customer_id'];

        // Limit to 5 saved addresses per customer
        $count = $db->prepare("SELECT COUNT(*) FROM customer_addresses WHERE customer_id=?");
        $count->execute([$customerId]);
        if ($count->fetchColumn() >= 5) error('الحد الأقصى 5 عناوين محفوظة');

        if ($data['is_default'] ?? 0) {
            $db->prepare("UPDATE customer_addresses SET is_default=0 WHERE customer_id=?")->execute([$customerId]);
        }
        $db->prepare("INSERT INTO customer_addresses (customer_id, label, address, area, zone_id, is_default) VALUES (?,?,?,?,?,?)")
           ->execute([$customerId, $data['label']??'بيت', $data['address'], $data['area']??null, $data['zone_id']??null, $data['is_default']??0]);
        success(['id' => $db->lastInsertId()], 'تم حفظ العنوان', 201);

    // ─── Customer: List my addresses ───────────────────────────────
    case 'GET:my-addresses':
        $authData = requireCustomerAuth();
        $db = getDB();
        $stmt = $db->prepare("SELECT ca.*, dz.zone_name, dz.delivery_price FROM customer_addresses ca
            LEFT JOIN delivery_zones dz ON ca.zone_id=dz.id
            WHERE ca.customer_id=? ORDER BY ca.is_default DESC, ca.id DESC");
        $stmt->execute([$authData['customer_id']]);
        success($stmt->fetchAll());

    // ─── Customer: Delete an address ────────────────────────────────
    case 'DELETE:address':
        $authData = requireCustomerAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $db = getDB();
        $db->prepare("DELETE FROM customer_addresses WHERE id=? AND customer_id=?")->execute([$id, $authData['customer_id']]);
        success([], 'تم الحذف');

    // ─── Customer: Set an address as default ───────────────────────
    case 'PUT:address-default':
        $authData = requireCustomerAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $db = getDB();
        $db->prepare("UPDATE customer_addresses SET is_default=0 WHERE customer_id=?")->execute([$authData['customer_id']]);
        $db->prepare("UPDATE customer_addresses SET is_default=1 WHERE id=? AND customer_id=?")->execute([$id, $authData['customer_id']]);
        success([], 'تم التحديث');

    // ─── ADMIN: List customers ────────────────────────────────────
    case 'GET:list':
        requireAuth();
        $db = getDB();
        $search = $_GET['search'] ?? null;
        $sql = "SELECT c.*, COUNT(o.id) as order_count, SUM(o.total_amount) as total_spent FROM customers c LEFT JOIN orders o ON c.id=o.customer_id WHERE 1=1";
        $params = [];
        if ($search) { $sql .= " AND (c.name LIKE ? OR c.whatsapp_number LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $sql .= " GROUP BY c.id ORDER BY c.created_at DESC LIMIT 50";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        success($stmt->fetchAll());

    // ─── ADMIN: Export all customers as CSV ─────────────────────────
    case 'GET:export-csv':
        requireAuth();
        $db = getDB();
        $rows = $db->query("SELECT c.name, c.whatsapp_number, c.email, c.balance, c.total_orders, c.total_spent, c.is_blacklisted, c.created_at
            FROM customers c ORDER BY c.created_at DESC")->fetchAll();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="customers_' . date('Y-m-d') . '.csv"');
        echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel/Arabic
        echo "الاسم,رقم الهاتف,البريد الإلكتروني,الرصيد,عدد الطلبات,إجمالي الإنفاق,محظور,تاريخ التسجيل\n";
        foreach ($rows as $r) {
            $line = [
                $r['name'] ?: '',
                $r['whatsapp_number'],
                $r['email'] ?: '',
                $r['balance'],
                $r['total_orders'],
                $r['total_spent'],
                $r['is_blacklisted'] ? 'نعم' : 'لا',
                $r['created_at'],
            ];
            echo implode(',', array_map(fn($v) => '"' . str_replace('"','""',$v) . '"', $line)) . "\n";
        }
        exit();
        $stmt->execute($params);
        success($stmt->fetchAll());

    case 'PUT:blacklist':
        requireAuth();
        $id = $path[1] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET is_blacklisted=?, blacklist_reason=? WHERE id=?")
           ->execute([$data['is_blacklisted'], $data['reason']??null, $id]);
        success([], 'تم التحديث');

    // ─── ADMIN: Adjust customer balance (add credit / debit) ───────
    case 'POST:adjust-balance':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing customer ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $amount = (float)($data['amount'] ?? 0);
        if ($amount == 0) error('أدخل قيمة غير صفرية');
        $reason = $data['reason'] ?? ($amount > 0 ? 'إضافة رصيد من الإدارة' : 'خصم من الإدارة');

        $db = getDB();
        $db->beginTransaction();
        try {
            $db->prepare("UPDATE customers SET balance = balance + ? WHERE id=?")->execute([$amount, $id]);
            $db->prepare("INSERT INTO balance_transactions (customer_id, amount, reason, created_by) VALUES (?,?,?,'admin')")
               ->execute([$id, $amount, $reason]);
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            error('فشل تحديث الرصيد: ' . $e->getMessage(), 500);
        }

        $stmt = $db->prepare("SELECT balance FROM customers WHERE id=?");
        $stmt->execute([$id]);
        success(['balance' => (float)$stmt->fetchColumn()], 'تم تحديث الرصيد');

    // ─── ADMIN: Balance transaction history for a customer ──────────
    case 'GET:balance-history':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing customer ID');
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM balance_transactions WHERE customer_id=? ORDER BY created_at DESC LIMIT 50");
        $stmt->execute([$id]);
        success($stmt->fetchAll());

    // ─── ADMIN: Get a single customer's full profile ────────────────
    case 'GET:detail':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing customer ID');
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM customers WHERE id=?");
        $stmt->execute([$id]);
        $customer = $stmt->fetch();
        if (!$customer) error('العميل غير موجود', 404);
        unset($customer['password']);

        $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
        $addrs->execute([$id]);
        $customer['addresses'] = $addrs->fetchAll();

        $coupons = $db->prepare("SELECT * FROM coupons WHERE customer_id=? ORDER BY created_at DESC");
        $coupons->execute([$id]);
        $customer['personal_coupons'] = $coupons->fetchAll();

        success($customer);

    default:
        error('Action not found', 404);
}
