<?php
// test_smtp.php
// Standalone SMTP test - bypasses the web UI entirely so we can see
// the exact error. Run from /var/www/restaurant:
//   php test_smtp.php your-email@example.com
//
// Reads SMTP settings directly from the database.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/mailer.php';

$toEmail = $argv[1] ?? null;
if (!$toEmail) {
    die("Usage: php test_smtp.php your-email@example.com\n");
}

$db = getDB();
$settings = $db->query("SELECT * FROM restaurant_settings LIMIT 1")->fetch();

echo "=== Current SMTP settings in database ===\n";
echo "smtp_host: " . ($settings['smtp_host'] ?: '(empty)') . "\n";
echo "smtp_port: " . ($settings['smtp_port'] ?: '(empty)') . "\n";
echo "smtp_user: " . ($settings['smtp_user'] ?: '(empty)') . "\n";
echo "smtp_pass: " . (!empty($settings['smtp_pass']) ? '(set, ' . strlen($settings['smtp_pass']) . ' chars)' : '(empty)') . "\n";
echo "smtp_from_email: " . ($settings['smtp_from_email'] ?: '(empty)') . "\n";
echo "smtp_secure: " . ($settings['smtp_secure'] ?: '(empty)') . "\n\n";

if (empty($settings['smtp_host'])) {
    die("❌ SMTP not configured at all. Save settings in the admin panel first.\n");
}

echo "=== Testing connection ===\n";
$start = microtime(true);
$result = smtpSendMail($settings, $toEmail, 'SMTP Test', '<p>This is a test email from the restaurant system.</p>');
$elapsed = round(microtime(true) - $start, 2);

echo "Took {$elapsed}s\n\n";

if ($result['success']) {
    echo "✅ SUCCESS! Email sent to $toEmail\n";
} else {
    echo "❌ FAILED: " . $result['error'] . "\n";
}
